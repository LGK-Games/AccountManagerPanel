<?php

$txt['guest_only'] = 'Guest Content';

?>
