<?php
/**
 *
 * @author  rumpa	http://arnitcreation.online
 * @license BSD http://opensource.org/licenses/bsd-license.php
 * @mod		Guest BBC
 *
 */

if (!defined('SMF'))
	die('Hacking attempt...');

	

function GuestBBC(&$codes)
{
	global $user_info;
	// Add bbc code(s)
	$codes[] = array(
             'tag' => 'guest',
             'type' => 'unparsed_content',
             'content' => $user_info['is_guest'] ? '$1' :'',
    );
}			

function GuestBBC_buttons(&$bbc_tags)
{
	global $txt;

	// Load language
	loadLanguage('GuestBBC');

	// Add guest bbc buttons after 'justify' button.
	$guest_bbc = array();
	foreach ($bbc_tags[0] as $tag)
	{
		$guest_bbc[] = $tag;
		if (isset($tag['code']) && $tag['code'] == 'justify')
		{
			$guest_bbc[] = array(
			);
			$guest_bbc[] = array(
				'image' => 'guest',
				'code' => 'guest',
				'before' => '[guest]',
				'after' => '[/guest]',
				'description' => $txt['guest_only']
			);
		}
	}
	$bbc_tags[0] = $guest_bbc;
}

?>
