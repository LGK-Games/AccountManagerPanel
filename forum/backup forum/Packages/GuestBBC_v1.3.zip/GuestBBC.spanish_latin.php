<?php

$txt['guest_only'] = 'Contenido para visitante(s)';

?>
