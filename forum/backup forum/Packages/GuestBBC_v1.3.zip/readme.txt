[center][b]About[/b]

This modification is for guset visitor only. Members can create or post for guest.Topic or post creater can not see this content only guest can view it.


[color=green]Best part of this mod put a "guest" button after "justify" button

tag use for this modification [guest]guest content[/guest]

[b]Version[/b]

V1.3 for SMF 2.1.3
Solve the issue of error log

V1.2 for SMF 2.1.2
Remove little bug from the package info file thanks to [color=blue]Doug Heffernan[/color]

Language added
V1.1 for SMF 2.1.2 
(Spanish language added credit goes to [color=blue]-Rock Lee-[/color]

Initial Release
V1.0 for SMF 2.1.2

[b]Author[/b]

[b][color=red]Rumpa[/color][/b][/center]