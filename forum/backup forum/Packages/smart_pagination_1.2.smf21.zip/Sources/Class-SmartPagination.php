<?php

/**
 * Class-SmartPagination.php
 *
 * @package Smart Pagination
 * @link https://dragomano.ru/mods/smart-pagination
 * @author Bugo <bugo@dragomano.ru>
 * @copyright 2010-2022 Bugo
 * @license https://opensource.org/licenses/BSD-3-Clause BSD
 *
 * @version 1.2
 */

if (!defined('SMF'))
	die('Hacking attempt...');

final class SmartPagination
{
	public function hooks()
	{
		add_integration_function('integrate_load_theme', __CLASS__ . '::loadTheme#', false, __FILE__);
		add_integration_function('integrate_menu_buttons', __CLASS__ . '::menuButtons#', false, __FILE__);
	}

	public function loadTheme()
	{
		global $settings, $txt;

		$settings['page_index'] = array_merge(
			isset($settings['page_index']) ? $settings['page_index'] : [],
			array(
				'extra_before'  => '<span class="pages">' . $txt['pages'] . '</span>',
				'current_page'  => '<span class="current_page button active">%1$d</span> ',
				'page'          => '<a class="nav_page button" href="{URL}">%2$s</a> ',
				'expand_pages'  => '<span class="expand_pages button" onclick="expandPages(this, {LINK}, {FIRST_PAGE}, {LAST_PAGE}, {PER_PAGE});"> ... </span>',
				'extra_after'   => ''
			)
		);

		loadCSSFile('smart_pagination.css');
	}

	public function menuButtons()
	{
		global $context;

		if (!empty($context['page_index']) && !strpos($context['page_index'], '2'))
			$context['page_index'] = '';
	}
}
