<?php return array(
    'root' => array(
        'name' => 'suki/breeze',
        'pretty_version' => 'dev-develop',
        'version' => 'dev-develop',
        'reference' => 'ed7f2857425cec5515a8b417d390904acaaa0804',
        'type' => 'smf-module',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'dev' => false,
    ),
    'versions' => array(
        'league/container' => array(
            'pretty_version' => '4.2.2',
            'version' => '4.2.2.0',
            'reference' => 'ff346319ca1ff0e78277dc2311a42107cc1aab88',
            'type' => 'library',
            'install_path' => __DIR__ . '/../league/container',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
        'orno/di' => array(
            'dev_requirement' => false,
            'replaced' => array(
                0 => '~2.0',
            ),
        ),
        'psr/container' => array(
            'pretty_version' => '2.0.2',
            'version' => '2.0.2.0',
            'reference' => 'c71ecc56dfe541dbd90c5360474fbc405f8d5963',
            'type' => 'library',
            'install_path' => __DIR__ . '/../psr/container',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
        'psr/container-implementation' => array(
            'dev_requirement' => false,
            'provided' => array(
                0 => '^1.0',
            ),
        ),
        'suki/breeze' => array(
            'pretty_version' => 'dev-develop',
            'version' => 'dev-develop',
            'reference' => 'ed7f2857425cec5515a8b417d390904acaaa0804',
            'type' => 'smf-module',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
