<?php

/*******************************************************************************
 * Smarter Internal Links
 *
 * A modification for Simple Machines Forum 2.1 that causes links to pages
 * within the forum to open in the same window by default.
 *
 * Copyright (c) 2022 Jon Stovell
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/

if (!defined('SMF'))
	die('No direct access...');

/**
 * Gets the opening HTML tags used for the 'url' and 'iurl' BBCodes.
 *
 * Called by:
 * 		integrate_bbc_codes
 */
function autoiurl_bbc_codes(&$codes, &$no_autolink_tags)
{
	global $context;

	if (!empty($context['autoiurl']))
		return;

	// Get the opening tags for the url and iurl BBCodes.
	// Done this way (as opposed to just hard-coding the expected strings)
	// in case other mods make any changes to these BBCodes.
	foreach ($codes as $code)
	{
		if (!in_array($code['tag'], array('url', 'iurl')))
			continue;

		if (empty($code['type']) || $code['type'] !== 'unparsed_equals')
			continue;

		if (empty($code['before']))
			continue;

		$context['autoiurl'][$code['tag']] = $code['before'];

		if (!empty($context['autoiurl']['url']) && !empty($context['autoiurl']['iurl']))
			break;
	}
}

/**
 * Removes `target="_blank" rel="noopener"` from links to internal pages.
 *
 * Called by:
 * 		integrate_post_parsebbc
 */
function autoiurl_post_parsebbc(&$message, &$smileys, &$cache_id, &$parse_tags)
{
	global $boardurl, $context;

	// Find `<a href="$1" class="bbc_link" target="_blank" rel="noopener">`
	// where `$1` is a URL that starts with $boardurl, and capture that URL.
	$pattern = str_replace('href\\="\\$1"', 'href\\="(' . preg_quote($boardurl, '~') . '\b[^"]*)"', preg_quote($context['autoiurl']['url'], '~'));

	// Replace with `<a href="$1" class="bbc_link">`, inserting the captured URL
	// as `$1` in the new string.
	$message = preg_replace('~' . $pattern . '~', $context['autoiurl']['iurl'], $message);
}

/**
 * Mention who made this thing
 *
 * Called by:
 * 		integrate_credits
 */
function autoiurl_credits()
{
	global $context;
	$context['copyrights']['mods'][] = 'Smarter Internal Links by Jon &quot;Sesquipedalian&quot; Stovell &copy; 2022';
}
