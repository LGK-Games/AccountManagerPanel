[size=x-large][b]Smarter Internal Links[/b][/size]

A modification for SMF 2.1 that causes links to pages within the forum to open in the same window by default.

In other words, this causes [nobbc][url][/nobbc] BBCode tags to be parsed as if they were [nobbc][iurl][/nobbc] BBCode tags when the link points to a URL within the forum.

This mod does not change any stored data. It just changes how that data is parsed for output.


[size=large][b]Settings[/b][/size]

There are no settings. Install to enable, uninstall to disable.


[size=large][b]License[/b][/size]

Smarter Internal Links is released under the MIT License. A full copy of this license is included in the package file.


[size=large][b]Changelog[/b][/size]

Version 1.0:
[list]
	[li]Initial release[/li]
[/list]