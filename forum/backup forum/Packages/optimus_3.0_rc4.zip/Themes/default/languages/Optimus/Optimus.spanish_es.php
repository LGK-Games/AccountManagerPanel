<?php

$txt['optimus_title'] = 'Optimización de motores de búsqueda';

$txt['optimus_tips'] = [
	'basic' => 'Search Engine Optimization (SEO) Starter Guide',
	'extra' => 'A Guide to Sharing for Webmasters',
	'favicon' => 'Define a favicon to show in search results',
	'metatags' => 'Get your website on Google',
	'robots' => 'How to write and submit a robots.txt file',
	'sitemap' => 'Build and submit a sitemap',
];

$txt['optimus_basic_title'] = 'Configuraciones básicas';
/* Arguments: OP_VERSION, php_version(), $smcFunc['db_title'], $smcFunc['db_get_version']() */
$txt['optimus_basic_desc'] = 'Versión del mod: <strong>%1$s</strong>, versión PHP: <strong>%2$s</strong>, versión %3$s: <strong>%4$s</strong>.<br>Se pueden discutir errores y características del mod en <a class="bbc_link" href="https://www.simplemachines.org/community/index.php?topic=422210.0">simplemachines.org</a>.';

$txt['optimus_main_page'] = 'Página principal';
$txt['optimus_forum_index'] = 'Título de la página de inicio del foro';
$txt['optimus_description'] = 'La descripción del foro';
$txt['optimus_description_subtext'] = 'Se utilizará como contenido de la meta etiqueta <strong>descripción</strong>.';

$txt['optimus_all_pages'] = 'Temas y páginas del foro';
$txt['optimus_board_extend_title'] = 'Agregar el nombre del foro a los títulos de los foros';
$txt['optimus_board_extend_title_set'] = ['Ninguno', 'Antes del título del foro', 'Después del título del foro'];
$txt['optimus_topic_extend_title'] = 'Agregue el título de la sección y el foro a los títulos de los temas';
$txt['optimus_topic_extend_title_set'] = ['Ninguno', 'Antes del título del tema', 'Después del título del tema'];
$txt['optimus_topic_description'] = 'Muestre el fragmento del primer mensaje del tema como la meta etiqueta <strong>descripción</strong>';
$txt['optimus_allow_change_topic_desc'] = 'Permitir un campo separado para la descripción del tema';
$txt['optimus_allow_change_topic_desc_subtext'] = 'Se muestra al editar un tema.';
$txt['optimus_allow_change_topic_keywords'] = 'Allow a separate field for the topic tags';
$txt['optimus_allow_change_topic_keywords_subtext'] = 'Se muestra al editar un tema.';
$txt['optimus_show_keywords_block'] = 'Display a block with tags above the first post of the topic';
$txt['optimus_show_keywords_on_message_index'] = 'Display tags in topic lists within boards';
$txt['optimus_use_color_tags'] = 'Use color tags';
$txt['optimus_max_allowed_tags'] = 'Maximum number of tags per topic';

$txt['optimus_extra_settings'] = 'Ajustes adicionales';
$txt['optimus_errors_for_wrong_actions'] = 'Display a 404 page for non-existent forum areas';
$txt['optimus_errors_for_wrong_boards_topics'] = 'Display a 403/404 page for inaccessible/non-existent boards and topics';
$txt['optimus_log_search'] = 'Activar el registro de los términos de búsqueda';

$txt['optimus_extra_title'] = 'Meta datos';
$txt['optimus_extra_desc'] = 'Here you can add the <a href="https://ogp.me/" target="_blank" rel="noopener" class="bbc_link">Open Graph markup</a> for forum pages.';
/* Argument: $scripturl */
$txt['optimus_extra_info'] = 'Use el <a href="https://webmaster.yandex.ru/tools/microtest/" target="_blank" rel="noopener" class="bbc_link">validador de datos estructurados</a> (Yandex.Webmaster) o <a href="https://developers.facebook.com/tools/debug" target="_blank" rel="noopener" class="bbc_link">Depurador para compartir en Facebook</a> para depurar sus etiquetas Open Graph.<hr><strong>Nota</strong>: Facebook almacena en caché imágenes y otros datos de OG. Para restablecer el caché, en el depurador de reenvío, escriba la dirección de la página con el parámetro <em>fbrefresh</em>, es decir, %1$s?fbrefresh=reset.';

$txt['optimus_og_image'] = 'Use la imagen del primer mensaje del tema en la meta etiqueta <strong>og:image</strong>';
/* Argument: $og_image_option_link */
$txt['optimus_og_image_subtext'] = 'De forma predeterminada, se utiliza la imagen especificada en la <a href="%s" class="bbc_link">configuración del tema actual</a>.';
$txt['optimus_og_image_help'] = 'If enabled, the <strong>og:image</strong> meta tag will include a link to the first image attached to the first topic message. If there are not any attachment, and the image inside the <strong>img</strong> tag is found in the message text, it is used.';
$txt['optimus_allow_change_board_og_image'] = 'Permitir un campo separado para el foro <strong>Imagen OG</strong>';
$txt['optimus_allow_change_board_og_image_subtext'] = 'Se muestra cuando se edita un foro.';
$txt['optimus_fb_appid'] = 'ID de la aplicación de Facebook (si tiene)';
$txt['optimus_fb_appid_help'] = 'Crea una aplicación <a href="https://developers.facebook.com/apps" target="_blank" rel="noopener" class="bbc_link"><strong>aquí</strong></a>, copia su ID y complete este campo.';
$txt['optimus_tw_cards'] = 'X account name (if you have)';
$txt['optimus_tw_cards_help'] = 'Read more about X Cards <a href="https://dev.twitter.com/cards/overview" target="_blank" rel="noopener" class="bbc_link"><strong>here</strong></a>.';

$txt['optimus_favicon_title'] = 'Favicon';
$txt['optimus_favicon_desc'] = 'Crea tu propio icono del foro. El navegador lo mostrará como una imagen junto a la pestaña abierta y otros elementos de la interfaz.';

$txt['optimus_favicon_text'] = 'El código del favicon';
$txt['optimus_favicon_help'] = 'Generate your own favicon <a href="https://www.favicomatic.com/" target="_blank" rel="noopener" class="bbc_link">here</a>.<br>Then upload the favicon files to the forum root, and save the code from the generator site in the field on the right.<br>This code will be load at the top of the site pages, between the &lt;head&gt;&lt;/head&gt; tags.';

$txt['optimus_meta_title'] = 'Meta etiquetas';
$txt['optimus_meta_desc'] = 'En esta página puede agregar cualquier código regular/de verificación de la lista a continuación.';

$txt['optimus_meta_addtag'] = 'Haga clic aquí para agregar una nueva etiqueta';
$txt['optimus_meta_customtag'] = 'Meta etiqueta personalizada';
$txt['optimus_meta_tools'] = 'Buscador (Herramientas)';
$txt['optimus_meta_name'] = 'Nombre';
$txt['optimus_meta_content'] = 'Contenido';
$txt['optimus_meta_info'] = 'Utilice solo los valores del parámetro <strong>content</strong> de las meta etiquetas.<br>Ejemplo: <span class="smalltext">&lt;meta name="<strong>NAME</strong>" content="<strong>VALUE</strong>"&gt;</span>';
$txt['optimus_search_engines'] = [
	'Google' => ['google-site-verification', 'https://www.google.com/webmasters/tools/', 'Google Search Console'],
	'Bing'   => ['msvalidate.01', 'https://www.bing.com/toolbox/webmaster/', 'Bing Webmaster'],
	'Yandex' => ['yandex-verification', 'https://webmaster.yandex.com/', 'Yandex.Webmaster'],
];

$txt['optimus_redirect_title'] = 'Redirect';
$txt['optimus_redirect_desc'] = 'On this page you can add redirection rules for internal forum URLs.';
$txt['optimus_redirect_info'] = 'You can specify either an internal address or an external link as the redirection "to" address.';
$txt['optimus_redirect_from'] = 'From';
$txt['optimus_redirect_to'] = 'To';
$txt['optimus_add_redirect'] = 'Add a new redirect';

$txt['optimus_counters'] = 'Contadores';
$txt['optimus_counters_desc'] = 'Puede agregar y cambiar cualquier contador en esta sección para registrar las visitas de su foro.';

$txt['optimus_head_code'] = 'Contadores invisibles con carga en el <strong>head</strong>';
$txt['optimus_head_code_subtext'] = 'Por ejemplo, <a href="https://www.google.com/analytics/sign_up.html" target="_blank" rel="noopener" class="bbc_link">Google Analytics</a>';
$txt['optimus_stat_code'] = 'Contadores invisibles con carga en el <strong>body</strong>';
$txt['optimus_stat_code_subtext'] = 'Por ejemplo, <a href="https://matomo.org/" target="_blank" rel="noopener" class="bbc_link">Matomo</a>, etc.';
$txt['optimus_count_code'] = 'Contadores visibles';
$txt['optimus_counters_css'] = 'Apariencia para contadores visibles (CSS)';
$txt['optimus_ignored_actions'] = 'Acciones ignoradas';
$txt['optimus_ignored_actions_subtext'] = '¡No se cargarán contadores en estas áreas!';

$txt['optimus_robots_title'] = 'Administrar robots.txt';
$txt['optimus_robots_desc'] = 'El generador de reglas se actualiza según las modificaciones instaladas y algunas configuraciones de su SMF.';

$txt['optimus_rules'] = 'Generador de reglas';
$txt['optimus_rules_hint'] = 'You can use these rules as an example for your robots.txt:';

$txt['optimus_htaccess_title'] = 'Administrar .htaccess';
$txt['optimus_htaccess_desc'] = 'Aquí puede modificar el archivo .htaccess para tu foro. ¡Ten cuidado!';

$txt['optimus_sitemap_title'] = 'Mapa del sitio';
/* Argument: OP_NAME */
$txt['optimus_sitemap_desc'] = '%1$s puede generar un mapa XML simple de acuerdo con la configuración a continuación.';
/* Argument: string */
$txt['optimus_sitemap_info'] = 'If you do not see recent boards or topics in the map, check the %s';
$txt['optimus_root_is_not_writable'] = 'Make sure that the forum root directory is writable!';
$txt['optimus_sitemap_enable'] = 'Activar el mapa del sitio';
$txt['optimus_sitemap_enable_subtext'] = 'El mapa se creará/actualizará después de guardar la configuración.';
$txt['optimus_sitemap_link'] = 'Mostrar el enlace del mapa del sitio en el pie de página';
$txt['optimus_remove_previous_xml_files'] = 'Quitar archivos sitemap*.xml generados anteriormente';
$txt['optimus_main_page_frequency'] = 'La frecuencia de actualización de la página principal';
$txt['optimus_main_page_frequency_set'] = ['constante (siempre)', 'Dependiendo de la fecha del último mensaje'];
$txt['optimus_sitemap_boards'] = 'Agregar enlaces a foros al mapa del sitio';
$txt['optimus_sitemap_boards_subtext'] = 'NO se agregarán los foros que esten ocultos para los invitados.';
$txt['optimus_sitemap_topics_num_replies'] = 'Agregar enlaces a temas que tengan el número de respuestas >=';
$txt['optimus_sitemap_add_found_images'] = 'Add links to detected images to the Sitemap';
$txt['optimus_sitemap_items_display'] = 'Número máximo de elementos por página';
$txt['optimus_sitemap_all_topic_pages'] = 'Agregue TODAS las páginas de temas al mapa del sitio';
$txt['optimus_sitemap_all_topic_pages_subtext'] = 'Si no se marca, solo se agregarán al mapa del sitio las primeras páginas de los temas.';
$txt['optimus_start_year'] = 'El mapa del sitio debe contener entradas a partir del año especificado';
$txt['optimus_update_frequency'] = 'Con qué frecuencia se actualiza el mapa del sitio';
$txt['optimus_update_frequency_set'] = ['Una vez al día', 'Cada 3 dias', 'Una vez por semana', 'Cada 2 semanas', 'Una vez al mes'];

$txt['optimus_mobile'] = 'Celular';
$txt['optimus_images'] = 'Imágenes';
$txt['optimus_news'] = 'Noticias';
$txt['optimus_video'] = 'Video';
$txt['optimus_index'] = 'Índice';
$txt['optimus_total_files'] = 'Total de archivos';
$txt['optimus_total_urls'] = 'URLs totales';
$txt['optimus_last_modified'] = 'Modificado por última vez';
$txt['optimus_frequency'] = 'Frecuencia';
$txt['optimus_priority'] = 'Prioridad';
$txt['optimus_direct_link'] = 'Enlace directo';
$txt['optimus_caption'] = 'Subtítulo';
$txt['optimus_thumbnail'] = 'Miniatura';

$txt['permissionname_optimus_add_descriptions'] = $txt['group_perms_name_optimus_add_descriptions'] = 'Adición de descripciones de temas';
$txt['permissionhelp_optimus_add_descriptions'] = 'Posibilidad de agregar una descripción al crear/editar un tema.';
$txt['permissionname_optimus_add_keywords'] = $txt['group_perms_name_optimus_add_keywords'] = 'Add tags for topics';
$txt['permissionhelp_optimus_add_keywords'] = 'Ability to add tags when creating/editing a topic.';
$txt['permissionname_optimus_add_descriptions_own'] = $txt['permissionname_optimus_add_keywords_own'] = 'Tema propio';
$txt['permissionname_optimus_add_descriptions_any'] = $txt['permissionname_optimus_add_keywords_any'] = 'Cualquier tema';
$txt['group_perms_name_optimus_add_descriptions_own'] = 'Agregar descripciones para temas propios';
$txt['group_perms_name_optimus_add_descriptions_any'] = 'Agregar descripciones para cualquier tema';
$txt['permissionname_optimus_view_search_terms'] = $txt['group_perms_name_optimus_view_search_terms'] = 'Ver las estadísticas de los términos de búsqueda';
$txt['permissionhelp_optimus_view_search_terms'] = 'Posibilidad de ver estadísticas de búsqueda en el foro.';

$txt['optimus_404_page_title'] = '404 - Pagina no encontrada';
$txt['optimus_404_h2'] = 'Error 404';
$txt['optimus_404_h3'] = 'The requested page does not exist.';
$txt['optimus_403_page_title'] = '403 - Acceso Prohibido';
$txt['optimus_403_h2'] = 'Error 403';
$txt['optimus_403_h3'] = 'You have no access to this page.';
/* Argument: $scripturl */
$txt['optimus_goto_main_page'] = 'Vaya a la <a class="bbc_link" href="%1$s">página principal</a>.';
$txt['optimus_seo_description'] = 'Description';
$txt['optimus_enter_description'] = 'Enter a short description of this topic';
$txt['optimus_seo_keywords'] = 'Tags';
$txt['optimus_enter_keywords'] = 'Enter one or more tags';
/* Argument: $keyword_name */
$txt['optimus_topics_with_keyword'] = 'Forum topics with tag "%s"';
$txt['optimus_keyword_id_not_found'] = 'The specified tag ID was not found.';
$txt['optimus_no_keywords'] = 'There is no information about this tag identifier.';
$txt['optimus_all_keywords'] = 'All tags in the forum topics';
$txt['optimus_keyword_column'] = 'Tag';
$txt['optimus_frequency_column'] = 'Frecuencia';
$txt['optimus_top_queries'] = 'Consultas de búsqueda populares';
/* Argument: $i  */
$txt['optimus_chart_title'] = 'Top %1$s';
$txt['optimus_no_search_terms'] = 'Las estadísticas aún no están disponibles.';
