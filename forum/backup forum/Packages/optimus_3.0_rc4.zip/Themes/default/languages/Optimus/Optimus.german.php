<?php

$txt['optimus_title'] = 'Suchmaschinenoptimierung (SEO)';

$txt['optimus_tips'] = [
	'basic' => 'Search Engine Optimization (SEO) Starter Guide',
	'extra' => 'A Guide to Sharing for Webmasters',
	'favicon' => 'Define a favicon to show in search results',
	'metatags' => 'Get your website on Google',
	'robots' => 'How to write and submit a robots.txt file',
	'sitemap' => 'Build and submit a sitemap',
];

$txt['optimus_basic_title'] = 'Grundeinstellungen';
/* Arguments: OP_VERSION, php_version(), $smcFunc['db_title'], $smcFunc['db_get_version']() */
$txt['optimus_basic_desc'] = 'Version der Mod: <strong>%1$s</strong>, PHP-Version: <strong>%2$s</strong>, %3$s-Version: <strong>%4$s</strong>.<br>Bugs und Features der Mod können unter <a class="bbc_link" href="https://www.simplemachines.org/community/index.php?topic=422210.0">simplemachines.org</a> diskutiert werden.';

$txt['optimus_main_page'] = 'Startseite';
$txt['optimus_forum_index'] = 'Titel der Forumsstartseite';
$txt['optimus_description'] = 'Forumsbeschreibung';
$txt['optimus_description_subtext'] = 'Sie wird als Inhalt des Meta-Tags <strong>description</strong> verwendet werden.';

$txt['optimus_all_pages'] = 'Themen- und Board-Seiten';
$txt['optimus_board_extend_title'] = 'Füge Forumsnamen zu Board-Titeln hinzu';
$txt['optimus_board_extend_title_set'] = ['Nicht hinzufügen', 'Vor dem Board-Titel', 'Nach dem Board-Titel'];
$txt['optimus_topic_extend_title'] = 'Füge Titel von Sektion und Forum zu Thementiteln hinzu';
$txt['optimus_topic_extend_title_set'] = ['Nicht hinzufügen', 'Vor dem Themen-Titel', 'Nach dem Themen-Titel'];
$txt['optimus_topic_description'] = 'Zeige das Snippet des ersten Beitrags eines Themas als Meta-Tag <strong>description</strong>';
$txt['optimus_allow_change_topic_desc'] = 'Erlaube ein separates Feld für die Themenbeschreibung';
$txt['optimus_allow_change_topic_desc_subtext'] = 'Es wird angezeigt, wenn ein Thema bearbeitet wird.';
$txt['optimus_allow_change_topic_keywords'] = 'Allow a separate field for the topic tags';
$txt['optimus_allow_change_topic_keywords_subtext'] = 'Es wird angezeigt, wenn ein Thema bearbeitet wird.';
$txt['optimus_show_keywords_block'] = 'Display a block with tags above the first post of the topic';
$txt['optimus_show_keywords_on_message_index'] = 'Display tags in topic lists within boards';
$txt['optimus_use_color_tags'] = 'Use color tags';
$txt['optimus_max_allowed_tags'] = 'Maximum number of tags per topic';

$txt['optimus_extra_settings'] = 'Weitere Einstellungen';
$txt['optimus_errors_for_wrong_actions'] = 'Display a 404 page for non-existent forum areas';
$txt['optimus_errors_for_wrong_boards_topics'] = 'Display a 403/404 page for inaccessible/non-existent boards and topics';
$txt['optimus_log_search'] = 'Erlaube das Loggen von Suchbegriffen';

$txt['optimus_extra_title'] = 'Metadaten';
$txt['optimus_extra_desc'] = 'Here you can add the <a href="https://ogp.me/" target="_blank" rel="noopener" class="bbc_link">Open Graph markup</a> for forum pages.';
/* Argument: $scripturl */
$txt['optimus_extra_info'] = 'Verwenden Sie <a href="https://webmaster.yandex.ru/tools/microtest/" target="_blank" rel="noopener" class="bbc_link">structured data validator</a> (Yandex.Webmaster) oder <a href="https://developers.facebook.com/tools/debug" target="_blank" rel="noopener" class="bbc_link">Facebook Sharing Debugger</a>, um Fehler in Ihren Open-Graph-Tags zu finden und zu beseitigen.<hr><strong>Hinweis</strong>: Facebook cacht Bilder und andere OG-Daten. Um diesen Cache zurückzusetzen, geben Sie die Seitenadresse mit dem Parameter <em>fbrefresh</em> im Repost-Debugger ein, z.B. %1$s?fbrefresh=reset.';

$txt['optimus_og_image'] = 'Verwende das Bild des ersten Beitrags eines Themas im Meta-Tag <strong>og:image</strong>';
/* Argument: $og_image_option_link */
$txt['optimus_og_image_subtext'] = 'Standardmäßig wird das Bild verwendet, das in den <a href="%s" class="bbc_link">aktuellen Theme-Einstellungen</a> angegeben ist.';
$txt['optimus_og_image_help'] = 'Falls aktiviert, enthält das <strong>og:image</strong>-Meta-Tag einen Link zum ersten Bild, das an den ersten Themenbeitrag angehängt ist. Falls es keine Anhänge gibt, und ein Bild in  <strong>img</strong>-Tags im Beitragstext gefunden wird, wird dieses verwendet.';
$txt['optimus_allow_change_board_og_image'] = 'Erlaubt ein separates Feld für das <strong>OG-Image</strong> des Boards';
$txt['optimus_allow_change_board_og_image_subtext'] = 'Es wird angezeigt, wenn ein Board bearbeitet wird.';
$txt['optimus_fb_appid'] = 'Facebook-Application-ID (falls Sie eine haben)';
$txt['optimus_fb_appid_help'] = 'Erzeugen Sie eine Anwendung <a href="https://developers.facebook.com/apps" target="_blank" rel="noopener" class="bbc_link"><strong>hier</strong></a>, kopieren Sie deren ID und geben Sie sie in dieses Feld ein.';
$txt['optimus_tw_cards'] = 'X account name (if you have)';
$txt['optimus_tw_cards_help'] = 'Read more about X Cards <a href="https://dev.twitter.com/cards/overview" target="_blank" rel="noopener" class="bbc_link"><strong>here</strong></a>.';

$txt['optimus_favicon_title'] = 'Favicon';
$txt['optimus_favicon_desc'] = 'Erzeugen Sie Ihr eigenes Forumssymbol. Es wird vom Browser als Bild neben dem geöffneten Tab und anderen Interface-Elementen angezeigt.';

$txt['optimus_favicon_text'] = 'Der Favicon-Code';
$txt['optimus_favicon_help'] = 'Generate your own favicon <a href="https://www.favicomatic.com/" target="_blank" rel="noopener" class="bbc_link">here</a>.<br>Then upload the favicon files to the forum root, and save the code from the generator site in the field on the right.<br>This code will be load at the top of the site pages, between the &lt;head&gt;&lt;/head&gt; tags.';

$txt['optimus_meta_title'] = 'Meta-Tags';
$txt['optimus_meta_desc'] = 'Auf dieser Seite können Sie beliebige reguläre/Verifizierungs-Codes aus der Liste unten hinzufügen.';

$txt['optimus_meta_addtag'] = 'Klicken Sie hier, um ein neues Tag hinzuzufügen';
$txt['optimus_meta_customtag'] = 'Benutzerdefiniertes Meta-Tag';
$txt['optimus_meta_tools'] = 'Suchmaschine (Werkzeug)';
$txt['optimus_meta_name'] = 'Name';
$txt['optimus_meta_content'] = 'Inhalt';
$txt['optimus_meta_info'] = 'Bitte nutzen Sie ausschließlich die Werte des <strong>content</strong>-Parameters der Meta-Tags.<br>Beispiel: <span class="smalltext">&lt;meta name="<strong>NAME</strong>" content="<strong>VALUE</strong>"&gt;</span>';
$txt['optimus_search_engines'] = [
	'Google' => ['google-site-verification', 'https://www.google.com/webmasters/tools/', 'Google-Such-Konsole'],
	'Bing'   => ['msvalidate.01', 'https://www.bing.com/toolbox/webmaster/', 'Bing Webmaster'],
	'Yandex' => ['yandex-verification', 'https://webmaster.yandex.com/', 'Yandex.Webmaster'],
];

$txt['optimus_redirect_title'] = 'Redirect';
$txt['optimus_redirect_desc'] = 'On this page you can add redirection rules for internal forum URLs.';
$txt['optimus_redirect_info'] = 'You can specify either an internal address or an external link as the redirection "to" address.';
$txt['optimus_redirect_from'] = 'From';
$txt['optimus_redirect_to'] = 'To';
$txt['optimus_add_redirect'] = 'Add a new redirect';

$txt['optimus_counters'] = 'AdSense/JS-Code';
$txt['optimus_counters_desc'] = 'Sie können beliebigen JS-Code in diesem Abschnitt hinzufügen oder ändern, um Statistiken/Aufrufe Ihres Forums zu protokollieren.';

$txt['optimus_head_code'] = 'Unsichtbares JS durch Laden im <strong>head</strong>-Abschnitt';
$txt['optimus_head_code_subtext'] = 'Zum Beispiel <a href="https://www.google.com/analytics/sign_up.html" target="_blank" rel="noopener" class="bbc_link">Google Analytics</a> oder <a href="https://www.google.com/adsense/start/" target="_blank" rel="noopener" class="bbc_link">Google AdSense</a>';
$txt['optimus_stat_code'] = 'Unsichtbares JS durch Laden im <strong>body</strong>-Abschnitt';
$txt['optimus_stat_code_subtext'] = 'Zum Beispiel <a href="https://matomo.org/" target="_blank" rel="noopener" class="bbc_link">Matomo</a>, etc.';
$txt['optimus_count_code'] = 'Sichtbares JS (Bild-Counter, Banner, etc.)';
$txt['optimus_counters_css'] = 'Erscheinungsbild für sichtbare Zähler (CSS-Code)';
$txt['optimus_ignored_actions'] = 'Ignorierte Aktionen';
$txt['optimus_ignored_actions_subtext'] = 'Zähler werden in diesen Bereichen nicht geladen!';

$txt['optimus_robots_title'] = 'robots.txt verwalten';
$txt['optimus_robots_desc'] = 'Der Regelgenerator wird aktualisiert abhängig von den installierten Mods und einigen SMF-Einstellungen.';

$txt['optimus_rules'] = 'Regelgenerator';
$txt['optimus_rules_hint'] = 'You can use these rules as an example for your robots.txt:';

$txt['optimus_htaccess_title'] = '.htaccess verwalten';
$txt['optimus_htaccess_desc'] = 'Hier können Sie die .htaccess-Datei ihres Forums bearbeiten. Seien Sie vorsichtig!';

$txt['optimus_sitemap_title'] = 'Sitemap';
/* Argument: OP_NAME */
$txt['optimus_sitemap_desc'] = '%1$s kann eine einfache XML-Map in Übereinstimmung mit den Einstellungen unterhalb generieren.';
/* Argument: string */
$txt['optimus_sitemap_info'] = 'If you do not see recent boards or topics in the map, check the %s';
$txt['optimus_root_is_not_writable'] = 'Make sure that the forum root directory is writable!';
$txt['optimus_sitemap_enable'] = 'Sitemap aktivieren';
$txt['optimus_sitemap_enable_subtext'] = 'Die Map wird nach dem Speichern der Einstellungen erzeugt/aktualisiert.';
$txt['optimus_sitemap_link'] = 'Sitemap-Link im Footer anzeigen';
$txt['optimus_remove_previous_xml_files'] = 'Zuvor generierte sitemap*.xml-Dateien entfernen';
$txt['optimus_main_page_frequency'] = 'Die Aktualisierungshäufigkeit der Hauptseite';
$txt['optimus_main_page_frequency_set'] = ['Konstant (immer)', 'Abhängig vom Datum des letzten Beitrags'];
$txt['optimus_sitemap_boards'] = 'Links auf Boards zur Sitemap hinzufügen';
$txt['optimus_sitemap_boards_subtext'] = 'Boards, die für Gäste nicht zugänglich sind, werden NICHT hinzugefügt.';
$txt['optimus_sitemap_topics_num_replies'] = 'Links auf Themen hinzufügen, die mindestens diese Anzahl Antworten haben';
$txt['optimus_sitemap_add_found_images'] = 'Add links to detected images to the Sitemap';
$txt['optimus_sitemap_items_display'] = 'Maximale Anzahl von Elementen pro Seite';
$txt['optimus_sitemap_all_topic_pages'] = 'ALLE Themenseiten zur Sitemap hinzufügen';
$txt['optimus_sitemap_all_topic_pages_subtext'] = 'Falls nicht ausgewählt, werden nur die ersten Seiten von Themen zur Sitemap hinzugefügt.';
$txt['optimus_start_year'] = 'Die Sitemap soll Einträge beginnend mit dem angegebenen Jahr enthalten';
$txt['optimus_update_frequency'] = 'Wie oft die Sitemap aktualisiert wird';
$txt['optimus_update_frequency_set'] = ['Einmal pro Tag', 'Alle 3 Tage', 'Einmal pro Woche', 'Alle 2 Wochen', 'Einmal pro Monat'];

$txt['optimus_mobile'] = 'Handy';
$txt['optimus_images'] = 'Bilder';
$txt['optimus_news'] = 'Nachrichten';
$txt['optimus_video'] = 'Video';
$txt['optimus_index'] = 'Index';
$txt['optimus_total_files'] = 'Gesamtanzahl Dateien';
$txt['optimus_total_urls'] = 'Gesamtanzahl URLs';
$txt['optimus_last_modified'] = 'Letzte Änderung';
$txt['optimus_frequency'] = 'Häufigkeit';
$txt['optimus_priority'] = 'Priorität';
$txt['optimus_direct_link'] = 'Direktlink';
$txt['optimus_caption'] = 'Bildunterschrift';
$txt['optimus_thumbnail'] = 'Vorschaubild';

$txt['permissionname_optimus_add_descriptions'] = $txt['group_perms_name_optimus_add_descriptions'] = 'Beschreibungen für Themen hinzufügen';
$txt['permissionhelp_optimus_add_descriptions'] = 'Die Fähigkeit, beim Erzeugen/Bearbeiten eines Themas eine Beschreibung hinzuzufügen.';
$txt['permissionname_optimus_add_keywords'] = $txt['group_perms_name_optimus_add_keywords'] = 'Add tags for topics';
$txt['permissionhelp_optimus_add_keywords'] = 'Ability to add tags when creating/editing a topic.';
$txt['permissionname_optimus_add_descriptions_own'] = $txt['permissionname_optimus_add_keywords_own'] = 'Eigenes Thema';
$txt['permissionname_optimus_add_descriptions_any'] = $txt['permissionname_optimus_add_keywords_any'] = 'Beliebiges Thema';
$txt['group_perms_name_optimus_add_descriptions_own'] = 'Beschreibungen für eigene Themen hinzufügen';
$txt['group_perms_name_optimus_add_descriptions_any'] = 'Beschreibungen für beliebige Themen hinzufügen';
$txt['permissionname_optimus_view_search_terms'] = $txt['group_perms_name_optimus_view_search_terms'] = 'Die Suchbegriffstatistiken ansehen';
$txt['permissionhelp_optimus_view_search_terms'] = 'Die Fähigkeit, Suchstatistiken des Forums anzusehen.';

$txt['optimus_404_page_title'] = '404 – Seite nicht gefunden';
$txt['optimus_404_h2'] = 'Fehler 404';
$txt['optimus_404_h3'] = 'The requested page does not exist.';
$txt['optimus_403_page_title'] = '403 – Zugriff verweigert';
$txt['optimus_403_h2'] = 'Fehler 403';
$txt['optimus_403_h3'] = 'You have no access to this page.';
/* Argument: $scripturl */
$txt['optimus_goto_main_page'] = 'Zur <a class="bbc_link" href="%1$s">Hauptseite</a>.';
$txt['optimus_seo_description'] = 'Description';
$txt['optimus_enter_description'] = 'Enter a short description of this topic';
$txt['optimus_seo_keywords'] = 'Tags';
$txt['optimus_enter_keywords'] = 'Enter one or more tags';
/* Argument: $keyword_name */
$txt['optimus_topics_with_keyword'] = 'Forum topics with tag "%s"';
$txt['optimus_keyword_id_not_found'] = 'The specified tag ID was not found.';
$txt['optimus_no_keywords'] = 'There is no information about this tag identifier.';
$txt['optimus_all_keywords'] = 'All tags in the forum topics';
$txt['optimus_keyword_column'] = 'Tag';
$txt['optimus_frequency_column'] = 'Häufigkeit';
$txt['optimus_top_queries'] = 'Beliebte Suchanfragen';
/* Argument: $i  */
$txt['optimus_chart_title'] = 'Top %1$s';
$txt['optimus_no_search_terms'] = 'Es sind noch keine Statistiken verfügbar.';
