<?php

$txt['optimus_title'] = 'Ottimizzazioni per i motori di ricerca';

$txt['optimus_tips'] = [
	'basic' => 'Guida introduttiva all\'ottimizzazione per i motori di ricerca (SEO).',
	'extra' => 'Una guida per i webmaster',
	'favicon' => 'Definisci una favicon da mostrare nei risultati di ricerca',
	'metatags' => 'Aggiungi il tuo sito web a Google',
	'robots' => 'Come scrivere e inviare un file robots.txt',
	'sitemap' => 'Costruisci e invia una sitemap',
];

$txt['optimus_basic_title'] = 'Impostazioni base';
/* Arguments: OP_VERSION, php_version(), $smcFunc['db_title'], $smcFunc['db_get_version']() */
$txt['optimus_basic_desc'] = 'Versione mod: <strong>%1$s</strong>, versione PHP: <strong>%2$s</strong>, versione %3$s: <strong>%4$s</strong>.<br>Puoi chiedere supporto, nuove features o segnalare bugs su <a class="bbc_link" href="https://www.simplemachines.org/community/index.php?topic=422210.0">simplemachines.org</a>.';

$txt['optimus_main_page'] = 'Pagina principale';
$txt['optimus_forum_index'] = 'Titolo della pagina principale';
$txt['optimus_description'] = 'Descrizione del Forum';
$txt['optimus_description_subtext'] = 'Verrà utilizzato come contenuto del meta-tag <strong>description</strong>.';

$txt['optimus_all_pages'] = 'Discussioni & pagine delle sezioni';
$txt['optimus_board_extend_title'] = 'Aggiungi il nome del forum nei titoli delle sezioni';
$txt['optimus_board_extend_title_set'] = ['Non aggiungere', 'Prima del titolo della sezione', 'Dopo il titolo della sezione'];
$txt['optimus_topic_extend_title'] = 'Aggiungi il titolo della sezione e del forum nel titolo della discussione';
$txt['optimus_topic_extend_title_set'] = ['Non aggiungere', 'Prima del titolo della discussione', 'Dopo il titolo della discussione'];
$txt['optimus_topic_description'] = 'Visualizza la parte del primo messaggio della discussione nel metatag <strong>description</strong>';
$txt['optimus_allow_change_topic_desc'] = 'Abilita un campo separato per la descrizione della discussione';
$txt['optimus_allow_change_topic_desc_subtext'] = 'Viene visualizzato durante la modifica di una discussione.';
$txt['optimus_allow_change_topic_keywords'] = 'Abilita un campo separato per i tag della discussione';
$txt['optimus_allow_change_topic_keywords_subtext'] = 'Viene visualizzato durante la modifica di una discussione.';
$txt['optimus_show_keywords_block'] = 'Visualizza un blocco con i tag sopra il primo messaggio della discussione';
$txt['optimus_show_keywords_on_message_index'] = 'Visualizza i tag nella lista delle discussioni all\'interno delle sezioni';
$txt['optimus_use_color_tags'] = 'Usa tags colorati';
$txt['optimus_max_allowed_tags'] = 'Numero massimo di tag per discussione';

$txt['optimus_extra_settings'] = 'Impostazioni aggiuntive';
$txt['optimus_errors_for_wrong_actions'] = 'Visualizza una pagina 404 per le aree del forum che non esistono';
$txt['optimus_errors_for_wrong_boards_topics'] = 'Visualizza una pagina 403/404 per le sezioni e le discussioni che non esistono o non si ha accesso';
$txt['optimus_log_search'] = 'Abilita la registrazione dei termini di ricerca';

$txt['optimus_extra_title'] = 'Metadata';
$txt['optimus_extra_desc'] = 'Qui puoi aggiungere il <a href="https://ogp.me/" target="_blank" rel="noopener" class="bbc_link">markup Open Graph</a> per le pagine del forum. ';
/* Argument: $scripturl */
$txt['optimus_extra_info'] = 'Utilizza il <a href="https://webmaster.yandex.ru/tools/microtest/" target="_blank" rel="noopener" class="bbc_link">convalidatore di dati strutturati</a> (Yandex.Webmaster) o il <a href="https://developers.facebook.com/tools/debug" target="_blank" rel="noopener" class="bbc_link">Debugger di condivisione di Facebook</a> per eseguire il debug dei tag Open Graph.<hr><strong>Nota</strong>: Facebook memorizza nella cache immagini e altri dati OG. Per resettare la cache, nel repost debugger, digita l\'indirizzo della pagina con il parametro <em>fbrefresh</em>, ad esempio %1$s?fbrefresh=reset.';

$txt['optimus_og_image'] = 'Utilizza l\'immagine del primo messaggio della discussione nel meta tag <strong>og:image</strong>';
/* Argument: $og_image_option_link */
$txt['optimus_og_image_subtext'] = 'Per impostazione predefinita, viene utilizzata l\'immagine specificata nelle <a href="%s" class="bbc_link">impostazioni correnti del tema</a>.';
$txt['optimus_og_image_help'] = 'Se abilitato, il meta tag <strong>og:image</strong> includerà un collegamento alla prima immagine allegata al primo messaggio della discussione. Se non sono presenti allegati e l\'immagine all\'interno del tag <strong>img</strong> si trova nel testo del messaggio, viene utilizzata.';
$txt['optimus_allow_change_board_og_image'] = 'Consenti un campo separato <strong>OG Image</strong> per il forum';
$txt['optimus_allow_change_board_og_image_subtext'] = 'Viene visualizzato durante la modifica di una discussione.';
$txt['optimus_fb_appid'] = 'ID Applicazione Facebook (Se disponibile)';
$txt['optimus_fb_appid_help'] = 'Crea un\'applicazione <a href="https://developers.facebook.com/apps" target="_blank" rel="noopener" class="bbc_link"><strong>qui</strong></a>, copia il suo ID e compila questo campo.';
$txt['optimus_tw_cards'] = 'Nome account X (Se disponibile)';
$txt['optimus_tw_cards_help'] = 'Puoi saperne di più sulle card di X <a href="https://dev.twitter.com/cards/overview" target="_blank" rel="noopener" class="bbc_link"><strong>qui</strong></a>.';

$txt['optimus_favicon_title'] = 'Favicon';
$txt['optimus_favicon_desc'] = 'Crea la tua icona del forum. Verrà visualizzato dal browser come immagine accanto alla scheda aperta e ad altri elementi dell\'interfaccia.';

$txt['optimus_favicon_text'] = 'Codice favicon';
$txt['optimus_favicon_help'] = 'Genera la tua favicon <a href="https://www.favicomatic.com/" target="_blank" rel="noopener" class="bbc_link">qui</a>.<br>Quindi carica i file delle favicon alla radice del forum e salva il codice dal sito generatore nel campo a destra.<br>Questo codice verrà caricato nella parte superiore delle pagine del sito, tra i tag &lt;head&gt;&lt;/head&gt;.';

$txt['optimus_meta_title'] = 'Meta tags';
$txt['optimus_meta_desc'] = 'In questa pagina puoi aggiungere qualsiasi codice regular/verification dall\'elenco seguente.';

$txt['optimus_meta_addtag'] = 'Clicca qui per aggiungere un nuovo tag';
$txt['optimus_meta_customtag'] = 'Meta tag personale';
$txt['optimus_meta_tools'] = 'Motore di ricerca (Strumento)';
$txt['optimus_meta_name'] = 'Name';
$txt['optimus_meta_content'] = 'Content';
$txt['optimus_meta_info'] = 'Utilizza solo i valori del parametro <strong>content</strong> dei meta tag.<br>Esempio: <span class="smalltext">&lt;meta name="<strong>NAME</strong>" content= "<strong>VALORE</strong>"&gt;</span>';
$txt['optimus_search_engines'] = [
	'Google' => ['google-site-verification', 'https://www.google.com/webmasters/tools/', 'Google Search Console'],
	'Bing'   => ['msvalidate.01', 'https://www.bing.com/toolbox/webmaster/', 'Bing Webmaster'],
	'Yandex' => ['yandex-verification', 'https://webmaster.yandex.com/', 'Yandex.Webmaster'],
];

$txt['optimus_redirect_title'] = 'Reindirizzamento';
$txt['optimus_redirect_desc'] = 'In questa pagina puoi aggiungere nuovi reindirizzamenti per gli URL interni del forum.';
$txt['optimus_redirect_info'] = 'È possibile specificare un indirizzo interno o un collegamento esterno come indirizzo di reindirizzamento "a".';
$txt['optimus_redirect_from'] = 'Da';
$txt['optimus_redirect_to'] = 'A';
$txt['optimus_add_redirect'] = 'Aggiungi un nuovo reindirizzamento';

$txt['optimus_counters'] = 'AdSense/Codice JS';
$txt['optimus_counters_desc'] = 'Puoi aggiungere e modificare qualsiasi codice JS in questa sezione per registrare statistiche/visite al tuo forum.';

$txt['optimus_head_code'] = 'JS invisibile con caricamento nella sezione <strong>head</strong>';
$txt['optimus_head_code_subtext'] = 'As esempio, <a href="https://www.google.com/analytics/sign_up.html" target="_blank" rel="noopener" class="bbc_link">Google Analytics</a>, o <a href="https://www.google.com/adsense/start/" target="_blank" rel="noopener" class="bbc_link">Google AdSense</a>';
$txt['optimus_stat_code'] = 'JS invisibile con caricamento nella sezione <strong>body</strong>';
$txt['optimus_stat_code_subtext'] = 'Ad esempio, <a href="https://matomo.org/" target="_blank" rel="noopener" class="bbc_link">Matomo</a>';
$txt['optimus_count_code'] = 'JS visibile (immagini contatori, banner, ecc.)';
$txt['optimus_counters_css'] = 'Aspetto per i contatori visibili (codice CSS)';
$txt['optimus_ignored_actions'] = 'Actions ignorate';
$txt['optimus_ignored_actions_subtext'] = 'I contatori non verranno caricati in queste aree!';

$txt['optimus_robots_title'] = 'Gestisci robots.txt';
$txt['optimus_robots_desc'] = 'Il generatore di regole viene aggiornato in base alle mod installate e ad alcune impostazioni del tuo forum SMF.';

$txt['optimus_rules'] = 'Generatore regole';
$txt['optimus_rules_hint'] = 'Puoi utilizzare queste regole come esempio per il tuo robots.txt:';

$txt['optimus_htaccess_title'] = 'Gestisci .htaccess';
$txt['optimus_htaccess_desc'] = 'Qui puoi modificare il file .htaccess  del tuo forum. Fai attenzione!';

$txt['optimus_sitemap_title'] = 'Sitemap';
/* Argument: OP_NAME */
$txt['optimus_sitemap_desc'] = '%1$s può generare una semplice mappa XML in base alle impostazioni seguenti.';
/* Argument: string */
$txt['optimus_sitemap_info'] = 'Se non vedi le bacheche o le discussioni recenti nella mappa, controlla %s';
$txt['optimus_root_is_not_writable'] = 'Verifica che la cartella principale del forum sia scrivibile!';
$txt['optimus_sitemap_enable'] = 'Attiva la Sitemap';
$txt['optimus_sitemap_enable_subtext'] = 'La mappa verra creata/aggiornata dopo il salvataggio della impostazioni.';
$txt['optimus_sitemap_link'] = 'Visualizza un link alla Sitemap in fondo al forum';
$txt['optimus_remove_previous_xml_files'] = 'Rimuovi files sitemap*.xml creati precedentemente';
$txt['optimus_main_page_frequency'] = 'La frequenza di aggiornamento della pagina principale';
$txt['optimus_main_page_frequency_set'] = ['Costante (sempre)', 'Dipendente dalla data dell\'ultimo messaggio'];
$txt['optimus_sitemap_boards'] = 'Aggiungi i link alle sezioni del forum nella Sitemap';
$txt['optimus_sitemap_boards_subtext'] = 'Le sezioni chiuse a visitatori NON verranno aggiunte.';
$txt['optimus_sitemap_topics_num_replies'] = 'Aggiungi link alle discussioni che hanno il numero di risposte maggiori o uguali a';
$txt['optimus_sitemap_add_found_images'] = 'Aggiungi link alle immagini rilevate nella Sitemap';
$txt['optimus_sitemap_items_display'] = 'Numero massimo di link per pagina';
$txt['optimus_sitemap_all_topic_pages'] = 'Aggiunge TUTTE le pagine delle discussioni nella sitemap';
$txt['optimus_sitemap_all_topic_pages_subtext'] = 'Se non selezionato, solo la prima pagina della discussione verrà agggiunta alla sitemap.';
$txt['optimus_start_year'] = 'La Sitemap deve contenere link a partire dall\'anno specificato';
$txt['optimus_update_frequency'] = 'Con quale frequenza viene aggiornata la Sitemap';
$txt['optimus_update_frequency_set'] = ['Una volta al giorno', 'Ogni 3 giorni', 'Una volta a settimana', 'Ogni 2 settimane', 'Una volta al mese'];

$txt['optimus_mobile'] = 'Mobile';
$txt['optimus_images'] = 'Immagini';
$txt['optimus_news'] = 'Notizie';
$txt['optimus_video'] = 'Video';
$txt['optimus_index'] = 'Indice';
$txt['optimus_total_files'] = 'Files totali';
$txt['optimus_total_urls'] = 'URLs totali';
$txt['optimus_last_modified'] = 'Ultima modifica';
$txt['optimus_frequency'] = 'Frequenza';
$txt['optimus_priority'] = 'Priorità';
$txt['optimus_direct_link'] = 'Link diretto';
$txt['optimus_caption'] = 'Didascalia';
$txt['optimus_thumbnail'] = 'Anteprima';

$txt['permissionname_optimus_add_descriptions'] = $txt['group_perms_name_optimus_add_descriptions'] = 'Aggiunta descrizione per le discussioni';
$txt['permissionhelp_optimus_add_descriptions'] = 'Abilita la possibilità di aggiungere una descrizione durante la creazione/modifica di una discussione.';
$txt['permissionname_optimus_add_keywords'] = $txt['group_perms_name_optimus_add_keywords'] = 'Aggiungi tag per discussione';
$txt['permissionhelp_optimus_add_keywords'] = 'Abilita la possibilità di aggiungere i tag durante la creazione/modifica di una discussione.';
$txt['permissionname_optimus_add_descriptions_own'] = $txt['permissionname_optimus_add_keywords_own'] = 'Propria discussione';
$txt['permissionname_optimus_add_descriptions_any'] = $txt['permissionname_optimus_add_keywords_any'] = 'Tutte le discussioni';
$txt['group_perms_name_optimus_add_descriptions_own'] = 'Aggiungere descrizioni per le proprie discussioni';
$txt['group_perms_name_optimus_add_descriptions_any'] = 'Aggiungere descrizioni in tutte le discussioni';
$txt['permissionname_optimus_view_search_terms'] = $txt['group_perms_name_optimus_view_search_terms'] = 'Visualizza le statistiche dei termini cercati';
$txt['permissionhelp_optimus_view_search_terms'] = 'Abilita la visualizzazione delle statistiche di ricerca nel forum.';

$txt['optimus_404_page_title'] = '404 - Pagina non trovata';
$txt['optimus_404_h2'] = 'Errore 404';
$txt['optimus_404_h3'] = 'La pagina richiesta non esiste';
$txt['optimus_403_page_title'] = '403 - Accesso Proibito';
$txt['optimus_403_h2'] = 'Errore 403';
$txt['optimus_403_h3'] = 'Non hai accesso a questa pagina.';
/* Argument: $scripturl */
$txt['optimus_goto_main_page'] = 'Vai alla <a class="bbc_link" href="%1$s">pagina principale</a>.';
$txt['optimus_seo_description'] = 'Descrizione';
$txt['optimus_enter_description'] = 'Inserisci una descrizione per questa discussione';
$txt['optimus_seo_keywords'] = 'Tags';
$txt['optimus_enter_keywords'] = 'Inserisci una o più tag';
/* Argument: $keyword_name */
$txt['optimus_topics_with_keyword'] = 'Discussioni con il tag "%s"';
$txt['optimus_keyword_id_not_found'] = 'Il tag specificato non è stata trovato.';
$txt['optimus_no_keywords'] = 'Non c\'è nessuna informazione riguardo questo tag.';
$txt['optimus_all_keywords'] = 'Tutti i tag nelle discussioni del forum';
$txt['optimus_keyword_column'] = 'Tag';
$txt['optimus_frequency_column'] = 'Frequenza';
$txt['optimus_top_queries'] = 'Termini di ricerca più popolari';
/* Argument: $i  */
$txt['optimus_chart_title'] = 'Top %1$s';
$txt['optimus_no_search_terms'] = 'Le statistiche non sono ancora disponibili.';
