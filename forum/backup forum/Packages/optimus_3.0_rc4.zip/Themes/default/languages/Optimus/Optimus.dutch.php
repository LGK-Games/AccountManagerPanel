<?php

$txt['optimus_title'] = 'Zoekmachine optimalisatie';

$txt['optimus_tips'] = [
	'basic' => 'Zoekmachine optimalisatie Snelstart gids',
	'extra' => 'Gids voor delen voor webmasters',
	'favicon' => 'Definieer een favicon om te tonen in zoekresultaten',
	'metatags' => 'Je website in Google krijgen',
	'robots' => 'Het schrijven en insturen van een robots.txt bestand',
	'sitemap' => 'Het bouwen en insturen van een sitemap',
];

$txt['optimus_basic_title'] = 'Algemene instellingen';
/* Arguments: OP_VERSION, php_version(), $smcFunc['db_title'], $smcFunc['db_get_version']() */
$txt['optimus_basic_desc'] = 'Versie van de Mod: <strong>%1$s</strong>, PHP versie: <strong>%2$s</strong>, %3$s versie: <strong>%4$s</strong>.<br>Bugs en features van de mod kunnen besproken worden op <a class="bbc_link" href="https://www.simplemachines.org/community/index.php?topic=422210.0">simplemachines.org</a>.';

$txt['optimus_main_page'] = 'Startpagina';
$txt['optimus_forum_index'] = 'Forum startpagina titel';
$txt['optimus_description'] = 'Forum beschrijving';
$txt['optimus_description_subtext'] = 'Wordt gebruikt als inhoud van de meta-tag <strong>description</strong>.';

$txt['optimus_all_pages'] = 'Topic & board paginas';
$txt['optimus_board_extend_title'] = 'Voeg forumnaam toe aan board titels';
$txt['optimus_board_extend_title_set'] = ['Niet toevoegen', 'Voor board titel', 'Na board titel'];
$txt['optimus_topic_extend_title'] = 'Voeg categorie en boardnaam toe aan topic titels';
$txt['optimus_topic_extend_title_set'] = ['Niet toevoegen', 'Voor topic titel', 'Na topic titel'];
$txt['optimus_topic_description'] = 'Gebruik het eerste bericht van het topic als meta-tag <strong>description</strong>';
$txt['optimus_allow_change_topic_desc'] = 'Gebruik een extra veld voor de topic beschrijving';
$txt['optimus_allow_change_topic_desc_subtext'] = 'Dit wordt getoond als een topic wordt gewijzigd.';
$txt['optimus_allow_change_topic_keywords'] = 'Gebrukik een extra veld voor topic zoektermen';
$txt['optimus_allow_change_topic_keywords_subtext'] = 'Dit wordt getoond als een topic wordt gewijzigd.';
$txt['optimus_show_keywords_block'] = 'Toon een blok met zoektermen boven het eerste bericht in een topic';
$txt['optimus_show_keywords_on_message_index'] = 'Toon zoektermen in topic lijsten in boards';
$txt['optimus_use_color_tags'] = 'Gebruik kleurtags';
$txt['optimus_max_allowed_tags'] = 'Maximaal aantal tags per topic';

$txt['optimus_extra_settings'] = 'Extra instellingen';
$txt['optimus_errors_for_wrong_actions'] = 'Toon een 404 pagina voor niet bestaande forum pagina\'s';
$txt['optimus_errors_for_wrong_boards_topics'] = 'Toon een 403/404 pagina voor niet-toegankelijke/niet bestaande boards en topics';
$txt['optimus_log_search'] = 'Activeer het logboek met gebruikte zoektermen';

$txt['optimus_extra_title'] = 'Metadata';
$txt['optimus_extra_desc'] = 'Hier kun je de <a href="https://ogp.me/" target="_blank" rel="noopener" class="bbc_link">Open Graph markup</a> voor forum pagina\'s toevoegen. ';
/* Argument: $scripturl */
$txt['optimus_extra_info'] = 'Gebruik een <a href="https://webmaster.yandex.ru/tools/microtest/" target="_blank" rel="noopener" class="bbc_link">struktuur data validator</a> (Yandex.Webmaster) of de <a href="https://developers.facebook.com/tools/debug" target="_blank" rel="noopener" class="bbc_link">Facebook Sharing Debugger</a> om je Open Graph tags te anayseren.<hr><strong>Let op</strong>: Facebook cached afbeeldingen en andere OG data. Om de cache te resetten, voer je in de debugger het webaddres in met de parameter <em>fbrefresh</em>, dat is %1$s?fbrefresh=reset.';

$txt['optimus_og_image'] = 'Gebruik de eerste afbeeldingsbijlage uit het eerste bericht van het topic in de meta tag <strong>og:image</strong>.';
/* Argument: $og_image_option_link */
$txt['optimus_og_image_subtext'] = 'De standaard afbeelding kan worden opgegeven in de instellingen van het <a href="%s" class="bbc_link">Huidige thema</a>.';
$txt['optimus_og_image_help'] = 'Indien actief, zal de  <strong>og:image</strong> meta tag een link bevatten naar de eerste afbeelding die als bijlage is toegevoegd aan het eerste bericht. Als er geen bijage is, en er is een afbeelding ingevoegd in een <strong>img</strong> tag, dan wordt deze gebruikt.';
$txt['optimus_allow_change_board_og_image'] = 'Gebruik een apart veld voor de board <strong>OG Afbeelding</strong>';
$txt['optimus_allow_change_board_og_image_subtext'] = 'Deze kan worden gewijzigd bij het aanpassen van een board.';
$txt['optimus_fb_appid'] = 'Facebook Application ID (als je dit hebt)';
$txt['optimus_fb_appid_help'] = 'Maak <a href="https://developers.facebook.com/apps" target="_blank" rel="noopener" class="bbc_link"><strong>hier</strong></a> een applicatie aan en kopieer het ID naar dit veld.';
$txt['optimus_tw_cards'] = 'Gebruikersnaam op X (als je die hebt)';
$txt['optimus_tw_cards_help'] = 'Lees <a href="https://dev.twitter.com/cards/overview" target="_blank" rel="noopener" class="bbc_link"><strong>hier</strong></a> meer over X Cards .';

$txt['optimus_favicon_title'] = 'Favicon';
$txt['optimus_favicon_desc'] = 'Maak je eigen forum icoon. Dit zal getoond worden in de browser tab voor de naam.';

$txt['optimus_favicon_text'] = 'De favicon code';
$txt['optimus_favicon_help'] = 'Genereer je eigen favicon <a href="https://www.favicomatic.com/" target="_blank" rel="noopener" class="bbc_link">hier</a>.<br>Daarna kun je de favicon bestanden uploaden naar de forum root, en de code 
 van de generator site opslaan in het veld rechts.<br>Deze code zal worden geladen bovenaan de pagina\'s van de website, tussen de &lt;head&gt;&lt;/head&gt; tags.';

$txt['optimus_meta_title'] = 'Meta tags';
$txt['optimus_meta_desc'] = 'Op deze pagina kun je verificatiecode(s) van onderstaande lijst onderhouden.';

$txt['optimus_meta_addtag'] = 'Klik hier om een nieuwe tag toe te voegen';
$txt['optimus_meta_customtag'] = 'Aangepaste meta tag';
$txt['optimus_meta_tools'] = 'Zoekmachine (Tools)';
$txt['optimus_meta_name'] = 'Naam';
$txt['optimus_meta_content'] = 'Inhoud';
$txt['optimus_meta_info'] = 'Gebruik alleen de waarden van de <strong>inhoud</strong> parameter van de meta tags.<br>Bijvoorbeeld: <span class="smalltext">&lt;meta name="<strong>NAME</strong>" content="<strong>WAARDE</strong>"&gt;</span>';
$txt['optimus_search_engines'] = [
	'Google' => ['google-site-verificatie', 'https://www.google.com/webmasters/tools/', 'Google Search Console'],
	'Bing'   => ['msvalidate.01', 'https://www.bing.com/toolbox/webmaster/', 'Bing Webmaster'],
	'Yandex' => ['yandex-verificatie', 'https://webmaster.yandex.com/', 'Yandex.Webmaster'],
];

$txt['optimus_redirect_title'] = 'Doorverwijzing';
$txt['optimus_redirect_desc'] = 'Op deze pagina kun je regels opvoeren voor doorverwijzingen voor interne forum URLs. ';
$txt['optimus_redirect_info'] = 'Je kunt hier een intern of een extern adres opgeven als bestemming voor doorverwijzing.';
$txt['optimus_redirect_from'] = 'Van';
$txt['optimus_redirect_to'] = 'Tot';
$txt['optimus_add_redirect'] = 'Voeg een nieuwe doorverwijzing in';

$txt['optimus_counters'] = 'AdSense/JS code';
$txt['optimus_counters_desc'] = 'Je kunt hier JS code toevoegen en wijzigen voor het bijhouden van bezoeken aan je forum.';

$txt['optimus_head_code'] = 'Onzichtbare JS tellers die geladen worden in de <strong>head</strong> sectie';
$txt['optimus_head_code_subtext'] = 'Bijvoorbeeld, <a href="https://www.google.com/analytics/sign_up.html" target="_blank" rel="noopener" class="bbc_link">Google Analytics</a>, of <a href="https://www.google.com/adsense/start/" target="_blank" rel="noopener" class="bbc_link">Google AdSense</a>';
$txt['optimus_stat_code'] = 'Onzichtbare JS tellers die geladen worden in de <strong>body</strong> sectie';
$txt['optimus_stat_code_subtext'] = 'Bijvoorbeeld, <a href="https://matomo.org/" target="_blank" rel="noopener" class="bbc_link">Matomo</a> etc';
$txt['optimus_count_code'] = 'Zichtbare JS (teller afbeeldingen, banners, enz)';
$txt['optimus_counters_css'] = 'Opmaak voor zichtbare tellers (CSS code)';
$txt['optimus_ignored_actions'] = 'Acties die genegeerd worden';
$txt['optimus_ignored_actions_subtext'] = 'Tellers zullen niet geladen worden in deze pagina\'s!';

$txt['optimus_robots_title'] = 'Beheer robots.txt';
$txt['optimus_robots_desc'] = 'De generator wordt bijgewerkt op basis van de geinstalleerde modificaties en instellingen van SMF.';

$txt['optimus_rules'] = 'robots.txt generator';
$txt['optimus_rules_hint'] = 'Je kunt deze regels gebruiken als voorbeeld voor jouw robots.txt';

$txt['optimus_htaccess_title'] = 'Beheer .htaccess';
$txt['optimus_htaccess_desc'] = 'Hier kun je het .htaccess bestand van je forum aanpassen. Wees voorzichtig!';

$txt['optimus_sitemap_title'] = 'Sitemap';
/* Argument: OP_NAME */
$txt['optimus_sitemap_desc'] = '%1$s kan een eenvoudige XML sitemap genereren op basis van onderstaande instellingen.';
/* Argument: string */
$txt['optimus_sitemap_info'] = 'Als je geen recente boards of topics in de sitemap vindt, controleer %s';
$txt['optimus_root_is_not_writable'] = 'Zorg ervoor dat de hoofdmap van het forum (be)schrijfbaar is!';
$txt['optimus_sitemap_enable'] = 'Activeer de Sitemap instellingen';
$txt['optimus_sitemap_enable_subtext'] = 'De sitemap zal worden gegenereerd of gewijzigd na het opslaan van de instellingen.';
$txt['optimus_sitemap_link'] = 'Toon een link naar de Sitemap in de footer';
$txt['optimus_remove_previous_xml_files'] = 'Verwijder eerder aangemaakte sitemap*.xml bestanden';
$txt['optimus_main_page_frequency'] = 'De vernieuwingsfrequentie van de hoofdpagina';
$txt['optimus_main_page_frequency_set'] = ['Direct (voortdurend)', 'Afhankelijk van de datum van het nieuwste bericht'];
$txt['optimus_sitemap_boards'] = 'Neem links naar de boards op in de sitemap';
$txt['optimus_sitemap_boards_subtext'] = 'Boards die niet toegankelijk zijn voor gasten worden NIET opgenomen.';
$txt['optimus_sitemap_topics_num_replies'] = 'Voeg alleen topics aan de sitemap toe die meer dan zoveel reacties hebben';
$txt['optimus_sitemap_add_found_images'] = 'Voeg links naar gevonden afbeeldingen toe aan de Sitemap';
$txt['optimus_sitemap_items_display'] = 'Maximum aantal items per pagina';
$txt['optimus_sitemap_all_topic_pages'] = 'Voeg ALLE topics toe aan de sitemap';
$txt['optimus_sitemap_all_topic_pages_subtext'] = 'Als dit niet is aangevinkt, wordt alleen de eerste pagina van alle topics toegevoegd aan de sitemap.';
$txt['optimus_start_year'] = 'De Sitemap moet de paginas bevatten van het opgegeven jaar';
$txt['optimus_update_frequency'] = 'Hoe frequent wordt de Sitemap bijgewerkt';
$txt['optimus_update_frequency_set'] = ['Eens per dag', 'Elke 3 dagen', 'Eens per week', 'Elke 2 weken', 'Eens per maand'];

$txt['optimus_mobile'] = 'Mobiel';
$txt['optimus_images'] = 'Afbeeldingen';
$txt['optimus_news'] = 'Nieuws';
$txt['optimus_video'] = 'Video';
$txt['optimus_index'] = 'Index';
$txt['optimus_total_files'] = 'Totaal aantal bestanden';
$txt['optimus_total_urls'] = 'Totaal aantal URLs';
$txt['optimus_last_modified'] = 'Laatst gewijzigd';
$txt['optimus_frequency'] = 'Frequentie';
$txt['optimus_priority'] = 'Prioriteit';
$txt['optimus_direct_link'] = 'Directe link';
$txt['optimus_caption'] = 'Titel';
$txt['optimus_thumbnail'] = 'Miniatuur';

$txt['permissionname_optimus_add_descriptions'] = $txt['group_perms_name_optimus_add_descriptions'] = 'Omschrijvingen toevoegen aan topics';
$txt['permissionhelp_optimus_add_descriptions'] = 'De mogelijkheid om een beschrijving toe te voegen bij het aanleggen en wijzigen van een topic.';
$txt['permissionname_optimus_add_keywords'] = $txt['group_perms_name_optimus_add_keywords'] = 'Voeg zoektermen toe aan topics';
$txt['permissionhelp_optimus_add_keywords'] = 'Biedt de mogelijkheid zoektermen op te geven bij het aanmaken of wijzigen van een topic.';
$txt['permissionname_optimus_add_descriptions_own'] = $txt['permissionname_optimus_add_keywords_own'] = 'Eigen topic';
$txt['permissionname_optimus_add_descriptions_any'] = $txt['permissionname_optimus_add_keywords_any'] = 'Elk topic';
$txt['group_perms_name_optimus_add_descriptions_own'] = 'Toevoegen van omschrijvingen aan eigen topics';
$txt['group_perms_name_optimus_add_descriptions_any'] = 'Toevoegen van omschrijvingen aan elk topic';
$txt['permissionname_optimus_view_search_terms'] = $txt['group_perms_name_optimus_view_search_terms'] = 'Toon statistieken van zoektermen';
$txt['permissionhelp_optimus_view_search_terms'] = 'De mogelijkheid om statistieken over gebruikte zoektermen te bekijken.';

$txt['optimus_404_page_title'] = '404 - Pagina niet gevonden';
$txt['optimus_404_h2'] = '404 fout';
$txt['optimus_404_h3'] = 'De gevraagde pagina bestaat niet';
$txt['optimus_403_page_title'] = '403 - Geen toegang';
$txt['optimus_403_h2'] = '403 fout';
$txt['optimus_403_h3'] = 'Je hebt geen toegang tot deze pagina.';
/* Argument: $scripturl */
$txt['optimus_goto_main_page'] = 'Ga naar de <a class="bbc_link" href="%1$s">hoofdpagina</a>.';
$txt['optimus_seo_description'] = 'Beschrijving';
$txt['optimus_enter_description'] = 'Geef een korte beschrijving voor dit topic';
$txt['optimus_seo_keywords'] = 'Zoektermen';
$txt['optimus_enter_keywords'] = 'Geef een of meer zoektermen op';
/* Argument: $keyword_name */
$txt['optimus_topics_with_keyword'] = 'Forumtopics met zoekterm "%s"';
$txt['optimus_keyword_id_not_found'] = 'Het opgegeven zoekterm ID werd niet gevonden.';
$txt['optimus_no_keywords'] = 'Er is geen informatie gevonden voor deze zoekterm.';
$txt['optimus_all_keywords'] = 'Alle zoektermen in de forum topics';
$txt['optimus_keyword_column'] = 'Zoekterm';
$txt['optimus_frequency_column'] = 'Frequentie';
$txt['optimus_top_queries'] = 'Veelgebruikte zoekacties';
/* Argument: $i  */
$txt['optimus_chart_title'] = 'Top %1$s';
$txt['optimus_no_search_terms'] = 'Statistieken zijn nog niet beschikbaar.';
