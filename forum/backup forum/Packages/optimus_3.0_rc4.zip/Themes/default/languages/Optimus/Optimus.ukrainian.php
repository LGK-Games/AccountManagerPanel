<?php

$txt['optimus_title'] = 'Пошукова оптимізація';

$txt['optimus_tips'] = [
	'basic' => 'Введення в пошукову оптимізацію',
	'extra' => 'Керівництво з публікації для веб-майстрів',
	'favicon' => 'Як показувати значок сайту в результатах пошуку',
	'metatags' => 'Як додати сайт до Google',
	'robots' => 'Як створити та надіслати файл robots.txt',
	'sitemap' => 'Як створити файл Sitemap і зробити його доступним для Google',
];

$txt['optimus_basic_title'] = 'Загальні налаштування';
/* Arguments: OP_VERSION, php_version(), $smcFunc['db_title'], $smcFunc['db_get_version']() */
$txt['optimus_basic_desc'] = 'Версія мода: <strong>%1$s</strong>, версія PHP: <strong>%2$s</strong>, версія %3$s: <strong>%4$s</strong>.<br>Обговорити баги та фічі мода можна на <a class="bbc_link" href="https://www.simplemachines.org/community/index.php?topic=422210.0">simplemachines.org</a>.';

$txt['optimus_main_page'] = 'Головна сторінка';
$txt['optimus_forum_index'] = 'Заголовок головної сторінки форуму';
$txt['optimus_description'] = 'Опис форуму';
$txt['optimus_description_subtext'] = 'Буде виведено в мета-тезі <strong>description</strong> головної сторінки.';

$txt['optimus_all_pages'] = 'Сторінки тем і розділів';
$txt['optimus_board_extend_title'] = 'Додавати назву форуму до заголовків розділів';
$txt['optimus_board_extend_title_set'] = ['Не додавати', 'Перед назвою розділу', 'Після назви розділу'];
$txt['optimus_topic_extend_title'] = 'Додавати назву розділу і форуму до заголовків тем';
$txt['optimus_topic_extend_title_set'] = ['Не додавати', 'Перед назвою теми', 'Після назви теми'];
$txt['optimus_topic_description'] = 'Використовувати уривок першого повідомлення теми як мета-тег <strong>description</strong>';
$txt['optimus_allow_change_topic_desc'] = 'Дозволити окреме поле для опису теми';
$txt['optimus_allow_change_topic_desc_subtext'] = 'Відображається при редагуванні теми.';
$txt['optimus_allow_change_topic_keywords'] = 'Allow a separate field for the topic tags';
$txt['optimus_allow_change_topic_keywords_subtext'] = 'Відображається при редагуванні теми.';
$txt['optimus_show_keywords_block'] = 'Display a block with tags above the first post of the topic';
$txt['optimus_show_keywords_on_message_index'] = 'Display tags in topic lists within boards';
$txt['optimus_use_color_tags'] = 'Використовувати кольорові теги';
$txt['optimus_max_allowed_tags'] = 'Maximum number of tags per topic';

$txt['optimus_extra_settings'] = 'Додаткові налаштування';
$txt['optimus_errors_for_wrong_actions'] = 'Відображати сторінку 404 для неіснуючих областей форуму';
$txt['optimus_errors_for_wrong_boards_topics'] = 'Відображати сторінку 403/404 для недоступних/неіснуючих розділів і тем';
$txt['optimus_log_search'] = 'Вести статистику пошукових запитів';

$txt['optimus_extra_title'] = 'Мікророзмітка';
$txt['optimus_extra_desc'] = 'Додавання <a href="https://ruogp.me/" target="_blank" rel="noopener" class="bbc_link">розмітки Open Graph</a> для сторінок форуму. ';
/* Argument: $scripturl */
$txt['optimus_extra_info'] = 'Використовуйте <a href="https://webmaster.yandex.ru/tools/microtest/" target="_blank" rel="noopener" class="bbc_link">валідатор мікророзмітки</a> (Яндекс.Вебмайстер) або <a href="https://developers.facebook.com/tools/debug" target="_blank" rel="noopener" class="bbc_link">налагоджувач репостів Facebook</a> для перевірки мікророзмітки вашого сайту.<hr><strong>Примітка</strong>: Facebook кешує зображення та інші OG-дані. Для скидання кешу потрібно в налагоджувачі репостів набрати адресу сторінки з параметром <em>fbrefresh</em>, наприклад: %1$s?fbrefresh=reset.';

$txt['optimus_og_image'] = 'Використовувати зображення з першого повідомлення теми в мета-тезі <strong>og:image</strong>';
/* Argument: $og_image_option_link */
$txt['optimus_og_image_subtext'] = 'За замовчуванням використовується зображення, задане в <a href="%s" class="bbc_link">налаштуваннях поточної теми оформлення</a>.';
$txt['optimus_og_image_help'] = 'Якщо ввімкнено, в мета-тег <strong>og:image</strong> підставляється посилання на перше зображення, прикріплене до першого повідомлення теми. Якщо вкладення немає, а в тексті повідомлення буде знайдено зображення всередині тегу <strong>img</strong>, використовується воно.';
$txt['optimus_allow_change_board_og_image'] = 'Дозволити окреме поле для картинки розділу (<strong>og:image</strong>)';
$txt['optimus_allow_change_board_og_image_subtext'] = 'Відображається при редагуванні розділу.';
$txt['optimus_fb_appid'] = 'ID додатку Facebook (якщо є)';
$txt['optimus_fb_appid_help'] = 'Створіть додаток <a href="https://developers.facebook.com/apps" target="_blank" rel="noopener" class="bbc_link"><strong>тут</strong></a>, скопіюйте його ID і вкажіть у цьому полі.';
$txt['optimus_tw_cards'] = 'X account name (if you have)';
$txt['optimus_tw_cards_help'] = 'Read more about X Cards <a href="https://dev.twitter.com/cards/overview" target="_blank" rel="noopener" class="bbc_link"><strong>here</strong></a>.';

$txt['optimus_favicon_title'] = 'Іконка сайту';
$txt['optimus_favicon_desc'] = 'Створіть свій значок для форуму.<br>Він буде відображатися браузером як зображення поруч із закладкою, у вкладках та в інших елементах інтерфейсу.';

$txt['optimus_favicon_text'] = 'Код для вставки favicon';
$txt['optimus_favicon_help'] = 'Згенеруйте свою унікальну іконку, наприклад, <a href="https://www.favicomatic.com/" target="_blank" rel="noopener" class="bbc_link">тут</a>. Потім завантажте файли іконки в корінь форуму, а запропонований на сайті код збережіть у полі праворуч. Цей код буде завантажуватися у верхній частині сторінок, між тегами &lt;<strong>head</strong>&gt;&lt;/<strong>head</strong>&gt;.';

$txt['optimus_meta_title'] = 'Мета-теги';
$txt['optimus_meta_desc'] = 'Додавання до коду сторінок форуму додаткових мета-тегів, наприклад, для підтвердження права власності на сайт.';

$txt['optimus_meta_addtag'] = 'Додати тег';
$txt['optimus_meta_customtag'] = 'Користувацький мета-тег';
$txt['optimus_meta_tools'] = 'Пошуковик (Сервіс)';
$txt['optimus_meta_name'] = 'Ім\'я тегу';
$txt['optimus_meta_content'] = 'Значення';
$txt['optimus_meta_info'] = 'Будь ласка, вказуйте тільки значення, що містяться в доданих мета-тегах (а не теги повністю).<br>Наприклад: <span class="smalltext">&lt;meta name="<strong>ІМ\'Я ТЕГУ</strong>" content="<strong>ЗНАЧЕННЯ</strong>"&gt;</span>';
$txt['optimus_search_engines'] = [
	'Google' => ['google-site-verification', 'https://www.google.com/webmasters/tools/', 'Google Search Console'],
	'Bing'   => ['msvalidate.01', 'https://www.bing.com/toolbox/webmaster/', 'Bing - Засоби веб-майстра'],
	'Yandex' => ['yandex-verification', 'https://webmaster.yandex.ua/', 'Яндекс.Вебмайстер'],
];

$txt['optimus_redirect_title'] = 'Перенаправлення';
$txt['optimus_redirect_desc'] = 'На цій сторінці можна додати правила перенаправлення для внутрішніх URL-адрес форуму.';
$txt['optimus_redirect_info'] = 'Як адресу перенаправлення можна вказати як внутрішню адресу, так і зовнішнє посилання.';
$txt['optimus_redirect_from'] = 'Звідки';
$txt['optimus_redirect_to'] = 'Куди';
$txt['optimus_add_redirect'] = 'Додати перенаправлення';

$txt['optimus_counters'] = 'AdSense/JS-код';
$txt['optimus_counters_desc'] = 'Додавайте та змінюйте будь-який JS-код для підрахунку статистики/відвідувань форуму.';

$txt['optimus_head_code'] = 'Невидимий код із завантаженням у секції <strong>head</strong>';
$txt['optimus_head_code_subtext'] = 'Наприклад, <a href="https://www.google.ua/analytics/" target="_blank" rel="noopener" class="bbc_link">Google Analytics</a> або <a href="https://www.google.com/adsense/start/" target="_blank" rel="noopener" class="bbc_link">Google AdSense</a>';
$txt['optimus_stat_code'] = 'Невидимий код із завантаженням у секції <strong>body</strong>';
$txt['optimus_stat_code_subtext'] = 'Наприклад, <a href="https://metrika.yandex.ua/" target="_blank" rel="noopener" class="bbc_link">Яндекс.Метрика</a> без інформера';
$txt['optimus_count_code'] = 'Видимі лічильники (інформери, банери тощо)';
$txt['optimus_counters_css'] = 'Оформлення блоку з видимими лічильниками (CSS-код)';
$txt['optimus_ignored_actions'] = 'Ігноровані області';
$txt['optimus_ignored_actions_subtext'] = 'На цих сторінках лічильники завантажуватися не будуть!';

$txt['optimus_robots_title'] = 'Редактор robots.txt';
$txt['optimus_robots_desc'] = 'Генератор правил оновлюється залежно від встановлених модів і деяких налаштувань SMF.';

$txt['optimus_rules'] = 'Генератор правил';
$txt['optimus_rules_hint'] = 'Можете скористатися цими заготовками для створення своїх правил:';

$txt['optimus_htaccess_title'] = 'Редактор .htaccess';
$txt['optimus_htaccess_desc'] = 'Тут можна змінити файл .htaccess для вашого форуму. Будьте обережні!';

$txt['optimus_sitemap_title'] = 'Карта форуму';
/* Argument: OP_NAME */
$txt['optimus_sitemap_desc'] = '%1$s вміє створювати просту XML-карту відповідно до наведених нижче налаштувань.';
/* Argument: string */
$txt['optimus_sitemap_info'] = 'Якщо свіжі розділи або теми не потрапляють у карту, зазирніть у секцію %s';
$txt['optimus_root_is_not_writable'] = 'Make sure that the forum root directory is writable!';
$txt['optimus_sitemap_enable'] = 'Активувати карту форуму';
$txt['optimus_sitemap_enable_subtext'] = 'Карта буде створена/оновлена після збереження налаштувань.';
$txt['optimus_sitemap_link'] = 'Показувати посилання на карту в підвалі';
$txt['optimus_remove_previous_xml_files'] = 'Видаляти раніше створені файли sitemap*.xml';
$txt['optimus_main_page_frequency'] = 'Частота зміни головної сторінки';
$txt['optimus_main_page_frequency_set'] = ['Постійна (always)', 'Залежно від дати останнього повідомлення'];
$txt['optimus_sitemap_boards'] = 'Додавати в карту посилання на розділи форуму';
$txt['optimus_sitemap_boards_subtext'] = 'Розділи, закриті для гостей, додані НЕ будуть.';
$txt['optimus_sitemap_topics_num_replies'] = 'Додавати в карту тільки теми з кількістю відповідей >=';
$txt['optimus_sitemap_add_found_images'] = 'Додавати в карту посилання на знайдені зображення';
$txt['optimus_sitemap_items_display'] = 'Максимальна кількість елементів на сторінці';
$txt['optimus_sitemap_all_topic_pages'] = 'Додавати в карту ВСІ сторінки тем';
$txt['optimus_sitemap_all_topic_pages_subtext'] = 'Якщо не позначено, у карту будуть додані лише перші сторінки тем.';
$txt['optimus_start_year'] = 'До карти повинні потрапляти записи, починаючи з зазначеного року';
$txt['optimus_update_frequency'] = 'Перiодичнiсть оновлення карти';
$txt['optimus_update_frequency_set'] = ['Раз на день', 'Раз на 3 дні', 'Раз на тиждень', 'Раз на 2 тижні', 'Раз на місяць'];

$txt['optimus_mobile'] = 'Сторінки для мобільних пристроїв';
$txt['optimus_images'] = 'Зображення';
$txt['optimus_news'] = 'Новини';
$txt['optimus_video'] = 'Відео';
$txt['optimus_index'] = 'Індекс';
$txt['optimus_total_files'] = 'Всього файлів';
$txt['optimus_total_urls'] = 'Всього посилань';
$txt['optimus_last_modified'] = 'Змінено';
$txt['optimus_frequency'] = 'Періодичність';
$txt['optimus_priority'] = 'Пріоритет';
$txt['optimus_direct_link'] = 'Пряме посилання';
$txt['optimus_caption'] = 'Заголовок';
$txt['optimus_thumbnail'] = 'Мініатюра';

$txt['permissionname_optimus_add_descriptions'] = $txt['group_perms_name_optimus_add_descriptions'] = 'Додавання описів для тем';
$txt['permissionhelp_optimus_add_descriptions'] = 'Можливість додавати опис під час створення/редагування теми.';
$txt['permissionname_optimus_add_keywords'] = $txt['group_perms_name_optimus_add_keywords'] = 'Add tags for topics';
$txt['permissionhelp_optimus_add_keywords'] = 'Ability to add tags when creating/editing a topic.';
$txt['permissionname_optimus_add_descriptions_own'] = $txt['permissionname_optimus_add_keywords_own'] = 'Власна тема';
$txt['permissionname_optimus_add_descriptions_any'] = $txt['permissionname_optimus_add_keywords_any'] = 'Будь-яка тема';
$txt['group_perms_name_optimus_add_descriptions_own'] = 'Додавання описів для власних тем';
$txt['group_perms_name_optimus_add_descriptions_any'] = 'Додавання описів для будь-яких тем';
$txt['permissionname_optimus_view_search_terms'] = $txt['group_perms_name_optimus_view_search_terms'] = 'Перегляд статистики пошукових запитів';
$txt['permissionhelp_optimus_view_search_terms'] = 'Можливість переглядати статистику пошуку на форумі.';

$txt['optimus_404_page_title'] = '404 - Сторінку не знайдено';
$txt['optimus_404_h2'] = 'Помилка 404';
$txt['optimus_404_h3'] = 'Такої сторінки тут немає.';
$txt['optimus_403_page_title'] = '403 - Доступ заборонено';
$txt['optimus_403_h2'] = 'Помилка 403';
$txt['optimus_403_h3'] = 'Ви не маєте доступу до цієї сторінки.';
/* Argument: $scripturl */
$txt['optimus_goto_main_page'] = 'Перейти на <a class="bbc_link" href="%1$s">головну сторінку</a>.';
$txt['optimus_seo_description'] = 'Опис';
$txt['optimus_enter_description'] = 'Введіть короткий опис цієї теми';
$txt['optimus_seo_keywords'] = 'Tags';
$txt['optimus_enter_keywords'] = 'Enter one or more tags';
/* Argument: $keyword_name */
$txt['optimus_topics_with_keyword'] = 'Forum topics with tag "%s"';
$txt['optimus_keyword_id_not_found'] = 'The specified tag ID was not found.';
$txt['optimus_no_keywords'] = 'There is no information about this tag identifier.';
$txt['optimus_all_keywords'] = 'All tags in the forum topics';
$txt['optimus_keyword_column'] = 'Tag';
$txt['optimus_frequency_column'] = 'Частотність';
$txt['optimus_top_queries'] = 'Популярні запити';
/* Argument: $i  */
$txt['optimus_chart_title'] = 'Топ-%1$s';
$txt['optimus_no_search_terms'] = 'Статистики поки немає.';
