<?php

$txt['optimus_title'] = 'Arama Motoru Optimizasyonu';

$txt['optimus_tips'] = [
	'basic' => 'Arama Motoru Optimizasyonu (SEO) Başlangıç ​​Kılavuzu',
	'extra' => 'Web Yöneticileri İçin Rehber',
	'favicon' => 'Arama sonuçlarında gösterilecek bir favicon tanımlayın',
	'metatags' => 'Web sitenizi Google\'a tanıtın',
	'robots' => 'Robots.txt dosyası nasıl yazılır ve gönderilir',
	'sitemap' => 'Site haritası oluşturun ve gönderin',
];

$txt['optimus_basic_title'] = 'Temel ayarlar';
/* Arguments: OP_VERSION, php_version(), $smcFunc['db_title'], $smcFunc['db_get_version']() */
$txt['optimus_basic_desc'] = 'Mod sürümü: <strong>%1$s</strong>, PHP sürümü: <strong>%2$s</strong>, %3$s sürümü: <strong>%4$s</strong>. Modun hataları ve özellikleri <a class="bbc_link" href="https://www.simplemachines.org/community/index.php?topic=422210.0">simplemachines.org</a> adresinde tartışılabilir.';

$txt['optimus_main_page'] = 'Ana Sayfa';
$txt['optimus_forum_index'] = 'Forum Ana Sayfası başlığı';
$txt['optimus_description'] = 'Forum açıklaması';
$txt['optimus_description_subtext'] = '<strong>description</strong> meta etiketinin içeriği olarak kullanılacaktır.';

$txt['optimus_all_pages'] = 'Konu ve bölüm sayfaları';
$txt['optimus_board_extend_title'] = 'Forum adlarını bölüm başlıklarına ekle';
$txt['optimus_board_extend_title_set'] = ['Ekleme', 'Bölüm başlığından önce', 'Bölüm başlığından sonra'];
$txt['optimus_topic_extend_title'] = 'Konu başlıklarına bölüm ve forum başlığı ekle';
$txt['optimus_topic_extend_title_set'] = ['Ekleme', 'Konu başlığından önce', 'Konu başlığından sonra'];
$txt['optimus_topic_description'] = 'Konunun ilk mesaj içeriğini meta-tag <strong>description</strong> olarak ayarla';
$txt['optimus_allow_change_topic_desc'] = 'Konu açıklaması yazmak için ayrı bir alan oluştur';
$txt['optimus_allow_change_topic_desc_subtext'] = 'Konu oluştururken, düzenlerken görüntülenir.';
$txt['optimus_allow_change_topic_keywords'] = 'Konu anahtar kelimeleri yazmak için ayrı bir alan oluştur';
$txt['optimus_allow_change_topic_keywords_subtext'] = 'Konu oluştururken, düzenlerken görüntülenir.';
$txt['optimus_show_keywords_block'] = 'Konunun ilk gönderisinin üzerinde anahtar kelimeler içeren bir blok göster';
$txt['optimus_show_keywords_on_message_index'] = 'Anahtar kelimeleri bölüm konu listesinde görüntüle';
$txt['optimus_use_color_tags'] = 'Renkli anahtar kelimeler kullanın';
$txt['optimus_max_allowed_tags'] = 'Konu başına maksimum anahtar kelime sayısı';

$txt['optimus_extra_settings'] = 'Ek ayarlar';
$txt['optimus_errors_for_wrong_actions'] = 'Erişilemeyen/var olmayan forum sayfaları için 404 sayfası görüntüle';
$txt['optimus_errors_for_wrong_boards_topics'] = 'Erişilemeyen/var olmayan bölümler ve konular için 403/404 sayfası görüntüle';
$txt['optimus_log_search'] = 'Arama terimlerinin günlüğe kaydedilmesini etkinleştir';

$txt['optimus_extra_title'] = 'Üst Veri';
$txt['optimus_extra_desc'] = 'Burada forum sayfaları için <a href="https://ogp.me/" target="_blank" rel="noopener" class="bbc_link">Open Graph markup</a> ekleyebilirsiniz.';
/* Argument: $scripturl */
$txt['optimus_extra_info'] = 'Open Graph etiketlerinizde hata ayıklamak için <a href="https://webmaster.yandex.ru/tools/microtest/" target="_blank" rel="noopener" class="bbc_link">yapılandırılmış veri</a>  doğrulayıcı (Yandex.Webmaster) veya <a href="https://developers.facebook.com/tools/debug" target="_blank" rel="noopener" class="bbc_link">Facebook Paylaşım Hata Ayıklayıcı</a> kullanın.
<hr><strong>Not:</strong> Facebook, görüntüleri ve diğer OG verilerini önbelleğe alır. Önbelleği sıfırlamak için, yeniden gönderme hata ayıklayıcısına fbrefresh parametresiyle sayfa adresini yazın, ör. <em>fbrefresh</em>, i.e. %1$s?fbrefresh=reset.';

$txt['optimus_og_image'] = '<strong>og:image</strong> meta etiketi için konu içideki ilk resmi kullan';
/* Argument: $og_image_option_link */
$txt['optimus_og_image_subtext'] = 'Varsayılan olarak, <a href="%s" class="bbc_link">kullanılan tema ayarlarında</a> belirtilen resim kullanılır.';
$txt['optimus_og_image_help'] = 'Etkinleştirilirse, <strong>og:image</strong> meta etiketine, Konunun ilk mesajına eklenen ilk görselin bağlantısını eklenecektir. Herhangi bir görsel yoksa  mesaj metninde <strong>img</strong> etiketinin içindeki resim bulunursa o kullanılır.';
$txt['optimus_allow_change_board_og_image'] = 'Bölüm <strong>OG Resmi</strong> için ayrı bir alana izin verin';
$txt['optimus_allow_change_board_og_image_subtext'] = 'Bölüm düzenlenirken görüntülenir.';
$txt['optimus_fb_appid'] = 'Facebook Uygulama kimliği (varsa)';
$txt['optimus_fb_appid_help'] = '<a href="https://developers.facebook.com/apps" target="_blank" rel="noopener" class="bbc_link"><strong>Buradan</strong></a>, bir uygulama oluşturun, kimliğini kopyalayın  ve bu alana girin.';
$txt['optimus_tw_cards'] = 'X hesap adı (eğer varsa)';
$txt['optimus_tw_cards_help'] = 'X Kartları hakkında daha fazla bilgiyi <a href="https://dev.twitter.com/cards/overview" target="_blank" rel="noopener" class="bbc_link"><strong>buradan</strong></a> okuyabilirsiniz.';

$txt['optimus_favicon_title'] = 'Favicon';
$txt['optimus_favicon_desc'] = 'Kendi forum simgenizi oluşturun. Tarayıcı tarafından açık sekmenin ve diğer arayüz öğelerinin yanında gösterilecektir.';

$txt['optimus_favicon_text'] = 'Favicon kodu';
$txt['optimus_favicon_help'] = 'Kendi favicon\'unuzu <a href="https://www.favicomatic.com/" target="_blank" rel="noopener" class="bbc_link">buradan</a> oluşturun.<br>Ardından favicon dosyalarını forum kök dizinine yükleyin ve kod oluşturucu sitesinden aldığınız kodu sağdaki alana kaydedin.<br>Bu kod, site sayfalarının en üstünde, &lt;head&gt;&lt;/head&gt; etiketlerinin arasına eklenecektir.';

$txt['optimus_meta_title'] = 'Meta etiketleri';
$txt['optimus_meta_desc'] = 'Bu sayfada, aşağıdaki listeden site doğrulama kodlarını ekleyebilirsiniz.';

$txt['optimus_meta_addtag'] = 'Yeni bir etiket ekle';
$txt['optimus_meta_customtag'] = 'Özel meta etiketi';
$txt['optimus_meta_tools'] = 'Arama motoru (Araçlar)';
$txt['optimus_meta_name'] = 'İsim';
$txt['optimus_meta_content'] = 'İçerik';
$txt['optimus_meta_info'] = 'Lütfen meta etiketlerin yalnızca <strong>içerik</strong> parametresindeki değerleri kullanın.<br>Örnek: <span class="smalltext">&lt;meta name="<strong>İSİM</strong>" content="<strong>DEĞER</strong>"&gt;</span>';
$txt['optimus_search_engines'] = [
	'Google' => ['google-site-doğrulama', 'https://search.google.com/search-console/about?hl=tr', 'Google Arama Konsolu'],
	'Bing'   => ['msvalidate.01', 'https://www.bing.com/webmasters/about?cc=tr', 'Bing Web Yöneticisi'],
	'Yandex' => ['yandex-doğrulaması', 'https://webmaster.yandex.com/', 'Yandex Web Yöneticisi'],
];

$txt['optimus_redirect_title'] = 'Yönlendirme';
$txt['optimus_redirect_desc'] = 'Bu sayfada dahili forum URL\'leri için yönlendirme kuralları ekleyebilirsiniz.';
$txt['optimus_redirect_info'] = 'Yönlendirme "hedef"i olarak dahili bir adres veya harici bir bağlantı belirtebilirsiniz.';
$txt['optimus_redirect_from'] = 'Gönderen';
$txt['optimus_redirect_to'] = 'Alıcı';
$txt['optimus_add_redirect'] = 'Yeni bir yönlendirme ekle';

$txt['optimus_counters'] = 'AdSense/JS kodu';
$txt['optimus_counters_desc'] = 'Forumunuzun istatistiklerini/ziyaretlerini kaydetmek için bu bölümde herhangi bir JS kodunu ekleyebilir ve değiştirebilirsiniz.';

$txt['optimus_head_code'] = '<strong>head</strong> bölümüne yüklenen görünmez JS sayaç kodları';
$txt['optimus_head_code_subtext'] = 'Örneğin, <a href="https://www.google.com/analytics/sign_up.html" target="_blank" rel="noopener" class="bbc_link">Google Analytics</a>, or <a href="https://www.google.com/adsense/start/" target="_blank" rel="noopener" class="bbc_link">Google AdSense</a>';
$txt['optimus_stat_code'] = '<strong>body</strong> bölümüne yüklenen JS kodları';
$txt['optimus_stat_code_subtext'] = 'Örnek: <a href="https://matomo.org/" target="_blank" rel="noopener" class="bbc_link">Matomo</a> etc';
$txt['optimus_count_code'] = 'Görünen JS kodları (görüntü sayaçları, banner, vb.)';
$txt['optimus_counters_css'] = 'Görünen sayaçların stili (CSS kodu)';
$txt['optimus_ignored_actions'] = 'Yok sayılan eylemler';
$txt['optimus_ignored_actions_subtext'] = 'Bu alanlara sayaç kodları yüklenmeyecek!';

$txt['optimus_robots_title'] = 'Robots.txt dosyasını yönetin';
$txt['optimus_robots_desc'] = 'Kural oluşturucu, kurulu modlara ve SMF ayarlarına bağlı olarak güncellenir.';

$txt['optimus_rules'] = 'Kural oluşturucu';
$txt['optimus_rules_hint'] = 'Bu kuralları robots.txt dosyanız için örnek olarak kullanabilirsiniz.';

$txt['optimus_htaccess_title'] = '.htaccess Düzenleyici';
$txt['optimus_htaccess_desc'] = 'Burada forumunuz için .htaccess dosyasını değiştirebilirsiniz. <strong>Dikkat olun!</strong>';

$txt['optimus_sitemap_title'] = 'Site Haritası';
/* Argument: OP_NAME */
$txt['optimus_sitemap_desc'] = '%1$s, aşağıdaki ayarlara göre basit bir XML haritası oluşturabilir.';
/* Argument: string */
$txt['optimus_sitemap_info'] = 'Haritada son panoları veya konuları görmüyorsanız, %s \'yi kontrol edin';
$txt['optimus_root_is_not_writable'] = 'Forum kök dizininin yazılabilir olduğundan emin olun!';
$txt['optimus_sitemap_enable'] = 'Site Haritasını Etkinleştir';
$txt['optimus_sitemap_enable_subtext'] = 'Ayarlar kaydedildikten sonra harita oluşturulacak/güncellenecektir.';
$txt['optimus_sitemap_link'] = 'Alt kısımda Site Haritası bağlantısını göster';
$txt['optimus_remove_previous_xml_files'] = 'Önceden oluşturulmuş sitemap*.xml dosyalarını kaldır';
$txt['optimus_main_page_frequency'] = 'Ana sayfanın güncelleme sıklığı';
$txt['optimus_main_page_frequency_set'] = ['Sabit (her zaman)', 'Son iletinin tarihine bağlı olarak'];
$txt['optimus_sitemap_boards'] = 'Site Haritasına bölüm bağlantılarını ekle';
$txt['optimus_sitemap_boards_subtext'] = 'Ziyaretçilere kapalı olan bölümler EKLENMEYECEKTİR.';
$txt['optimus_sitemap_topics_num_replies'] = 'İleti sayısına göre ekle >=';
$txt['optimus_sitemap_add_found_images'] = 'Tespit edilen görsellere Site Haritasına bağlantılar ekleyin';
$txt['optimus_sitemap_items_display'] = 'Sayfa başına maksimum öğe sayısı';
$txt['optimus_sitemap_all_topic_pages'] = 'TÜM konu sayfalarını site haritasına ekleyin';
$txt['optimus_sitemap_all_topic_pages_subtext'] = 'İşaretlenmezse, site haritasına yalnızca konuların ilk sayfaları eklenecektir.';
$txt['optimus_start_year'] = 'Site Haritası, belirtilen yıldan itibaren girişler içersin';
$txt['optimus_update_frequency'] = 'Site Haritası ne sıklıkla güncellensin?';
$txt['optimus_update_frequency_set'] = ['Günde bir kez', '3 günde bir', 'Haftada bir', '2 haftada bir', 'Ayda bir'];

$txt['optimus_mobile'] = 'Mobil';
$txt['optimus_images'] = 'Resimler';
$txt['optimus_news'] = 'Haberler';
$txt['optimus_video'] = 'Video';
$txt['optimus_index'] = 'Dizin';
$txt['optimus_total_files'] = 'Toplam dosya';
$txt['optimus_total_urls'] = 'Toplam URL';
$txt['optimus_last_modified'] = 'Son düzenleme';
$txt['optimus_frequency'] = 'Sıklık';
$txt['optimus_priority'] = 'Öncelik';
$txt['optimus_direct_link'] = 'Direkt link';
$txt['optimus_caption'] = 'Altyazı';
$txt['optimus_thumbnail'] = 'Küçük resim';

$txt['permissionname_optimus_add_descriptions'] = $txt['group_perms_name_optimus_add_descriptions'] = 'Konulara açıklama ekleyebilir';
$txt['permissionhelp_optimus_add_descriptions'] = 'Bir konu oluştururken/düzenlerken açıklama ekleyebilir.';
$txt['permissionname_optimus_add_keywords'] = $txt['group_perms_name_optimus_add_keywords'] = 'Konulara etiket ekleyin';
$txt['permissionhelp_optimus_add_keywords'] = 'Bir konu oluştururken/düzenlerken anahtar kelimeler ekleyebilir.';
$txt['permissionname_optimus_add_descriptions_own'] = $txt['permissionname_optimus_add_keywords_own'] = 'Kendi konuları';
$txt['permissionname_optimus_add_descriptions_any'] = $txt['permissionname_optimus_add_keywords_any'] = 'Herhangi bir konu';
$txt['group_perms_name_optimus_add_descriptions_own'] = 'Kendi konularına açıklama ekleyebilir';
$txt['group_perms_name_optimus_add_descriptions_any'] = 'Herhangi bir konuya açıklama ekleyebilir';
$txt['permissionname_optimus_view_search_terms'] = $txt['group_perms_name_optimus_view_search_terms'] = 'Arama terimlerinin istatistiklerini görüntüleyebilir';
$txt['permissionhelp_optimus_view_search_terms'] = 'Forumdaki arama istatistiklerini görüntüleme izinleri.';

$txt['optimus_404_page_title'] = '404 - Sayfa Bulunamadı';
$txt['optimus_404_h2'] = 'Hata 404';
$txt['optimus_404_h3'] = 'İstenen sayfa mevcut değil.';
$txt['optimus_403_page_title'] = '403 - Erişim Yasaklandı';
$txt['optimus_403_h2'] = 'Hata 403';
$txt['optimus_403_h3'] = 'Bu sayfaya erişiminiz yok.';
/* Argument: $scripturl */
$txt['optimus_goto_main_page'] = '<a class="bbc_link" href="%1$s">Ana sayfaya</a> git.';
$txt['optimus_seo_description'] = 'Açıklama';
$txt['optimus_enter_description'] = 'Bu konu hakkında kısa bir açıklama girin';
$txt['optimus_seo_keywords'] = 'Etiketler';
$txt['optimus_enter_keywords'] = 'Bir veya daha fazla anahtar kelime girin';
/* Argument: $keyword_name */
$txt['optimus_topics_with_keyword'] = '"%s" anahtar kelimesine sahip forum konuları';
$txt['optimus_keyword_id_not_found'] = 'Belirtilen anahtar kelime kimliği bulunamadı.';
$txt['optimus_no_keywords'] = 'Bu anahtar kelime tanımlayıcı hakkında bilgi yok.';
$txt['optimus_all_keywords'] = 'Forum konularındaki tüm anahtar kelimeler';
$txt['optimus_keyword_column'] = 'Etiketler';
$txt['optimus_frequency_column'] = 'Sıklık';
$txt['optimus_top_queries'] = 'Popüler arama sorguları';
/* Argument: $i  */
$txt['optimus_chart_title'] = 'En Çok %1$s';
$txt['optimus_no_search_terms'] = 'İstatistikler henüz mevcut değil.';
