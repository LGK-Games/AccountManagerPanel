<?php

$txt['optimus_title'] = 'Optimus for SMF';

$txt['optimus_tips'] = [
	'basic' => 'Przewodnik dla początkujących dotyczący optymalizacji pod kątem wyszukiwarek (SEO)',
	'extra' => 'Przewodnik udostępniania dla webmasterów',
	'favicon' => 'Definiowanie ikony favicon wyświetlanej w wynikach wyszukiwania',
	'metatags' => 'Znajdź swoją witrynę w Google',
	'robots' => 'Jak utworzyć i przesłać plik robots.txt?',
	'sitemap' => 'Utwórz i prześlij mapę witryny',
];

$txt['optimus_basic_title'] = 'Ustawienia podstawowe';
/* Arguments: OP_VERSION, php_version(), $smcFunc['db_title'], $smcFunc['db_get_version']() */
$txt['optimus_basic_desc'] = 'Wersja modyfikacji: <strong>%1$s</strong>, Wersja PHP: <strong>%2$s</strong>, %3$s version: <strong>%4$s</strong>.<br>O błędach i funkcjach moda można dyskutować pod adresem <a class="bbc_link" href="https://www.simplemachines.org/community/index.php?topic=422210.0">simplemachines.org</a>.';

$txt['optimus_main_page'] = 'Strona główna';
$txt['optimus_forum_index'] = 'Tytuł strony głównej forum';
$txt['optimus_description'] = 'Opis forum';
$txt['optimus_description_subtext'] = 'Zostanie on użyty jako zawartość meta-tagu <strong>opis</strong>.';

$txt['optimus_all_pages'] = 'Strony tematów i forum';
$txt['optimus_board_extend_title'] = 'Dodawanie nazwy forum do tytułów forów';
$txt['optimus_board_extend_title_set'] = ['Nie dodawaj', 'Przed tytułem forum', 'Po tytule forum'];
$txt['optimus_topic_extend_title'] = 'Dodaj tytuł sekcji i forum do tytułów tematów';
$txt['optimus_topic_extend_title_set'] = ['Nie dodawaj', 'Przed tytułem forum', 'Po tytule forum'];
$txt['optimus_topic_description'] = 'Wyświetla pierwszy fragment wiadomości tematu jako meta-tag <strong>opis</strong>.';
$txt['optimus_allow_change_topic_desc'] = 'Oddzielne pole na opis tematu';
$txt['optimus_allow_change_topic_desc_subtext'] = 'Jest on wyświetlany podczas edycji tematu.';
$txt['optimus_allow_change_topic_keywords'] = 'Allow a separate field for the topic tags';
$txt['optimus_allow_change_topic_keywords_subtext'] = 'Jest on wyświetlany podczas edycji tematu.';
$txt['optimus_show_keywords_block'] = 'Display a block with tags above the first post of the topic';
$txt['optimus_show_keywords_on_message_index'] = 'Display tags in topic lists within boards';
$txt['optimus_use_color_tags'] = 'Używaj kolorowych znaczników';
$txt['optimus_max_allowed_tags'] = 'Maximum number of tags per topic';

$txt['optimus_extra_settings'] = 'Dodatkowe ustawienia';
$txt['optimus_errors_for_wrong_actions'] = 'Wyświetlanie strony 404 dla nieistniejących obszarów forum';
$txt['optimus_errors_for_wrong_boards_topics'] = 'Wyświetlanie strony 403/404 dla niedostępnych/nieistniejących forów i tematów.';
$txt['optimus_log_search'] = 'Włącz rejestrowanie wyszukiwanych haseł';

$txt['optimus_extra_title'] = 'Metadane';
$txt['optimus_extra_desc'] = 'Tutaj można dodać dodatkowy <a href="https://ogp.me/" target="_blank" rel="noopener" class="bbc_link">znacznik</a> dla stron forum.';
/* Argument: $scripturl */
$txt['optimus_extra_info'] = 'Użyj <a href="https://webmaster.yandex.ru/tools/microtest/" target="_blank" rel="noopener" class="bbc_link">walidatora danych strukturalnych</a> (Yandex.Webmaster) lub <a href="https://developers.facebook.com/tools/debug" target="_blank" rel="noopener" class="bbc_link">Facebook Sharing Debuggera</a> do debugowania tagów Open Graph. <hr><strong>Uwaga</strong>: Facebook buforuje obrazy i inne dane OG. Aby zresetować pamięć podręczną, w debugerze repost wpisz adres strony z parametrem <em>fbrefresh</em>, np. %1$s?fbrefresh=reset.';

$txt['optimus_og_image'] = 'Użyj obrazu z pierwszej wiadomości tematycznej w metatagu <strong>og:image</strong>';
/* Argument: $og_image_option_link */
$txt['optimus_og_image_subtext'] = 'Domyślnie używany jest obraz określony w <a href="%s" class="bbc_link">aktualnych ustawieniach motywu</a>.';
$txt['optimus_og_image_help'] = 'Jeśli opcja ta jest włączona, metatag <strong>og:image</strong> będzie zawierał link do pierwszego obrazu dołączonego do pierwszej wiadomości tematycznej. Jeśli nie ma żadnego załącznika, a obraz wewnątrz znacznika <strong>img</strong> znajduje się w tekście wiadomości, jest on używany.';
$txt['optimus_allow_change_board_og_image'] = 'Zezwól na oddzielne pole dla tablicy <strong>OG Image</strong>.';
$txt['optimus_allow_change_board_og_image_subtext'] = 'Jest on wyświetlany podczas edycji forum.';
$txt['optimus_fb_appid'] = 'Identyfikator aplikacji Facebook (jeśli posiadasz)';
$txt['optimus_fb_appid_help'] = 'Utwórz aplikację <a href="https://developers.facebook.com/apps" target="_blank" rel="noopener" class="bbc_link"><strong>tutaj</strong></a>, skopiuj jej ID i wypełnij to pole.';
$txt['optimus_tw_cards'] = 'X account name (if you have)';
$txt['optimus_tw_cards_help'] = 'Read more about X Cards <a href="https://dev.twitter.com/cards/overview" target="_blank" rel="noopener" class="bbc_link"><strong>here</strong></a>.';

$txt['optimus_favicon_title'] = 'Favicon';
$txt['optimus_favicon_desc'] = 'Stwórz własną ikonę forum. Będzie ona wyświetlana przez przeglądarkę jako obraz obok otwartej karty i innych elementów interfejsu.';

$txt['optimus_favicon_text'] = 'Kod ikony favicon';
$txt['optimus_favicon_help'] = 'Wygeneruj własną ikonę favicon <a href="https://www.favicomatic.com/" target="_blank" rel="noopener" class="bbc_link">tutaj</a>.<br>Następnie prześlij pliki favicon do katalogu głównego forum i zapisz kod ze strony generatora w polu po prawej stronie.<br>Kod ten zostanie załadowany na górze stron witryny, pomiędzy znacznikami &lt;head&gt;&lt;/head&gt;.';

$txt['optimus_meta_title'] = 'Meta tagi';
$txt['optimus_meta_desc'] = 'Na tej stronie można dodać dowolny kod zwykły/weryfikacyjny z poniższej listy.';

$txt['optimus_meta_addtag'] = 'Kliknij tutaj, aby dodać nowy tag';
$txt['optimus_meta_customtag'] = 'Niestandardowy metatag';
$txt['optimus_meta_tools'] = 'Wyszukiwarka (narzędzie)';
$txt['optimus_meta_name'] = 'Nazwa';
$txt['optimus_meta_content'] = 'Zawartość';
$txt['optimus_meta_info'] = 'Należy używać tylko wartości z parametru <strong>content</strong> metatagów. <br>Przykład: <span class="smalltext">&lt;meta name="<strong>NAME</strong>" content="<strong>VALUE</strong>"&gt;</span>';
$txt['optimus_search_engines'] = [
	'Google' => ['google-site-verification', 'https://www.google.com/webmasters/tools/', 'Google Search Console'],
	'Bing'   => ['msvalidate.01', 'https://www.bing.com/toolbox/webmaster/', 'Bing Webmaster'],
	'Yandex' => ['yandex-verification', 'https://webmaster.yandex.com/', 'Yandex.Webmaster'],
];

$txt['optimus_redirect_title'] = 'Przekierowania';
$txt['optimus_redirect_desc'] = 'Na tej stronie można dodać reguły przekierowania dla wewnętrznych adresów URL forum.';
$txt['optimus_redirect_info'] = 'Jako adres przekierowania "do" można określić adres wewnętrzny lub łącze zewnętrzne.';
$txt['optimus_redirect_from'] = 'Od';
$txt['optimus_redirect_to'] = 'Do';
$txt['optimus_add_redirect'] = 'Dodaj nowe przekierowanie';

$txt['optimus_counters'] = 'Kod AdSense/JS';
$txt['optimus_counters_desc'] = 'Możesz dodać i zmienić dowolny kod JS w tej sekcji, aby rejestrować statystyki/odwiedziny forum.';

$txt['optimus_head_code'] = 'Niewidoczny JS z ładowaniem w sekcji <strong>head</strong>';
$txt['optimus_head_code_subtext'] = 'Na przykład, <a href="https://www.google.com/analytics/sign_up.html" target="_blank" rel="noopener" class="bbc_link">Google Analytics</a>, lub <a href="https://www.google.com/adsense/start/" target="_blank" rel="noopener" class="bbc_link">Google AdSense</a>';
$txt['optimus_stat_code'] = 'Niewidoczny JS z ładowaniem w sekcji <strong>body</strong>';
$txt['optimus_stat_code_subtext'] = 'Na przykład, <a href="https://matomo.org/" target="_blank" rel="noopener" class="bbc_link">Matomo</a> etc';
$txt['optimus_count_code'] = 'Widoczny JS (liczniki obrazów, banery itp.)';
$txt['optimus_counters_css'] = 'Wygląd widocznych liczników (kod CSS)';
$txt['optimus_ignored_actions'] = 'Zignorowane działania';
$txt['optimus_ignored_actions_subtext'] = 'Liczniki nie będą ładowane na tych obszarach!';

$txt['optimus_robots_title'] = 'Zarządzanie robots.txt';
$txt['optimus_robots_desc'] = 'Generator reguł jest aktualizowany w zależności od zainstalowanych modów i niektórych ustawień SMF.';

$txt['optimus_rules'] = 'Generator reguł';
$txt['optimus_rules_hint'] = 'Możesz użyć tych reguł jako przykładu dla pliku robots.txt (w prawym obszarze tekstowym):';

$txt['optimus_htaccess_title'] = 'Zarządzanie .htaccess';
$txt['optimus_htaccess_desc'] = 'Tutaj możesz zmodyfikować plik .htaccess dla swojego forum. Bądź ostrożny!';

$txt['optimus_sitemap_title'] = 'Mapa witryny';
/* Argument: OP_NAME */
$txt['optimus_sitemap_desc'] = '%1$s może wygenerować prostą mapę XML zgodnie z poniższymi ustawieniami.';
/* Argument: string */
$txt['optimus_sitemap_info'] = 'If you do not see recent boards or topics in the map, check the %s';
$txt['optimus_root_is_not_writable'] = 'Make sure that the forum root directory is writable!';
$txt['optimus_sitemap_enable'] = 'Aktywuj mapę witryny';
$txt['optimus_sitemap_enable_subtext'] = 'Mapa zostanie utworzona/zaktualizowana po zapisaniu ustawień.';
$txt['optimus_sitemap_link'] = 'Pokaż link do mapy witryny w stopce';
$txt['optimus_remove_previous_xml_files'] = 'Usunięcie wcześniej wygenerowanych plików sitemap*.xml';
$txt['optimus_main_page_frequency'] = 'Częstotliwość aktualizacji strony głównej';
$txt['optimus_main_page_frequency_set'] = ['Stała (zawsze)', 'W zależności od daty ostatniej wiadomości'];
$txt['optimus_sitemap_boards'] = 'Dodawanie linków forum do mapy witryny';
$txt['optimus_sitemap_boards_subtext'] = 'Fora zamknięte dla gości NIE zostaną dodane.';
$txt['optimus_sitemap_topics_num_replies'] = 'Dodaj linki do tematów, które mają określoną liczbę odpowiedzi >=';
$txt['optimus_sitemap_add_found_images'] = 'Dodawanie linków wykrytych obrazów do mapy witryny';
$txt['optimus_sitemap_items_display'] = 'Maksymalna liczba elementów na stronę';
$txt['optimus_sitemap_all_topic_pages'] = 'Dodaj WSZYSTKIE strony tematyczne do mapy witryny';
$txt['optimus_sitemap_all_topic_pages_subtext'] = 'Jeśli opcja ta nie zostanie zaznaczona, do mapy witryny dodawane będą tylko pierwsze strony tematów.';
$txt['optimus_start_year'] = 'Mapa witryny musi zawierać wpisy rozpoczynające się od określonego roku';
$txt['optimus_update_frequency'] = 'Jak często mapa witryny jest aktualizowana';
$txt['optimus_update_frequency_set'] = ['Raz dziennie', 'Co 3 dni', 'Raz w tygodniu', 'Co 2 tygodnie', 'Raz w miesiącu'];

$txt['optimus_mobile'] = 'Mobile';
$txt['optimus_images'] = 'Obrazy';
$txt['optimus_news'] = 'Aktualności';
$txt['optimus_video'] = 'Wideo';
$txt['optimus_index'] = 'Indeks';
$txt['optimus_total_files'] = 'Całkowita liczba plików';
$txt['optimus_total_urls'] = 'Łączna liczba adresów URL';
$txt['optimus_last_modified'] = 'Ostatnia modyfikacja';
$txt['optimus_frequency'] = 'Częstotliwość';
$txt['optimus_priority'] = 'Priorytet';
$txt['optimus_direct_link'] = 'Link bezpośredni';
$txt['optimus_caption'] = 'Podpis';
$txt['optimus_thumbnail'] = 'Miniatura';

$txt['permissionname_optimus_add_descriptions'] = $txt['group_perms_name_optimus_add_descriptions'] = 'Dodawanie opisów dla tematów';
$txt['permissionhelp_optimus_add_descriptions'] = 'Możliwość dodania opisu podczas tworzenia/edycji tematu.';
$txt['permissionname_optimus_add_keywords'] = $txt['group_perms_name_optimus_add_keywords'] = 'Add tags for topics';
$txt['permissionhelp_optimus_add_keywords'] = 'Ability to add tags when creating/editing a topic.';
$txt['permissionname_optimus_add_descriptions_own'] = $txt['permissionname_optimus_add_keywords_own'] = 'Własny temat';
$txt['permissionname_optimus_add_descriptions_any'] = $txt['permissionname_optimus_add_keywords_any'] = 'Dowolny temat';
$txt['group_perms_name_optimus_add_descriptions_own'] = 'Dodawanie opisów do własnych tematów';
$txt['group_perms_name_optimus_add_descriptions_any'] = 'Dodaj opisy dla dowolnych tematów';
$txt['permissionname_optimus_view_search_terms'] = $txt['group_perms_name_optimus_view_search_terms'] = 'Wyświetl statystyki wyszukiwanych haseł';
$txt['permissionhelp_optimus_view_search_terms'] = 'Możliwość przeglądania statystyk wyszukiwania na forum.';

$txt['optimus_404_page_title'] = '404 - Strona nie odnaleziona';
$txt['optimus_404_h2'] = 'Błąd 404';
$txt['optimus_404_h3'] = 'Przepraszamy, ale żądana strona nie istnieje.';
$txt['optimus_403_page_title'] = '403 - Dostęp zabroniony';
$txt['optimus_403_h2'] = 'Błąd 403';
$txt['optimus_403_h3'] = 'Przepraszamy, ale nie masz dostępu do tej strony';
/* Argument: $scripturl */
$txt['optimus_goto_main_page'] = 'Wróć do <a class="bbc_link" href="%1$s">strony głównej</a>.';
$txt['optimus_seo_description'] = 'Opis tematu [SEO]';
$txt['optimus_enter_description'] = 'Wprowadź krótki opis tego tematu';
$txt['optimus_seo_keywords'] = 'Tags';
$txt['optimus_enter_keywords'] = 'Enter one or more tags';
/* Argument: $keyword_name */
$txt['optimus_topics_with_keyword'] = 'Forum topics with tag "%s"';
$txt['optimus_keyword_id_not_found'] = 'The specified tag ID was not found.';
$txt['optimus_no_keywords'] = 'There is no information about this tag identifier.';
$txt['optimus_all_keywords'] = 'All tags in the forum topics';
$txt['optimus_keyword_column'] = 'Tag';
$txt['optimus_frequency_column'] = 'Częstotliwość';
$txt['optimus_top_queries'] = 'Popularne zapytania';
/* Argument: $i  */
$txt['optimus_chart_title'] = 'Top %1$s';
$txt['optimus_no_search_terms'] = 'Statystyki nie są jeszcze dostępne.';
