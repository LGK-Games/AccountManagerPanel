<?php

// Add affiliate form.
function template_add_affiliates()
{
	global $context, $scripturl, $txt;
	
	echo '
	<div id="admincenter">
		<div class="cat_bar">
			<h3 class="catbg">
				'.$txt['add_affiliates'].'
			</h3>
		</div>
		<form method="post" action="', $scripturl, '?action=admin;area=affiliates;sa=submit_affiliate" accept-charset="', $context['character_set'], '">
			<div class="windowbg2">
				<span class="topslice"><span></span></span>
				<div class="content">
					<dl class="settings">					
						<dt>
							<span><label for="add_affiliate_image">', $txt['add_affiliate_image'], '</label></span>
						</dt>
						<dd>
							<input type="text" id="add_affiliate_image" name="add_affiliate_image" size="75" required />
						</dd>
						<dt>
							<span><label for="add_affiliate_link">', $txt['add_affiliate_link'], '</label></span>
						</dt>
						<dd>
							<input type="text" id="add_affiliate_link" name="add_affiliate_link" size="75" />
						</dd>
						<dt>
							<span><label for="add_affiliate_description">', $txt['add_affiliate_description'], '</label></span>
						</dt>
						<dd>
							<input type="text" id="add_affiliate_description" name="add_affiliate_description" size="75" />
						</dd>
					</dl>
					<hr class="hrcolor clear" />
					<div class="righttext">
						<input style="display:none" name="save" value="ok" />
						<input style="display:none" name="sc" value="', $context['session_id'], '" />
						<button>',$txt['save'],'</button>
					</div>
				</div>
				<span class="botslice"><span></span></span>
			</div>
		</form>
	</div>';
}

// Add affiliate from acp form.
function template_add_affiliates_front()
{
	global $context, $scripturl, $txt;
	
	echo '
	<div id="admincenter">
		<div class="cat_bar">
			<h3 class="catbg">
				'.$txt['add_affiliates'].'
			</h3>
		</div>
		<form method="post" action="', $scripturl, '?action=affiliates;sa=submitaffiliates" accept-charset="', $context['character_set'], '">
			<div class="windowbg2">
				<span class="topslice"><span></span></span>
				<div class="content">
					<dl class="settings">					
						<dt>
							<span><label for="add_affiliate_image">', $txt['add_affiliate_image'], '</label></span>
						</dt>
						<dd>
							<input type="text" id="add_affiliate_image" name="add_affiliate_image" size="75" required />
						</dd>
						<dt>
							<span><label for="add_affiliate_link">', $txt['add_affiliate_link'], '</label></span>
						</dt>
						<dd>
							<input type="text" id="add_affiliate_link" name="add_affiliate_link" size="75" />
						</dd>
						<dt>
							<span><label for="add_affiliate_description">', $txt['add_affiliate_description'], '</label></span>
						</dt>
						<dd>
							<input type="text" id="add_affiliate_description" name="add_affiliate_description" size="75" />
						</dd>
					</dl>
					<hr class="hrcolor clear" />
					<div class="righttext">
						<input style="display:none" name="save" value="ok" />
						<input style="display:none" name="sc" value="', $context['session_id'], '" />
						<button>',$txt['save'],'</button>
					</div>
				</div>
				<span class="botslice"><span></span></span>
			</div>
		</form>
	</div>';
}

//Edit affiliates acp.
function template_edit_affiliates()
{
	global $context, $scripturl, $txt;
	
	echo '
	<div id="admincenter">
		<div class="cat_bar">
			<h3 class="catbg">
				'.$txt['editing_affiliate'].' '.$context['aff_edit']['id'].'
			</h3>
		</div>
		<form method="post" action="', $scripturl, '?action=admin;area=affiliates;sa=update_affiliate" accept-charset="', $context['character_set'], '">
			<div class="windowbg2">
				<span class="topslice"><span></span></span>
				<div class="content">
					<dl class="settings">					
						<dt>
							<span><label for="add_affiliate_image">', $txt['add_affiliate_image'], '</label></span>
						</dt>
						<dd>
							<input type="text" id="add_affiliate_image" value="',$context['aff_edit']['image'] ,'" name="add_affiliate_image" size="75" required />
						</dd>
						<dt>
							<span><label for="add_affiliate_link">', $txt['add_affiliate_link'], '</label></span>
						</dt>
						<dd>
							<input type="text" id="add_affiliate_link" value="',$context['aff_edit']['link'] ,'" name="add_affiliate_link" size="75" />
						</dd>	
						<dt>
							<span><label for="add_affiliate_description">', $txt['add_affiliate_description'], '</label></span>
						</dt>
						<dd>
							<input type="text" id="add_affiliate_description" value="',$context['aff_edit']['description'], '" name="add_affiliate_description" size="75" />
						</dd>						
					</dl>
					<hr class="hrcolor clear" />
					<div class="righttext">
						<input style="display:none" name="id" value="'.  $context['aff_edit']['id'] .'" />
						<input style="display:none" name="save" value="ok" />
						<input style="display:none" name="sc" value="', $context['session_id'], '" />
						<button>',$txt['save'],'</button>
					</div>
				</div>
				<span class="botslice"><span></span></span>
			</div>
		</form>
	</div>';
}

//Edit affiliates front.
function template_edit_affiliates_front()
{
	global $context, $scripturl, $txt;
	
	echo '
	<div id="admincenter">
		<div class="cat_bar">
			<h3 class="catbg">
				'.$txt['editing_affiliate'].' '.$context['aff_edit']['id'].'
			</h3>
		</div>
		<form method="post" action="', $scripturl, '?action=affiliates;sa=update" accept-charset="', $context['character_set'], '">
			<div class="windowbg2">
				<span class="topslice"><span></span></span>
				<div class="content">
					<dl class="settings">					
						<dt>
							<span><label for="add_affiliate_image">', $txt['add_affiliate_image'], '</label></span>
						</dt>
						<dd>
							<input type="text" id="add_affiliate_image" value="',$context['aff_edit']['image'] ,'" name="add_affiliate_image" size="75" required />
						</dd>
						<dt>
							<span><label for="add_affiliate_link">', $txt['add_affiliate_link'], '</label></span>
						</dt>
						<dd>
							<input type="text" id="add_affiliate_link" value="',$context['aff_edit']['link'] ,'" name="add_affiliate_link" size="75" />
						</dd>	
						<dt>
							<span><label for="add_affiliate_description">', $txt['add_affiliate_description'], '</label></span>
						</dt>
						<dd>
							<input type="text" id="add_affiliate_description" value="',$context['aff_edit']['description'], '" name="add_affiliate_description" size="75" />
						</dd>						
					</dl>
					<hr class="hrcolor clear" />
					<div class="righttext">
						<input style="display:none" name="id" value="'.  $context['aff_edit']['id'] .'" />
						<input style="display:none" name="save" value="ok" />
						<input style="display:none" name="sc" value="', $context['session_id'], '" />
						<button>',$txt['save'],'</button>
					</div>
				</div>
				<span class="botslice"><span></span></span>
			</div>
		</form>
	</div>';
}

// View affiliate.
function template_view_affiliate()
{
    global $context, $txt;

		foreach ($context['affdata'] as $aff)
		{
			echo '
				<table class="table_grid">
				<thead>
				<tr class="title_bar">
					<th class="lefttext">
						', $txt['displaying_affiliate'], ' ', $aff['id'] , '
					</th>
				</tr>
			</thead>
			<tbody>
				<tr class="windowbg">
					<td class="windowbg lefttext" style="padding-bottom:10px; width: 200px;">
						<img src="'.$aff['image'].'" alt="" />
					</td>
					<td class="windowbg lefttext" style="padding-bottom:10px">
						<br />
						<span class="smalltext">
							<strong>', $txt['affiliate_added_by'], ':</strong> ', $aff['user_id'] , '; ', $aff['time'] , '; <strong>', $txt['views'], ':</strong> ', $aff['views'] , '<br /><hr />
						    <strong>', $txt['link'], ':</strong> ', $aff['link'], '<br />
							<strong>', $txt['description'], ':</strong> ', $aff['description'], '<br />
						</span>
					</td>';	
				echo '
				</tr></tbody></table>';
		}
}

// Display affiliates on board index.
function template_affiliates_tpl_above()
{
	global $context, $scripturl;

	if (!empty($context['affiliatesList']))
	{
		echo '<div class="affiliatesContainer">';
		
		foreach ($context['affiliatesList'] as $affiliate)
		{
			$image = '<a href="' . $scripturl . '?action=affiliates;sa=view;id='.$affiliate['id']. '"><img src="'.$affiliate['image'].'" alt="" /></a>';
			
			echo'
				<article aria-label="article">
					<figure>
						'.$image.'
						<figcaption>'.$affiliate['description'].'</figcaption>
					</figure>
				</article>';
		}
		echo '</div>';
		
	}
}

// Nothing to show here.
function template_affiliates_tpl_below() {}