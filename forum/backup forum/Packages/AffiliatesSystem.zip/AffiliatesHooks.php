<?php

// If we have found SSI.php and we are outside of SMF, then we are running standalone.

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
{
	$ssi = true;
	require_once(dirname(__FILE__) . '/SSI.php');
}

// If we are outside SMF and can't find SSI.php, then throw an error.
	
elseif (!defined('SMF'))
	exit('<strong>Error:</strong> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

//Run hook functions.
$hook_functions = array(
	'integrate_pre_include' => '$sourcedir/Subs-Affiliates.php',
	'integrate_admin_areas' => 'affiliates_admin_area',
	'integrate_load_theme' => 'affiliates_load_theme',
	'integrate_actions' => 'affiliates_actions',
	'integrate_menu_buttons' => 'affiliates_menu_button',
	'integrate_load_permissions' => 'load_affiliates_permissions',
	'integrate_load_illegal_guest_permissions' => 'load_no_guests_affiliates_permissions',
	'integrate_member_context' => 'load_count_context',
	'integrate_load_member_data' => 'load_count_data',
	'integrate_load_custom_profile_fields' => 'load_custom_fields',
);

if (!empty($context['uninstalling']))
	$call = 'remove_integration_function';
else
	$call = 'add_integration_function';

foreach ($hook_functions as $hook => $function)
	$call($hook, $function);			

if (!empty($ssi))
	echo 'Congratulations! You have successfully installed this mod!';