<?php

// If we have found SSI.php and we are outside of SMF, then we are running standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
{
	$ssi = true;
	require_once(dirname(__FILE__) . '/SSI.php');
}

// If we are outside SMF and can't find SSI.php, then throw an error
elseif (!defined('SMF'))
	exit('<strong>Error:</strong> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

global $smcFunc;

if (!isset($smcFunc['db_create_table']))
	db_extend('packages');

$smcFunc['db_add_column']('{db_prefix}members', 
	array(
			'name' => 'affiliate_count',
			'type' => 'int',
			'size' => 10,
			'default' => 0,
			'not_null' => true,
			'unsigned' => true,
		)
);

$tables = array(
	'affiliates' => array(
		'columns' => array(
			array(
				'name' => 'id',
				'type' => 'int',
				'size' => '10',
				'null' => false,
				'unsigned' => true,
				'auto' => true,
			),
			array(
				'name' => 'user_id',
				'type' => 'int',
				'size' => 10,
				'not_null' => true,
				'unsigned' => true,
			),
			array(
				'name' => 'image',
				'type' => 'varchar',
				'size' => '255',
				'not_null' => true,
			),
			array(
				'name' => 'link',
				'type' => 'varchar',
				'size' => '255',
			),	
			array(
				'name' => 'description',
				'type' => 'varchar',
				'size' => '255',
			),
			array(
			   'name' => 'time',
			    'type' => 'int',					
			    'size' => '10',
			    'default' => '0',
				'unsigned' => true,
	        ),
			array(
				'name' => 'views',
				'type' => 'int',
		        'size' => '10',
		        'default' => '0',
				'unsigned' => true,
			),
		),
		'indexes' => array(
			array(
				'type' => 'primary',
				'columns' => array('id'),
			),
		),
	),
);

foreach ($tables as $table_name => $data)
	$smcFunc['db_create_table']('{db_prefix}' . $table_name, $data['columns'], $data['indexes']);
	   
if (!empty($ssi))
	echo 'Congratulations! You have successfully installed this mod!';	   