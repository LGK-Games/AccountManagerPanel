<?php

// If we are outside SMF throw an error.
if (!defined('SMF'))
	die('Hacking attempt...');

// Admin panel menu for the mod.
function AffiliatesAdminMenu()
{
	global $context, $txt;
	
	isAllowedTo('admin_forum');
	
	loadLanguage('Affiliates');

	$subActions = array(
	    'main' => 'AdminAffiliates', 
	    'add_affiliate' => 'AddAffiliate',
		'submit_affiliate' => 'SubmitAffiliate',
		'edit_affiliate' => 'EditAffiliate',
		'update_affiliate' => 'UpdateAffiliate',
		'settings' => 'AffiliatesSettings',
	);
	
	$context['page_title'] = $txt['admin_affiliates'];

	$context[$context['admin_menu_name']]['tab_data'] = array(
		'title' => &$txt['admin_affiliates'],
		'description' => $txt['admin_affiliates_desc'],
		'tabs' => array(
			'main' => array(
				'description' => $txt['admin_affiliates_desc'],
			),
			'add_affiliate' => array(
				'description' => $txt['add_affiliates_desc'],
			),
			'settings' => array(
				'description' => $txt['affiliates_settings_desc'],
			),
		),
	);

	// Call the right function for this sub-acton.
	if (!isset($_GET['sa']) || !isset($subActions[$_GET['sa']]))
		$_GET['sa'] = 'main';
	
	$subActions[$_GET['sa']]();
}

// Display add affiliate form.
function AddAffiliate()
{
	global $context, $txt;
	
	isAllowedTo('admin_forum');

	loadTemplate('Affiliates');
	
	$context['page_title'] = $txt['add_affiliates'];
	$context['sub_template'] = 'add_affiliates';
}

// Insert affiliate in the database.
function SubmitAffiliate()
{
	global $smcFunc, $user_info;
	
	$_POST['add_affiliate_image'] = $smcFunc['htmlspecialchars']($_POST['add_affiliate_image']);
	$_POST['add_affiliate_link'] = $smcFunc['htmlspecialchars']($_POST['add_affiliate_link']);
	$_POST['add_affiliate_description'] = $smcFunc['htmlspecialchars']($_POST['add_affiliate_description']);
	
	censorText($_POST['add_affiliate_description']);
	
	$image = !empty($_POST['add_affiliate_image']) ? $_POST['add_affiliate_image'] : '';
	$link = !empty($_POST['add_affiliate_link']) ? $_POST['add_affiliate_link'] : '';
	$description = !empty($_POST['add_affiliate_description']) ? $_POST['add_affiliate_description'] : '';
	
	if (empty($image))
		fatal_lang_error('you must_enter_image_url', false);
	
	$smcFunc['db_insert']('',
		'{db_prefix}affiliates',
		array(
				'user_id' => 'int', 'image' => 'string', 'link' => 'string', 'description' => 'string', 'time' => 'int',
		    ),
		array(
				$user_info['id'], $image, $link, $description, time(),
			),
		array('id')
	);
	
	$smcFunc['db_query']('', '
		UPDATE {db_prefix}members
		SET affiliate_count = affiliate_count + 1
	    WHERE id_member = {int:member}',
		array(
			'member' => $user_info['id'],
		)
	);
		
	redirectexit('action=admin;area=affiliates;sa=main');
}

// Display edit affiliate form.
function EditAffiliate()
{
	global $smcFunc, $context, $txt;
	
	$id = (int) $_REQUEST['id'];
	
	if(empty($id))
		fatal_lang_error('affiliate_is_deleted', false);
	
	isAllowedTo('admin_forum');

	loadTemplate('Affiliates');
	
	$context['page_title'] = $txt['editing_affiliate'] . $id;
	$context['sub_template'] = 'edit_affiliates';
	
	$results = $smcFunc['db_query']('', '
	        SELECT id, image, link, description
	        FROM {db_prefix}affiliates
	        WHERE id = {int:id} 
		    LIMIT 1',
		    array(
			   'id' => $id,
		    )
	    );

    $row = $smcFunc['db_fetch_assoc']($results);
	$smcFunc['db_free_result']($results);
	
	$context['aff_edit'] = $row;
}

// Insert updated affiliate in the database.
function UpdateAffiliate()
{
	global $smcFunc;
	
	$id = (int) $_REQUEST['id'];
	
	if(empty($id))
		fatal_lang_error('affiliate_is_deleted', false);
	
	$image = $smcFunc['htmlspecialchars']($_POST['add_affiliate_image']);
	$link = $smcFunc['htmlspecialchars']($_POST['add_affiliate_link']);
	$description = $smcFunc['htmlspecialchars']($_POST['add_affiliate_description']);
	
	censorText($description);
	
	if (empty($image))
		fatal_lang_error('you must_enter_image_url', false);
	
	$smcFunc['db_query']('',"
			UPDATE {db_prefix}affiliates
			SET
				image = {string:image},
				link = {string:link},			
				description = {string:description}							
			WHERE id = {int:id}",
			array(
			    'id' => $id,
				'image' => $image,
				'link' => $link,	
				'description' => $description,				
			)
	);
	
	redirectexit('action=admin;area=affiliates;sa=main');
}

// Display all affiliates in the admin panel.
function AdminAffiliates()
{
	global $txt, $sourcedir, $scripturl, $context, $smcFunc;
	
	isAllowedTo('admin_forum');
	
	// User pressed the 'remove selection button'.
	if (!empty($_POST['delete']) && !empty($_POST['remove']) && is_array($_POST['remove']))
	{
		checkSession();

		foreach ($_POST['remove'] as $index => $log_time)
			$_POST['remove'][(int) $index] = (int) $log_time;

		$smcFunc['db_query']('', '
			DELETE FROM {db_prefix}affiliates
			WHERE id IN ({array_int:affiliates_list})',
			array(
				'affiliates_list' => $_POST['remove'],
			)
		);

		redirectexit('action=admin;area=affiliates;sa=main');
	}
	
	$listOptions = array(
		'id' => 'affiliates_list',
		'items_per_page' => 20,
		'base_href' => $scripturl . '?action=admin;area=affiliates;sa=main',
		'default_sort_col' => 'image',
		'no_items_label' => $txt['no_affiliates_added_yet'],
		'get_items' => array(
			'function' => 'list_getAdminAffiliates',
		),
		'get_count' => array(
			'function' => 'list_countAdminAffiliates',
		),
		'columns' => array(
			'image' => array(
				'header' => array(
					'value' => $txt['image'],
					'style' => 'width: 10%; text-align: center;',
				),
				'data' => array(
					'db' => 'image',
				),
				'sort' =>  array(
					'default' => 'image',
					'reverse' => 'image DESC',
				),
			),
			'link' => array(
				'header' => array(
					'value' => $txt['link'],
					'style' => 'width: 30%; text-align: left;',
				),
				'data' => array(
					'db' => 'link',
				),
				'sort' => array(
					'default' => 'link',
					'reverse' => 'link DESC',
				),
			),
			'description' => array(
				'header' => array(
					'value' => $txt['description'],
					'style' => 'width: 20%; text-align: left;',
				),
				'data' => array(
					'db' => 'description',
				),
				'sort' =>  array(
					'default' => 'description',
					'reverse' => 'description DESC',
				),
			),
			'views' => array(
				'header' => array(
					'value' => $txt['views'],
				),
				'data' => array(
					'db' => 'views',
					'style' => 'width: 5%; text-align: center;',
				),
				'sort' =>  array(
					'default' => 'views',
					'reverse' => 'views DESC',
				),
			),
			'user_id' => array(
				'header' => array(
					'value' => $txt['username'],
					'style' => 'width: 10%; text-align: left;',
				),
				'data' => array(
					'db' => 'user_id',
				),
				'sort' =>  array(
					'default' => 'user_id',
					'reverse' => 'user_id DESC',
				),
			),
			'time' => array(
				'header' => array(
					'value' => $txt['affiliate_time'],
					'style' => 'width: 20%; text-align: center;',
				),
				'data' => array(
					'db' => 'time',
				),
				'sort' =>  array(
					'default' => 'time',
					'reverse' => 'time DESC',
				),
			),
			'modify' => array(
				'header' => array(
					'value' => $txt['modify'],
					'style' => 'width: 5%; text-align: center;',
				),
				'data' => array(
					'sprintf' => array(
						'format' => '<a href="' . $scripturl . '?action=admin;area=affiliates;sa=edit_affiliate;id=%1$d">' . $txt['edit'] . '</a>',
						'params' => array(
							'id' => false,
						),
					),
					'class' => 'centercol',
				),
			),
			'check' => array(
				'header' => array(
					'value' => '<input type="checkbox" onclick="invertAll(this, this.form);" class="input_check" />',
			),
			'data' => array(
					'sprintf' => array(
						'format' => '<input type="checkbox" name="remove[]" value="%1$d" class="input_check" />',
						'params' => array(
							'id' => false,
						),
					),
					'style' => 'text-align: center',
				),
			),
		),	
		'form' => array(
			'href' => $scripturl . '?action=admin;area=affiliates;sa=main',
		),
		'additional_rows' => array(
			array(
				'position' => 'below_table_data',
				'value' => '<input type="submit" name="delete" value="' . $txt['delete_selected_affiliates'] . '" onclick="return confirm(\'' . $txt['confirm_delete_selected_affiliates_desc'] . '\');" class="button_submit" />',
				'style' => 'text-align: right;',
			),
		),
	);

	require_once($sourcedir . '/Subs-List.php');
	createList($listOptions);

	$context['sub_template'] = 'show_list';
	$context['default_list'] = 'affiliates_list';
}

// Get all added affiliates.
function list_getAdminaffiliates($start, $items_per_page, $sort)
{
	global $smcFunc, $scripturl, $txt;
	
	$result = $smcFunc['db_query']('', '
	       SELECT aff.id, aff.user_id, aff.image, aff.link, aff.description, aff.views, aff.time,
		   mem.id_member, mem.member_name
		   FROM {db_prefix}affiliates AS aff
		   LEFT JOIN {db_prefix}members AS mem ON (mem.id_member = aff.user_id)
		   ORDER BY {raw:sort}
		   LIMIT {int:start}, {int:per_page}',
		   array(
				 'sort' => $sort,
		         'start' => $start,
			     'per_page' => $items_per_page,
			    )
	);
	
    $affiliates = array();
	
	while ($row = $smcFunc['db_fetch_assoc']($result))
	{
		$affiliates[] = array(
		    'id' => $row['id'],
			'user_id' => !empty($row['user_id']) ? '<a href="' . $scripturl . '?action=profile;u=' . $row['user_id'] . '">' . $row['member_name'] . '</a>' : $txt['guest'],
			'image' => '<a href="' . $scripturl . '?action=affiliates;sa=view;id='.$row['id']. '" target="_blank"><img src="'.$row['image'].'" alt="" /></a>',
			'link' => !empty($row['link']) ? $row['link'] : $txt['no_link_added'],
			'description' => !empty($row['description']) ? parse_bbc($row['description']) : $txt['no_description_added'],
			'views' => $row['views'],
			'time' => timeformat($row['time']),
		);
	}
	
	return $affiliates;

	$smcFunc['db_free_result']($result);
}

// Count all added affiliates for the pagination.
function list_countAdminAffiliates()
{
	global $smcFunc;
	
	$result = $smcFunc['db_query']('', '
		SELECT COUNT(*)
		FROM {db_prefix}affiliates',
		array( )
	);
				
	list ($affiliates) = $smcFunc['db_fetch_row']($result);
	
	$smcFunc['db_free_result']($result);

	return $affiliates;
}

// Settings.
function AffiliatesSettings($return_config = false) 
{
	global $txt, $scripturl, $context, $sourcedir, $modSettings;
	
	require_once($sourcedir.'/ManageServer.php');
	
	$context['page_title'] = $txt['settings'];
	$context['sub_template'] = 'show_settings';
	
	$config_vars = array(
		array('check', 'display_affiliates_forum'),
		'',
		array('check', 'daily_affiliates_limit'),
		array('int', 'daily_affiliates_nummber'),
        array('permissions', 'daily_excluded_groups'),
		'',
		array('check', 'enable_affiliate_count_members_posts'),
		array('check', 'enable_affiliate_count_members_profiles'),
	);
		
	if (isset($_GET['save']))
	{
		saveDBSettings($config_vars);
		redirectexit('action=admin;area=affiliates;sa=settings');
	}
	
	$context['settings_title'] = $txt['settings'];
	$context['post_url'] = $scripturl . '?action=admin;area=affiliates;save;sa=settings';
	
	prepareDBSettingContext($config_vars);
}