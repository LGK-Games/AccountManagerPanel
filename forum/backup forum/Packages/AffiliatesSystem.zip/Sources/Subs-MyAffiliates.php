<?php

// If we are outside SMF throw an error.
if (!defined('SMF'))
	die('hacking attempt...');

//Display all their affiliates to members.
function MyAffiliates()
{
	global $txt, $sourcedir, $scripturl, $context, $smcFunc;
	
	if(!allowedTo('submit_affiliates'))
		fatal_lang_error('no_access', false);
	
	loadLanguage('Affiliates');
	
	$context['page_title'] = $txt['my_affiliates_page'];
	
	$context['linktree'][] = array(
		'url' => $scripturl . '?action=affiliates',
		'name' => $txt['admin_affiliates'],
	);
	
	$context['linktree'][] = array(
		'url' => $scripturl . '?action=myaffiliates',
		'name' => $txt['my_affiliates_page'],
	);
	
	// User pressed the 'remove selection button'.
	if (!empty($_POST['delete']) && !empty($_POST['remove']) && is_array($_POST['remove']))
	{
		checkSession();

		foreach ($_POST['remove'] as $index => $log_time)
			$_POST['remove'][(int) $index] = (int) $log_time;

		$smcFunc['db_query']('', '
			DELETE FROM {db_prefix}affiliates
			WHERE id IN ({array_int:affiliates_list})',
			array(
				'affiliates_list' => $_POST['remove'],
			)
		);

		redirectexit($scripturl . '?action=myaffiliates');
	}
	
	$listOptions = array(
		'id' => 'affiliates_list',
		'items_per_page' => 20,
		'base_href' => $scripturl . '?action=myaffiliates',
		'default_sort_col' => 'image',
		'no_items_label' => $txt['no_affiliates_added_yet_by_you'],
		'get_items' => array(
			'function' => 'list_getMyAffiliates',
		),
		'get_count' => array(
			'function' => 'list_countMyAffiliates',
		),
		'columns' => array(
			'image' => array(
				'header' => array(
					'value' => $txt['image'],
				),
				'data' => array(
					'db' => 'image',
					'style' => 'width: 15%; text-align:center',
				),
				'sort' =>  array(
					'default' => 'image',
					'reverse' => 'image DESC',
				),
			),
			'description' => array(
				'header' => array(
					'value' => $txt['description'],
				),
				'data' => array(
					'db' => 'description',
					'style' => 'width: 55%; text-align:center',
				),
				'sort' =>  array(
					'default' => 'description',
					'reverse' => 'description DESC',
				),
			),
			'views' => array(
				'header' => array(
					'value' => $txt['views'],
				),
				'data' => array(
					'db' => 'views',
					'style' => 'width: 5%; text-align: center;',
				),
				'sort' =>  array(
					'default' => 'views',
					'reverse' => 'views DESC',
				),
			),
			'time' => array(
				'header' => array(
					'value' => $txt['affiliate_time'],
					'style' => 'width: 20%; text-align:left',
				),
				'data' => array(
					'db' => 'time',
				),
				'sort' =>  array(
					'default' => 'time',
					'reverse' => 'time DESC',
				),
			),
			'modify' => array(
				'header' => array(
					'value' => $txt['modify'],
					'style' => 'width: 5%; text-align: center;',
				),
				'data' => array(
					'sprintf' => array(
						'format' => '<a href="' . $scripturl . '?action=affiliates;sa=edit;id=%1$d">' . $txt['edit'] . '</a>',
						'params' => array(
							'id' => false,
						),
					),
					'class' => 'centercol',
				),
			),
			'check' => array(
				'header' => array(
					'value' => '<input type="checkbox" onclick="invertAll(this, this.form);" class="input_check" />',
			),
			'data' => array(
					'sprintf' => array(
						'format' => '<input type="checkbox" name="remove[]" value="%1$d" class="input_check" />',
						'params' => array(
							'id' => false,
						),
					),
					'style' => 'text-align: center',
				),
			),
		),	
		'form' => array(
			'href' => $scripturl . '?action=myaffiliates',
		),
		'additional_rows' => array(
			array(
				'position' => 'below_table_data',
				'value' => '<input type="submit" name="delete" value="' . $txt['delete_selected_affiliates'] . '" onclick="return confirm(\'' . $txt['confirm_delete_selected_affiliates_desc'] . '\');" class="button_submit" />',
				'style' => 'text-align: right;',
			),
		),
	);

	require_once($sourcedir . '/Subs-List.php');
	createList($listOptions);

	$context['sub_template'] = 'show_list';
	$context['default_list'] = 'affiliates_list';
}

// Get all members added affiliates.
function list_getMyAffiliates($start, $items_per_page, $sort)
{
	global $smcFunc, $scripturl, $txt, $user_info;
	
	$result = $smcFunc['db_query']('', '
	       SELECT aff.id, aff.user_id, aff.image, aff.link, aff.description, aff.views, aff.time,
		   mem.id_member, mem.member_name
		   FROM {db_prefix}affiliates AS aff
		   LEFT JOIN {db_prefix}members AS mem ON (mem.id_member = aff.user_id)
		   WHERE aff.user_id = {int:by_user}
		   ORDER BY {raw:sort}
		   LIMIT {int:start}, {int:per_page}',
		   array(
		         'by_user' => $user_info['id'],
				 'sort' => $sort,
		         'start' => $start,
			     'per_page' => $items_per_page,
			    )
	);
	
    $affiliates = array();
	
	while ($row = $smcFunc['db_fetch_assoc']($result))
	{
		$affiliates[] = array(
		    'id' => $row['id'],
			'image' => '<a href="' . $scripturl . '?action=affiliates;sa=view;id='.$row['id']. '"><img src="'.$row['image'].'" alt="" /></a>',
			'description' => !empty($row['description']) ? parse_bbc($row['description']) : $txt['no_description_added'],
			'views' => $row['views'],
			'time' => timeformat($row['time']),
		);
	}
	
	return $affiliates;

	$smcFunc['db_free_result']($result);
}

// Count all added members affiliates for the pagination.
function list_countMyAffiliates()
{
	global $smcFunc, $user_info;
	
	$result = $smcFunc['db_query']('', '
		SELECT COUNT(*)
		FROM {db_prefix}affiliates
		WHERE user_id = {int:by_user}',
		array(
		    'by_user' => $user_info['id'], 
		)
	);
				
	list ($affiliates) = $smcFunc['db_fetch_row']($result);
	
	$smcFunc['db_free_result']($result);

	return $affiliates;
}