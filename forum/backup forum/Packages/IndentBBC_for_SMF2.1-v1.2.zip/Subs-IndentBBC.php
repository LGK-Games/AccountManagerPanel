<?php
/**
 *
 * @author  ahrasis	http://smf.ahrasis.com
 * @license BSD http://opensource.org/licenses/BSD-3-Clause
 * @mod		Indent BBC
 *
 */

if (!defined('SMF'))
	die('Hacking attempt...');

	

function IndentBBC(&$codes)
{
	// Add bbc code(s)
	$codes[] = array(
			'tag' => 'indent-left',
			'before' => '<div style="margin-left: 3%;">',
			'after' => '</div>',
			'block_level' => true
	);
	$codes[] = array(
			'tag' => 'indent-right',
			'before' => '<div style="margin-right: 3%;">',
			'after' => '</div>',
			'block_level' => true
	);
	$codes[] = array(
			'tag' => 'indent-both',
			'before' => '<div style="margin: 0 3%;">',
			'after' => '</div>',
			'block_level' => true
	);
}


function IndentBBC_Buttons(&$bbc_tags)
{
	global $txt;

	// Load language
	loadLanguage('IndentBBC');

	// Add indent bbc buttons new group after 'justify' button.
	$indent_bbc = array();
	foreach ($bbc_tags[0] as $tag)
	{
		$indent_bbc[] = $tag;
		if (isset($tag['code']) && $tag['code'] == 'justify')
		{
			$indent_bbc[] = array(
			);
			$indent_bbc[] = array(
				'image' => 'indent-left',
				'code' => 'indent-left',
				'before' => '[indent-left]',
				'after' => '[/indent-left]',
				'description' => $txt['indent-left']
			);
			$indent_bbc[] = array(
				'image' => 'indent-right',
				'code' => 'indent-right',
				'before' => '[indent-right]',
				'after' => '[/indent-right]',
				'description' => $txt['indent-right']
			);
			$indent_bbc[] = array(
				'image' => 'indent-both',
				'code' => 'indent-both',
				'before' => '[indent-both]',
				'after' => '[/indent-both]',
				'description' => $txt['indent-both']
			);
		}
	}
	$bbc_tags[0] = $indent_bbc;
}

?>
