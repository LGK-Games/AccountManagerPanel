<?php

$txt['indent-left'] = 'Sangría izquierda';
$txt['indent-right'] = 'Sangría derecha';
$txt['indent-both'] = 'Aplicar la sangría a ambos lados';

?>
