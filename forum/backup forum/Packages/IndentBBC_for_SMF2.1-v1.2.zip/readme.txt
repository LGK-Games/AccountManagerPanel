﻿[hr]
[center][color=red][size=16pt][b]Indent BBC for SMF 2.1[/b][/size][/color]
[url=https://www.simplemachines.org/community/index.php?action=profile;u=112942][b]By GL700Wing[/b][/url]
[i](Based on [url=https://custom.simplemachines.org/index.php?mod=4003]Indent BBC[/url] mod by [url=https://www.simplemachines.org/community/index.php?action=profile;u=51815]Hj Ahmad Rasyid Hj Ismail[/url])[/i]
[/center]
[hr]


Note: For SMF 2.0 use the [url=https://custom.simplemachines.org/mods/index.php?mod=4003]Indent BBC[/url] mod.

[size=12pt][b][color=maroon]Indent BBC for SMF 2.1[/color][/b][/size]
- For SMF 2.1.x
- Fully hook, no file modification.

This mod will add three indent BBC buttons (ie: left side; right side; and both sides) that can used to indent text.

[color=red]BSD License.[/color] Feel free to modify accordingly but keep [url=https://www.simplemachines.org/community/index.php?action=profile;u=193241]Emanuale's name[/url] and [url=https://www.simplemachines.org/community/index.php?action=profile;u=51815]author's link[/url] if it is in here somewhere. ;)


[b][size=12pt]Release History:[/size][/b]
v1.0 - 11-Sep-22
o Initial Release

v1.1 - 18-Sep-22
o Added Spanish language files - thanks to [url=https://www.simplemachines.org/community/index.php?action=profile;u=322597]-Rock Lee-[/url].
o Fixed bug reported by [url=https://www.simplemachines.org/community/index.php?msg=4134781]Steve[/url].

v1.2 - 10-Jun-23
o Fixed hooks issue reported by [url=https://www.simplemachines.org/community/index.php?msg=4151473]Steve[/url].


[color=blue][b][size=12pt][u]License[/u][/size][/b][/color]
Copyright (c) 2014-2015, Hj Ahmad Rasyid Hj Ismail, 2022-2023 Kathy Leslie
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
