<?php

/*************************************************************************************************************
* Subs-AM2QBM.php - Subs for Add Modify to Quick Buttons menu (v1.1)
**************************************************************************************************************
* This mod is licensed under the 2-Clause BSD License, which can be found here:
*	https://opensource.org/licenses/BSD-2-Clause
**************************************************************************************************************
* Copyright (c) 2024 Kathy Leslie
* Redistribution and use in source and binary forms, with or without modification, are permitted provided
* that the following conditions are met:
*	1.	Redistributions of source code must retain the above copyright notice, this list of conditions
*		and the following disclaimer.
*	2.	Redistributions in binary form must reproduce the above copyright notice, this list of conditions and
*		the following disclaimer in the documentation and/or other materials provided with the distribution.
* This software is provided by the copyright holders and contributors "as is" and any express or implied
* warranties, including, but not limited to, the implied warranties of merchantability and fitness for a
* particular purpose are disclaimed. In no event shall the copyright holder or contributors be liable for
* any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not
* limited to, procurement of substitute goods or services; loss of use, data, or profits; or business
* interruption) however caused and on any theory of liability, whether in contract, strict liability, or
* tort (including negligence or otherwise) arising in any way out of the use of this software, even if
* advised of the possibility of such damage.
*************************************************************************************************************/

//============================================================================================================
// Function for adding option to remove 'Quick Edit' from the Quick Buttons menu.
// Called using hook 'integrate_general_mod_settings' from ./Sources/ManageSettings.php
//============================================================================================================
function AM2QBM_modSettings(&$config_vars)
{
	loadLanguage('AM2QBM');
	$config_vars = array_merge($config_vars, array(
		'',
		array('check', 'AM2QBM_remove'),
		)
	);
}

//============================================================================================================
// Function for moving 'Modify' and optionally removing 'Quick Edit' on the Quick Buttons menu.
// Called as hook by 'integrate_prepare_display_context' in ./Sources/Display.php.
//============================================================================================================
function AM2QBM_displayContext(&$output)
{
	global $context, $modSettings, $scripturl, $txt;

	// 'Modify' button definition copied from ./Sources/Display.php
	$modifyButton = array(
				'modify' => array(
					'label' => $txt['modify'],
					'href' => $scripturl.'?action=post;msg='.$output['id'].';topic='.$context['current_topic'].'.'.$context['start'],
					'icon' => 'modify_button',
					'show' => $output['can_modify']
					),
				);

	// Add 'Modify' before 'More' on the Quick Buttons menu ...
	$index = array_search('more', array_keys($output['quickbuttons']));
	$output['quickbuttons'] = array_merge(array_slice($output['quickbuttons'], 0, $index), $modifyButton, array_slice($output['quickbuttons'], $index));

	// ... and remove 'Modify' from the Quick Buttons 'More' menu.
	unset($output['quickbuttons']['more']['modify']);

	// Optionally remove 'Quick Edit' from the Quick Buttons menu.
	if (isset($output['quickbuttons']['quick_edit']) && !empty($modSettings['AM2QBM_remove']))
		unset($output['quickbuttons']['quick_edit']);
}

?>
