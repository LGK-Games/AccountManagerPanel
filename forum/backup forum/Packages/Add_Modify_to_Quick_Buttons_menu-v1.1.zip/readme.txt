[center][b][size=12pt]Add Modify to Quick Buttons menu
v1.1[/size][/b][/center]

This mod will add the [i]Modify[/i] button to the Quick Buttons menu and provide an option to remove the [i]Quick Edit[/i] button from the Quick Buttons menu.

[b]Release History[/b]
v1.0 - 25-Sep-24
o Initial release as [i]Replace Quick Edit with Modify[/i].

v1.1 - 28-Sep-24
o As per [url=https://www.simplemachines.org/community/index.php?msg=4180424]this request[/url] made removal of the [i]Quick Edit[/i] button from Quick Buttons menu optional.
o Renamed to [i]Add Modify to Quick Buttons menu[/i].

[color=blue][b][u]License[/u][/b][/color]
Copyright 2024 Kathy Leslie

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
