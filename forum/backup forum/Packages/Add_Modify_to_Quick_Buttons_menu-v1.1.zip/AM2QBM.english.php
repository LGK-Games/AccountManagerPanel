<?php

// Add Modify to Quick Buttons menu
$txt['AM2QBM_remove'] = '<strong><em>Add \'Modify\' to Quick Buttons menu</em></strong><br>Remove <em> \'Quick Edit\' </em> from Quick Buttons menu';

?>
