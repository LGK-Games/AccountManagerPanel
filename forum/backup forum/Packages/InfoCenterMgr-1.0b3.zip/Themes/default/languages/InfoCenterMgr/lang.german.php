<?php

/**
 * @package InfoCenterMgr
*/

$txt['icm_title'] = 'Info Center Manager';
$txt['icm_settings_title'] = 'Info Center Manager-Einstellungen';
$txt['icm_desc'] = 'description text';
$txt['icm_hide_online'] = 'Abschnitt "Benutzer online" unterdrücken';
$txt['icm_limit_recent_posts'] = 'Nur die letzte Antwort pro Thema in "Neueste Beiträge" anzeigen';

?>
