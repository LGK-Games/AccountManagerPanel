<?php

/**
 * @package InfoCenterMgr
 * Spanish translation https://www.bombercode.net Rev 1.0 2022
*/

$txt['icm_title'] = 'Administrador del centro de información';
$txt['icm_settings_title'] = 'Ajustes del administrador del centro de información';
$txt['icm_hide_online'] = 'Ocultar la sección "Usuarios en línea"';
$txt['icm_limit_recent_posts'] = 'Mostrar solo la última respuesta por tema en la sección "Publicaciones recientes"';

?>
