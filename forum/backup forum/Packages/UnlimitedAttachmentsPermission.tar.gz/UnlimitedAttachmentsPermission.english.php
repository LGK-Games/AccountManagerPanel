<?php
$txt['permissionname_unlimited_attachments'] = 'Exempt from attachment limits';
$txt['permissionhelp_unlimited_attachments'] = 'Members with this permission are not subject to the following limits when posting attachments:
<ul class="bbc_list">
	<li>' . $txt['attachmentNumPerPostLimit'] . '</li>
	<li>' . $txt['attachmentSizeLimit'] . '</li>
	<li>' . $txt['attachmentPostLimit'] . '</li>
	<li>' . $txt['attachmentExtensions'] . '</li>
</ul>
<br>
This permission is only useful if the "' . $txt['permissionname_post_attachment'] . '" permission is also enabled.';
?>