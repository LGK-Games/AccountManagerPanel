<?php
/** 
* Brazilian Portuguese (PT-BR) translation by ORIONitos
*/
$txt['permissionname_unlimited_attachments'] = 'Isento de limites de anexo';
$txt['permissionhelp_unlimited_attachments'] = 'Membros com essa  permissão não são obrigados a seguir os limies de tamanho quando postam anexos:
<ul class="bbc_list">
	<li>' . $txt['attachmentNumPerPostLimit'] . '</li>
	<li>' . $txt['attachmentSizeLimit'] . '</li>
	<li>' . $txt['attachmentPostLimit'] . '</li>
	<li>' . $txt['attachmentExtensions'] . '</li>
</ul>
<br>
Essa permissão só é válida se a "' . $txt['permissionname_post_attachment'] . '" também estiver atva.';
?>

