<?php

/*******************************************************************************
 * Unlimited Attachments Permission
 *
 * A modification for Simple Machines Forum that adds a permission to allow
 * membergroups to post attachments on a given board without any limits on their
 * number, size, or file extensions.
 *
 * Copyright (c) 2019 Jon Stovell
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/

if (!defined('SMF'))
	die('No direct access...');

/**
 * Give the admin some control
 * Called by:
 * 		integrate_load_permissions
 */
function unlimited_attachments_permission_setting(&$permissionGroups, &$permissionList, &$leftPermissionGroups, &$hiddenPermissions, &$relabelPermissions)
{
	loadLanguage('UnlimitedAttachmentsPermission');

	$permissionList['board']['unlimited_attachments'] = array(false, 'attachment');
}

/**
 * Give the admin some help
 * Called by:
 * 		integrate_helpadmin
 */
function unlimited_attachments_permission_help()
{
	if (isset($_GET['help']) && substr($_GET['help'], 0, 14) == 'permissionhelp')
	{
		loadLanguage('Admin');
		loadLanguage('UnlimitedAttachmentsPermission');
	}
}

/**
 * Adjusts the relevant $modSettings values if you have the permission
 * Called by:
 * 		integrate_actions
 */
function unlimited_attachments_permission_enable(&$actionArray)
{
	global $modSettings, $user_info, $context;

	// Don't mess with anything if the admin is trying to configure attachment settings
	if (isset($context['current_action']) && $context['current_action'] == 'admin' && isset($context['current_subaction']) && $context['current_subaction'] == 'attachments')
		return;

	if ($user_info['is_admin'] || in_array('unlimited_attachments', $user_info['permissions']))
	{
		// You can upload whatever you want, as many you want, and as big as PHP will let you.
		$modSettings['attachmentSizeLimit'] = floor(memoryReturnBytes(ini_get('upload_max_filesize')) / 1024);
		$modSettings['attachmentPostLimit'] = floor(memoryReturnBytes(ini_get('post_max_size')) / 1024);
		$modSettings['attachmentNumPerPostLimit'] = 0;
		$modSettings['attachmentCheckExtensions'] = 0;
	}
}

/**
 * Mention who made this thing
 * Called by:
 * 		integrate_credits
 */
function unlimited_attachments_permission_credits()
{
	global $context;
	$context['copyrights']['mods'][] = 'Unlimited Attachments Permission by Jon &quot;Sesquipedalian&quot; Stovell &copy; 2019';
}
