<?php
$txt['permissionname_unlimited_attachments'] = 'Geen beperkingen voor bijlagen';
$txt['permissionhelp_unlimited_attachments'] = 'Ledengroepen met deze permissie worden niet beperkt door deze limieten bij het plaatsen van bijlagen:
<ul class="bbc_list">
	<li>' . $txt['attachmentNumPerPostLimit'] . '</li>
	<li>' . $txt['attachmentSizeLimit'] . '</li>
	<li>' . $txt['attachmentPostLimit'] . '</li>
	<li>' . $txt['attachmentExtensions'] . '</li>
</ul>
<br>
Deze permissie heeft alleen nut als deze permissie "' . $txt['permissionname_post_attachment'] . '" ook is toegekend.';
?>