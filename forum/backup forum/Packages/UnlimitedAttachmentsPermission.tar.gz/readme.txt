[size=x-large][b]Unlimited Attachments Permission[/b][/size]

A modification for SMF 2.1 that adds a permission to allow membergroups to post attachments on a given board without any limits on their number, size, or file extensions.


[size=large][b]Settings[/b][/size]

Adds an "Exempt from attachment limits" permission to the board permission profiles available in [b]Administration Center ► Permissions ► Edit Profiles[/b]. The permission can be granted to any given membergroup in any given permission profile.

The permission is always enabled for administrators.


[size=large][b]License[/b][/size]

Unlimited Attachments Permission is released under the MIT License. A full copy of this license is included in the package file.


[size=large][b]Changelog[/b][/size]

Version 1.2:
[list]
	[li]Added Dutch translation[/li]
[/list]

Version 1.1:
[list]
	[li]Added Latin Spanish translation[/li]
	[li]Added Brazilian Portuguese translation[/li]
[/list]

Version 1.0:
[list]
	[li]Initial release[/li]
[/list]