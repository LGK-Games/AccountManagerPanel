<?php
/*Spanish translation https://www.bombercode.net Copyright 2014-2019 */
$txt['permissionname_unlimited_attachments'] = 'Exento de límites de adjuntos';
$txt['permissionhelp_unlimited_attachments'] = 'Los miembros con este permiso no están sujetos a los siguientes límites al publicar archivos adjuntos:
<ul class="bbc_list">
	<li>' . $txt['attachmentNumPerPostLimit'] . '</li>
	<li>' . $txt['attachmentSizeLimit'] . '</li>
	<li>' . $txt['attachmentPostLimit'] . '</li>
	<li>' . $txt['attachmentExtensions'] . '</li>
</ul>
<br>
Este permiso solo es útil si el "' . $txt['permissionname_post_attachment'] . '" permiso también está activado.';
?>