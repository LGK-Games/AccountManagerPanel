[color=red][size=14pt][b]Relative Time Formats[/b][/size][/color] 

[b]For SMF 2.1.x[/b]
[b]Tested only with the SMF default theme![/b]

With this mod can the admin decide how to set the default display of time and date format with a relative one, such as 1 minute ago, 4 hours ago or Sunday at 10:20 etc. 
Individual members can always override these defaults in the "Look and Layout" section of their profile settings 

[color=red][b][size=12pt]License[/size][/b][/color]
 * This SMF modification is subject to the BSD 2-Clause License

[color=red][b][size=12pt]Admin settings[/size][/b][/color]
- Admin->Features and Options->General

[color=red][b][size=12pt]User settings[/size][/b][/color]
- Profile->Look and Layout

[color=red][b][size=12pt]Languages[/size][/b][/color]
- English

[color=red][b][size=12pt]Changelog[/size][/b][/color]
[b]Version 1.2.2 - Dec 7, 2023[/b]
- Fixed logical operators for output timeformat 

[b]Version 1.2.1 - Feb 22, 2022[/b]
- Fixed post linking calender and previews 

[b]Version 1.2 - Feb 16, 2022[/b]
- Fixed that this mod does not break the calendar page 

[b]Version 1.0.1 - Jul 19, 2021[/b]
- Updated installation package to handle more RC releases without emulation 

[b]Version 1.0 - May 30, 2019[/b]
- Initial Release