<?php
/*
 * @package RelativeTimeFormats
 * @version 1.0
 * @author Pipke http://www.simplemachines.org/community/index.php?action=profile;u=314795
 * @copyright Copyright (C) 2019
 * @All rights reserved. 
 * @This SMF modification is subject to the BSD 2-Clause License
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
	exit('<b>Error:</b> Cannot install or uninstall - please verify you put this in the same place as SMF\'s index.php.');

// Mod db-settings
if (!empty($context['uninstalling']))
{
	// Remove rtf db-settings
	$mod_settings = array('rtf_admin_display');
	foreach($mod_settings as $rtf_db_list)
	{
		$smcFunc['db_query']('', '
			DELETE FROM {db_prefix}settings
			WHERE variable = {string:rtf_db}',
			array(
				'rtf_db' => $rtf_db_list,
			)
		);
	}
	// Remove column in members table
	if (!array_key_exists('db_remove_column', $smcFunc))
		db_extend('packages');
	
	$smcFunc['db_remove_column']('{db_prefix}members', 'rtf_user_display');
}
else #installing
{
	// Adding rtf db-settings	
	$mod_settings = array(
		'rtf_admin_display' => 5, 
	);
	updateSettings($mod_settings);
	
	// Add column in members table
	if (!array_key_exists('db_add_column', $smcFunc))
		db_extend('packages');

	$columns = $smcFunc['db_list_columns']('{db_prefix}members');

	if (!in_array('rtf_user_display', $columns)) 
	{
		$smcFunc['db_add_column'](
			'{db_prefix}members',
			array(
				'name' => 'rtf_user_display',
				'size' => 1,
				'type' => 'tinyint',
				'null' => true, 
			)
		);
	}
}

// Prepare hooks
$hook_functions = array(
	'integrate_pre_include' => '$sourcedir/RelativeTimeFormats.php',
	'integrate_load_member_data'=> 'rtf_integrate_load_member_data',
	'integrate_load_profile_fields'=> 'rtf_integrate_load_profile_fields',
	'integrate_setup_profile_context'=> 'rtf_integrate_setup_profile_context',
	'integrate_load_theme'=> 'rtf_integrate_load_theme',
	'integrate_buffer' => 'rtf_integrate_buffer',
	'integrate_theme_context' => 'rtf_integrate_theme_context',
	'integrate_modify_basic_settings' => 'rtf_integrate_modify_basic_settings',
	'integrate_save_basic_settings' => 'rtf_integrate_save_basic_settings',
	'integrate_helpadmin' => 'rtf_integrate_helpadmin',
	'integrate_credits' => 'rtf_integrate_credits',
	);

// Adding or removing hooks
if (!empty($context['uninstalling']))
	$request = 'remove_integration_function';
else
	$request = 'add_integration_function';

// Carrying out the hooks
foreach ($hook_functions as $hook => $function)
	$request($hook, $function);

?>