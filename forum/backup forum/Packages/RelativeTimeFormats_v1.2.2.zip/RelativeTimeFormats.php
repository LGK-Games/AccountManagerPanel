<?php
/*
 * @package RelativeTimeFormats
 * @version 1.2.2
 * @author Pipke http://www.simplemachines.org/community/index.php?action=profile;u=314795
 * @copyright Copyright (C) 2022
 * @All rights reserved. 
 * @This SMF modification is subject to the BSD 2-Clause License
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

if (!defined('SMF'))
	die('Hacking attempt...');

// Initialize the template...look for the time/date	
function rtf_integrate_load_theme()
{
	global $context, $user_settings, $user_info, $modSettings;
	
	// Don't do dirty when uninstalling
	if (isset($_REQUEST['sa']) && $_REQUEST['sa'] == 'uninstall2')
		return;
	
	// skip calender && post page
	if ($context['current_action'] == 'calendar' || $context['current_action'] == 'post' )
		return;
	
	// skip xml previews
	if (isset($_REQUEST['xml']))
		return;
	
	// Time title attribute
	$time_title = $user_info['time_format'];
	
	// If user has set there own preferences use it!
	if (isset($user_settings['rtf_user_display']))
		$context['rtf_user_display'] = $user_settings['rtf_user_display'];
	else ## guest or default admin choice
		$context['rtf_user_display'] = $modSettings['rtf_admin_display'];		

	// Here we go relative...
	if ($context['rtf_user_display'] > 1 )
	{
		// Set all page printed time/date to rtf identifier
		$user_info['time_format'] = '<time title="'.$time_title.'">data-rtf-time="%Y-%m-%d %H:%M:%S"</time>';
		
		// This user choice can't work with this smf setting, we disable it 
		$modSettings['todayMod'] = false;
	}	
}

// Admin layout settings 
function rtf_integrate_modify_basic_settings(&$config_vars)
{
	global $txt;

	// Mod language
	loadLanguage('RelativeTimeFormats');
	
	// The select box
	$setting[] = array('select', 'rtf_admin_display', 
		array(
			'1' => $txt['rtf_1'], 
			'2' => $txt['rtf_2'], 
			'3' => $txt['rtf_3'], 
			'4' => $txt['rtf_4'], 
			'5' => $txt['rtf_5'], 
			'6' => $txt['rtf_6'], 
			'7' => $txt['rtf_7']
		)
	);
			
	$config_vars[] = array_splice($config_vars, 19, 0, $setting); ## before $config_var key[19] => time_offset	
}
// Admin save settings  
function rtf_integrate_save_basic_settings()
{
	if (empty($_POST['rtf_admin_display']))
		$_POST['rtf_admin_display'] = array();

	updateSettings(array('rtf_admin_display' => $_POST['rtf_admin_display']));
}
	
// Help info button admin
function rtf_integrate_helpadmin()
{
	// Mod language
	loadLanguage('RelativeTimeFormats');
}

// Display these time/date context (no transform) as default format
function rtf_integrate_theme_context()
{
	global $context;
	
	// Strip the identifier tags of current_time and local_time
	if (isset($context['rtf_user_display']))
	{
		// Current time 
		if (isset($context['current_time'])) 
		{
			$context['current_time'] = ltrim($context['current_time'],"<time>"); ## string-> remove <time> tags, we dont want this to be found
			$context['current_time'] = substr($context['current_time'], 0, strpos($context['current_time'], '">')); ## string-> remove everything with and after ">
			$context['current_time'] = str_replace('title="', '', $context['current_time']); ## string-> remove title="
		}
		// Local time 
		if (isset($context['member']['local_time'])) 
		{
			$context['member']['local_time'] = ltrim($context['member']['local_time'],"<time>"); 
			$context['member']['local_time'] = substr($context['member']['local_time'], 0, strpos($context['member']['local_time'], '">')); 
			$context['member']['local_time'] = str_replace('title="', '', $context['member']['local_time']); 
		}
	}
}

function rtf_integrate_load_member_data(&$select_columns)
{
	// Load db choice
	$select_columns.=', mem.rtf_user_display';
	
}

// User options
function rtf_integrate_load_profile_fields(&$profile_fields)
{	
	global $txt, $cur_profile, $modSettings, $scripturl;
	
	// Mod language
	loadLanguage('RelativeTimeFormats');
		
	// Check if user has set time display, else use admin default
	if (empty($cur_profile['rtf_user_display']))
		$cur_profile['rtf_user_display'] = $modSettings['rtf_admin_display'];
	
	// Find the admin default option choice
	$txt['rtf_'.$modSettings['rtf_admin_display']] = $txt['rtf_'.$modSettings['rtf_admin_display']].' '.$txt['timeformat_default']; 
	
	$profile_fields['rtf_user_display'] = array(
		'type' => 'select',
		'subtext' => '<a href="' . $scripturl . '?action=helpadmin;help=rtf_user_display" onclick="return reqOverlayDiv(this.href);" title="'. $txt['help']. '"><span class="main_icons help"></span></a> ' . $txt['rtf_date_format'],
		'options' => array(
			'1' => $txt['rtf_1'], 
			'2' => $txt['rtf_2'],  
			'3' => $txt['rtf_3'], 
			'4' => $txt['rtf_4'],  
			'5' => $txt['rtf_5'],  
			'6' => $txt['rtf_6'],  				
			'7' => $txt['rtf_7']
		),
		'permission' => 'profile_extra',
		'label' => $txt['rtf_admin_display'],
	);
}

function rtf_integrate_setup_profile_context(&$fields) 
{
	// Show it only on the theme edit profile page please
	if (isset($_REQUEST['area']) && $_REQUEST['area'] == 'theme')
		array_splice($fields, 4, 0, 'rtf_user_display'); ## before $fields key[4] => timezone	
}

// The magic	
function rtf_integrate_buffer($rtf_time)
{
	$find = array(	
		'~data-rtf-time="(.*)"</time>~',  // 0
		'~(data-rtf-time="{$time_id}")~', // 1
	);
		
	// Find all time format outputs
	$time_ids = preg_match_all($find[0], $rtf_time, $matches) ? array_unique($matches[1]) : array();
	
	// Transform it ;)	
	foreach ($time_ids as $time_id ) {
		$time_output = strtotime($time_id);
		$rtf_time = preg_replace(str_replace('{$time_id}', $time_id, $find[1]), rtf_time_transform($time_output), $rtf_time);
	}
	
	return $rtf_time;
}

// Relative Time Formats Transform
function rtf_time_transform($time)
{
    global $context, $txt;
	
	// Mod language
	loadLanguage('RelativeTimeFormats');
	
	// Not set any choice, then go back
	if (!$context['rtf_user_display'] || $context['rtf_user_display'] == 1)
		return;
	
	// The elapsed amount of time in seconds (integers only please!)
    $elapsed = time() - floor($time);
    
	// Is there any real difference?
    if ($elapsed < 5) { 
		return $txt['rtf_just_now']; 
	}
    
	// Setup an array of all possible time differences to check against
    $times = array (
        12 * 30 * 24 * 60 * 60  =>  'yr', // year
        30 * 24 * 60 * 60       =>  'mh', // month
        07 * 24 * 60 * 60       =>  'wk', // week
        24 * 60 * 60            =>  'dy', // day
        60 * 60                 =>  'hr', // hour
        60                      =>  'me', // minute
        1                       =>  'sd' ); //second
    
	// Setup a return string
    $return = '';
	$i = 0;
    
	// Loop through all of the time "constants"
    foreach ($times as $seconds => $string)
    {       
		// Get the difference
        $difference = floor($elapsed / $seconds);
		
        // Is there an actual (positive) difference?
        if ($difference >= 1)
        {
            // Add this difference to the return string. 
            $return .= " $difference $string" . ($difference > 1 ? 's' : '') . ',';	
			
			// Should we continue adding all possible differences?
			if ($i == $context['rtf_user_display'] -2) 
				break;
			
			if ($context['rtf_user_display'] > 3)
				break;
			 
   			$i++;
            
			// Subtract this difference from the total elapsed for the next loop
            $elapsed -= $difference * $seconds;
        }		
    }
	
	$return = explode(',', $return);
	
	// Short relative
	if ($context['rtf_user_display'] > 3) {
		if ($string === 'dy' || $string === 'dys') { 
			if ($return[0] === ' 1 dy')
				$format = $txt['rtf_yesterday_at'].($context['rtf_user_display'] == 4 || $context['rtf_user_display'] == 6 ? ' %I:%M %p' : ' %H:%M');
			else
				$format = '%A '.$txt['at'].($context['rtf_user_display'] == 4 || $context['rtf_user_display'] == 6 ? ' %I:%M %p' : ' %H:%M');
				
			return(timeformat($time, $format)); 
		}
		if ($string === 'wk' || $string === 'wks' || $string === 'mh' || $string === 'mhs') { 
				$format = $context['rtf_user_display'] > 5 ? '%B %e' : '%e %B';
			
			return(timeformat($time, $format)); 
		}
		if ($string === 'yr' || $string === 'yrs') { 
				$format = $context['rtf_user_display'] > 5 ? '%B %e, %Y' : '%e %B, %Y';
			
			return(timeformat($time, $format)); 
		}
	}
	
	// Your language
	$replacements = array(',', 'yrs', 'yr', 'mhs', 'mh', 'wks', 'wk', 'dys', 'dy', 'hrs', 'hr', 'mes', 'me', 'sds', 'sd');
	$replacements2 = array($txt['rtf_and'], $txt['rtf_years'], $txt['rtf_year'], $txt['rtf_months'], $txt['rtf_month'], $txt['rtf_weeks'], $txt['rtf_week'], $txt['rtf_days'], $txt['rtf_day'], $txt['rtf_hours'], $txt['rtf_hour'], $txt['rtf_minutes'], $txt['rtf_minute'], $txt['rtf_seconds'], $txt['rtf_second']);

    // Strip the final comma from the string before returning it
    $return = substr(implode(',',$return), 0, -1) .' '. $txt['rtf_ago'];
	
	return(str_replace($replacements, $replacements2, $return));
}

// Show the hard work
function rtf_integrate_credits()
{
	global $context;
	
	$context['copyrights']['mods'][] = 'RelativeTimeFormats v1.2.2 | &copy 2022 by <a href="http://www.simplemachines.org/community/index.php?action=profile;u=314795">Pipke</a>';	
}

?>