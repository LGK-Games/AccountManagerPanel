<?php
/*
 * @package RelativeTimeFormats
 * @version 1.0
 * @author Pipke http://www.simplemachines.org/community/index.php?action=profile;u=314795
 * @copyright Copyright (C) 2019
 * @All rights reserved. 
 * @This SMF modification is subject to the BSD 2-Clause License
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

global $helptxt;

$rtf_helpadmin_options = 'Option examples when the current time is \'May 28, 2019, 10:02:30 PM\'<br>
	<span class="smalltext">
		<fieldset style="padding: 6px;"><legend style="padding-left: 2px; padding-right: 2px;">Absolute format:</legend>
			Display according your PHP\'s strftime function time format setting.
		</fieldset>
		<fieldset style="padding: 6px;"><legend style="padding-left: 2px; padding-right: 2px;">Relative with one time difference format:</legend>
			May 28, 2019, 10:04:31 PM &#10233; 2 minutes ago<br>
			May 28, 2019, 03:44:31 PM &#10233; 6 hours ago<br>
			May 27, 2019, 09:44:28 PM &#10233; 1 day ago<br>
			May 23, 2019, 04:02:02 AM &#10233; 5 days ago<br>
			May 28, 2018, 10:18:59 PM &#10233; 1 year ago
		</fieldset>
		<fieldset style="padding: 6px;"><legend style="padding-left: 2px; padding-right: 2px;">Relative with two time differences format:</legend>
			May 28, 2019, 10:04:31 PM &#10233; 2 minutes and 12 seconds ago<br>
			May 28, 2019, 03:44:15 PM &#10233; 6 hours and 18 minutes ago<br>
			May 27, 2019, 09:44:28 PM &#10233; 1 day and 18 minutes ago<br>
			May 23, 2019, 04:02:02 AM &#10233; 5 days and 18 hours ago<br>
			May 28, 2018, 10:18:59 PM &#10233; 1 year and 5 days ago
		</fieldset>
		<fieldset style="padding: 6px;"><legend style="padding-left: 2px; padding-right: 2px;">Relative based on {time format}:</legend>
			May 28, 2019, 10:04:31 PM &#10233; 2 minutes ago<br>
			May 28, 2019, 03:44:15 PM &#10233; 6 hours ago<br>
			May 27, 2019, 09:44:28 PM &#10233; Yesterday at 21:44<br>
			May 23, 2019, 04:02:02 AM &#10233; Thursday at 04:02<br>
			May 05, 2019, 11:32:06 AM &#10233; May 05<br>
			May 28, 2018, 10:18:59 PM &#10233; May 28, 2018
		</fieldset>
	</span>';

$helptxt['rtf_admin_display'] = 'This setting lets the admin decide how to display time and date format.<br>Individual members can always override these defaults in the "Look and Layout" section of their profile settings.<br>'.$rtf_helpadmin_options;
$helptxt['rtf_user_display'] = '<strong>Display time and date format as:</strong><br>You have the ability to set how the time and date display for yourself.<br>'.$rtf_helpadmin_options;

$txt['rtf_date_format'] = 'The choice here will be used to display time and date throughout this forum.';
$txt['rtf_admin_display'] = 'Display time and date format as:';
$txt['rtf_year'] = 'year';
$txt['rtf_years'] = 'years';
$txt['rtf_month'] = 'month';
$txt['rtf_months'] = 'months';
$txt['rtf_week'] = 'week';
$txt['rtf_weeks'] = 'weeks';
$txt['rtf_day'] = 'day';
$txt['rtf_days'] = 'days';
$txt['rtf_hour'] = 'hour';
$txt['rtf_hours'] = 'hours';
$txt['rtf_minute'] = 'minute';
$txt['rtf_minutes'] = 'minutes';
$txt['rtf_second'] = 'second';
$txt['rtf_seconds'] = 'seconds';
$txt['rtf_and'] = ' and ';
$txt['rtf_ago'] = 'ago';
$txt['rtf_just_now'] = 'just now';
$txt['rtf_yesterday_at'] = 'Yesterday at';
$txt['rtf_about'] = 'about';
$txt['rtf_1'] = 'Absolute format';
$txt['rtf_2'] = 'Relative with one time difference format';
$txt['rtf_3'] = 'Relative with two time differences format';
$txt['rtf_4'] = 'Relative based on \'Day Month, Year HH:MM am/pm\'';
$txt['rtf_5'] = 'Relative based on \'Day Month, Year HH:MM 24 hour\'';
$txt['rtf_6'] = 'Relative based on \'Month Day, Year HH:MM am/pm\'';
$txt['rtf_7'] = 'Relative based on \'Month Day, Year HH:MM 24 hour\'';

// SMF default text string overwrite
$txt['date_format'] = 'The format here will also be used to display the current, local and the \'title\' dates.';

?>
