This mod will display top posters, top topic starters and top topics of your forum on the index page.

You can enable/disable the mod at its settings page in the Admin Panel as well as set the stats limit and decide how to order top topics display, which is based on their views or replies.

If you have any questions do not hesitate to post them in the mod 's support topic.

This mod is released under Mozilla Public License 2.0 (MPL-2.0).