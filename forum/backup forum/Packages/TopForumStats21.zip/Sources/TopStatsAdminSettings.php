<?php

// If we are outside SMF throw an error.
if (!defined('SMF'))
	die('Hacking attempt...');

//Add mod settings in admin panel.	
function TopStatsAdminArea(&$admin_areas)
{
	global $txt;
	
	return $admin_areas['config']['areas']['modsettings']['subsections'] += array('topstats' => array(sprintf($txt['topstats_settings'])));
}

//Add action for settings.
function TopStatsSubAction(&$subActions)
{
	return $subActions += array('topstats' => 'TopStatsSettings');
}

//Settings.
function TopStatsSettings($return_config = false) 
{
	global $context, $txt, $scripturl, $modSettings, $settings;

	$context['page_title'] = $txt['topstats_settings'];
	
	$config_vars = array(
		array('check', 'enable_top_stats'),
		array('select', 'top_stats_topic_order', array('views' => $txt['views'], 'replies' => $txt['replies'])),
		array('int', 'top_stats_limit'),
	);

	if ($return_config)
		return $config_vars;
	
	if (isset($_GET['save'])) 
	{
		checkSession();

		saveDBSettings($config_vars);
		writeLog();

		redirectexit('action=admin;area=modsettings;sa=topstats');
	}

	$context['post_url'] = $scripturl . '?action=admin;area=modsettings;save;sa=topstats';

	prepareDBSettingContext($config_vars);
}