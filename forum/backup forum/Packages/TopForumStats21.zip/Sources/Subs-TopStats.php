<?php

// If we are outside SMF throw an error.
if (!defined('SMF'))
	die('Hacking attempt...');

//Load our custom language.
function load_top_stats_language()
{
	loadLanguage('TopStats');
}

//Display top stats on forum index.
function display_forum_top_stats()
{
	global $context;
	
    if (!isset($_GET['xml']) && !isset($_GET['action']) && !isset($_GET['topic']) && !isset($_GET['board']))
	{
		loadTemplate('TopStats');
		$context['template_layers'][] = 'top_stats';
		DisplayTopStats();
	}
}

//Get top stats.	
function DisplayTopStats()
{
	global $smcFunc, $context, $modSettings, $txt, $scripturl;
	
	$orderby = (isset($modSettings['top_stats_topic_order']) && $modSettings['top_stats_topic_order'] == "views" ) ? 'views' : 'replies';
	$limit = (!empty($modSettings['top_stats_limit'])) ? $modSettings['top_stats_limit'] : 5;

	$context['topics_order'] = ($orderby == 'views') ? $txt['views'] : $txt['replies'];
	
	//Get top posters.
	$members_result = $smcFunc['db_query']('', '
		SELECT mem.id_member, mem.real_name, mem.posts, mg.online_color
		FROM {db_prefix}members AS mem
		LEFT JOIN {db_prefix}membergroups mg ON (mem.id_group = mg.id_group)
		WHERE mem.posts > {int:no_posts}
		ORDER BY mem.posts DESC
		LIMIT {int:limit}',
		array(
		      'no_posts' => 0,
			  'limit' => $limit,
		)
	);
	
	$context['top_posters'] = array();
	
	while ($row = $smcFunc['db_fetch_assoc']($members_result))
	{
		 $row['real_name'] = shorten_subject($row['real_name'], 6);
		
		$context['top_posters'][] = array(
			'name' => $row['real_name'],
			'id' => $row['id_member'],
			'posts' => $row['posts'],
			'href' => $scripturl . '?action=profile;u=' . $row['id_member'],
			'link' => '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '" style="color: ' . $row['online_color'] . ';">' . $row['real_name'] . '</a>'
		);

	}

	 //Get top topic starters.
	if (($members = cache_get_data('top_stats_topics', 360)) == null)
	{
		$request = $smcFunc['db_query']('', '
			SELECT id_member_started, COUNT(*) AS hits
			FROM {db_prefix}topics' . (!empty($modSettings['recycle_enable']) && $modSettings['recycle_board'] > 0 ? '
			WHERE id_board != {int:recycle_board}' : '') . '
			GROUP BY id_member_started
			ORDER BY hits DESC
			LIMIT {int:limit}',
			array(
				'recycle_board' => $modSettings['recycle_board'],
				'limit' => $limit,
			)
		);
		
		$members = array();
		
		while ($row = $smcFunc['db_fetch_assoc']($request))
		{	
			$members[$row['id_member_started']] = $row['hits'];
		}
		
		$smcFunc['db_free_result']($request);

		cache_put_data('top_stats_topics', $members, 360);
	}

	if (empty($members))
		$members = array(0 => 0);

	// Topic poster top 10.
	$members_result = $smcFunc['db_query']('top_topic_starters', '
		SELECT mem.id_member, mem.real_name, mg.online_color
		FROM {db_prefix}members AS mem
		LEFT JOIN {db_prefix}membergroups mg ON (mem.id_group = mg.id_group)
		WHERE mem.id_member IN ({array_int:member_list})
		ORDER BY FIND_IN_SET(mem.id_member, {string:top_topic_posters})
		LIMIT {int:limit}',
		array(
			'member_list' => array_keys($members),
			'top_topic_posters' => implode(',', array_keys($members)),
			'limit' => $limit,
		)
	);
	
	$context['top_topicers'] = array();
	
	while ($row = $smcFunc['db_fetch_assoc']($members_result))
	{
		$row['real_name'] = shorten_subject($row['real_name'], 6);
		
		$context['top_topicers'][] = array(
			'name' => $row['real_name'],
			'id' => $row['id_member'],
			'topics' => $members[$row['id_member']],
			'href' => $scripturl . '?action=profile;u=' . $row['id_member'],
			'link' => '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '" style="color: ' . $row['online_color'] . ';">' . $row['real_name'] . '</a>'
		);
	}
	
	$smcFunc['db_free_result']($members_result);
   
    //Get most viewed/replied topics.
	$top_topics = $smcFunc['db_query']('', '
		 SELECT t.id_topic, t.id_board, m.subject, m.id_topic, m.poster_time, IFNULL(mem.real_name, m.poster_name) AS poster_name, t.num_views, t.num_replies, m.id_member, mg.online_color
		 FROM {db_prefix}topics as t
		 INNER JOIN {db_prefix}messages AS m ON (m.id_msg = t.id_first_msg)
		 INNER JOIN {db_prefix}boards AS b ON (b.id_board = t.id_board)
		 LEFT JOIN {db_prefix}membergroups AS mg ON (mg.id_group = m.id_member)
		 LEFT JOIN {db_prefix}members AS mem ON (mem.id_member = m.id_member)
		 WHERE {query_wanna_see_board}' . ($modSettings['postmod_active'] ? '
		 AND t.approved = {int:is_approved}' : '') . (!empty($modSettings['recycle_enable']) && $modSettings['recycle_board'] > 0 ? '
		 AND b.id_board != {int:recycle_enable}' : '') . '
		 ORDER BY t.num_' . $orderby . ' DESC
		 LIMIT {int:limit}',
			   array(
					 'limit' => $limit,
					 'is_approved' => 1,
					 'recycle_enable' => $modSettings['recycle_board'],
				    )
			    );
			
	   $context['top_topics'] = array();
	
       while ($row = $smcFunc['db_fetch_assoc']($top_topics))
       {
		 $row['subject'] = shorten_subject($row['subject'], 20); 
		
		 $row['poster_name'] = shorten_subject($row['poster_name'], 6);
	        
         $context['top_topics'][] = array(
		      'link' => '<a href="' . $scripturl . '?topic=' . $row['id_topic'] . '.new;topicseen#new">' . $row['subject'] . '</a>',
              'time' => timeformat($row['poster_time']),
		      'starter' => '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '" style="color: ' . $row['online_color'] . ';">' . $row['poster_name'] . '</a>',
			  'orderby' => ($orderby == 'views') ? $row['num_views'] : $row['num_replies'],
         );
       }
   
       $smcFunc['db_free_result']($top_topics);
}