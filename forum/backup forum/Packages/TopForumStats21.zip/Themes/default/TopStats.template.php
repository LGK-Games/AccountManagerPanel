<?php

//Our custom template to display the top stats.
function template_top_stats_above()
{
     global $context, $modSettings, $txt;

	 //Display forum top stats.
     if (!empty($modSettings['enable_top_stats']))
     {	  
            echo '<br />
            <div class="cat_bar">
			<h3 class="catbg" style = "text-align:center">
				<span class="main_icons stats"></span>', $context['forum_name'], ' - ', $txt['top_stats_title'], '
			</h3>
		    </div>
		    <div class="roundframe">
            <table class="table_grid">
                <tr class="title_bar">
                     <th width="15%">' . $txt['top_posters_list'] . '</th>
                     <th width="15%">' . $txt['top_topic_starters_list'] . '</th>
                     <th width="75%">' . $txt['top_topics_list'] . '</th>
                </tr>
                    <tr class="windowbg">
                      <td width="15%" valign="top">
            <table width="100%">';
            
			//Get top posters.
            foreach ($context['top_posters'] AS $posters)
            {
                echo '
                      <tr>
                          <td width="50%">', $posters['link'], '</td>
                          <td width="50%" align="right">', $posters['posts'], '</td> 
                      </tr>'; 
            }
            echo '
            </table>
                  </td>
                     <td width="15%" valign="top">
           <table width="100%">';

           //Get top topic starters.
           foreach ($context['top_topicers'] AS $topicers)
           {
               echo '
                     <tr>
                         <td width="50%">', $topicers['link'], '</td>
                         <td width="50%" align="right">', $topicers['topics'], '</td>
                     </tr>'; 
          }
          echo '
          </table>
                 </td>
                    <td width="70%" valign="top">
         <table width="100%">';

         //Get most viewed/replied topics.
         foreach ($context['top_topics'] AS $topic)
         {
              echo '
                    <tr>
                        <td width="45%" valign="top">', $topic['link'], ' - '.$topic['orderby'].' '.$context['topics_order'].'</td>
                        <td width="15%" align="right" style = "text-align:center" valign="top">', $txt['by'], ' ', $topic['starter'],'</td>
                        <td width="40%" align="right" valign="top">', $topic['time'], '</td>
                    </tr>';
         }
         echo '
		 </table></td></tr></table>
            </div><span class="botslice"><span></span></span><br />'; 
    }
}

function template_top_stats_below()
{
    
}