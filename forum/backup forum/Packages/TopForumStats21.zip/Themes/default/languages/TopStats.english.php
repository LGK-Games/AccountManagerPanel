<?php

//Language strings.
global $modSettings;

$txt['top_posters_list'] = 'Top Posters';
$txt['top_topic_starters_list'] = 'Top Topicers';
$txt['top_topics_list'] = 'Top Topics';
$txt['topstats_settings'] = 'Board Stats Settings';
$txt['enable_top_stats'] = 'Enable Mod <div class="smalltext">Here you can enable/disable the mod.</div>';
$txt['top_stats_topic_order'] = 'Topics Order By Criteria <div class="smalltext">This field controls the display order of topics. By default it set to be ordered by views.</div>';
$txt['top_stats_limit'] = 'Board Stats Limit <div class="smalltext">This field controls the number of stats that will be displayed. By default it is set to show 5.</div>';
$txt['top_stats_title'] = 'Top '.$modSettings['top_stats_limit'].' Stats';