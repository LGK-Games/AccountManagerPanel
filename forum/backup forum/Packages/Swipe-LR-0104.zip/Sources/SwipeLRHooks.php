<?php
/**
 *	Logic for the Swipe LR mod hooks.
 *
 *	Copyright 2024 Shawn Bulen
 *
 *	The Swipe LR mod is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This software is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this software.  If not, see <https://www.gnu.org/licenses/>.
 *
 */

// If we are outside SMF throw an error.
if (!defined('SMF')) {
	die('Hacking attempt...');
}

/**
 *
 * Hook function - Load the javascript.
 *
 * Hook: integrate_load_theme
 *
 * @return null
 */

function swipe_lr_load_js()
{
	loadJavaScriptFile('swipe_lr.js', array('minimize' => true));
}
