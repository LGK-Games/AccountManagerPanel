<?php

/*************************************************************************************************************
* Subs-RTbQE.php - Subs for Remove Topic beside Quick Edit (v1.0)
**************************************************************************************************************
* This mod is licensed under the 2-Clause BSD License, which can be found here:
*	https://opensource.org/licenses/BSD-2-Clause
**************************************************************************************************************
* Copyright (c) 2024 Rumpa
* Redistribution and use in source and binary forms, with or without modification, are permitted provided
* that the following conditions are met:
*	1.	Redistributions of source code must retain the above copyright notice, this list of conditions
*		and the following disclaimer.
*	2.	Redistributions in binary form must reproduce the above copyright notice, this list of conditions and
*		the following disclaimer in the documentation and/or other materials provided with the distribution.
* This software is provided by the copyright holders and contributors "as is" and any express or implied
* warranties, including, but not limited to, the implied warranties of merchantability and fitness for a
* particular purpose are disclaimed. In no event shall the copyright holder or contributors be liable for
* any direct, indirect, incidental, special, exemplary, or consequential damages (including, but not
* limited to, procurement of substitute goods or services; loss of use, data, or profits; or business
* interruption) however caused and on any theory of liability, whether in contract, strict liability, or
* tort (including negligence or otherwise) arising in any way out of the use of this software, even if
* advised of the possibility of such damage.
*************************************************************************************************************/

//============================================================================================================
// Function for adding 'Remove Topic' button beside 'Quick Edit' button when editing a message.
// Called as hook by 'integrate_prepare_display_context' in ./Sources/Display.php.
//============================================================================================================
function RTbQE_displayContext(&$output)
{
	global $context, $scripturl, $txt;

	// 'Remove Topic' button definition copied from ./Sources/Display.php
	$removetopicButton = array(
                 'remove_topic' => array(
				     'label' => $txt['remove_topic'],
				      'href' => $scripturl.'?action=removetopic2;topic='.$context['current_topic'].'.'.$context['start'].';'.$context['session_var'].'='.$context['session_id'],
				      'javascript' => 'data-confirm="'.$txt['are_sure_remove_topic'].'"',
				       'class' => 'you_sure',
				       'icon' => 'remove_button',
				       'show' => $context['can_delete'] && ($context['topic_first_message'] == $output['id'])
			        ),
                  'remove' => array(
				     'label' => $txt['remove'],
				     'href' => $scripturl.'?action=deletemsg;topic='.$context['current_topic'].'.'.$context['start'].';msg='.$output['id'].';'.$context['session_var'].'='.$context['session_id'],
				      'javascript' => 'data-confirm="'.$txt['remove_message_question'].'"',
				      'class' => 'you_sure',
				      'icon' => 'remove_button',
				      'show' => $output['can_remove'] && ($context['topic_first_message'] != $output['id'])
			),
				);

	// Add the 'Remove Topic' button to the quick buttons menu.
	$index = array_search('quick_edit', array_keys($output['quickbuttons'])) + 1;
	$output['quickbuttons'] = array_merge(array_slice($output['quickbuttons'], 0, $index), $removetopicButton, array_slice($output['quickbuttons'], $index));

	// Remove the 'Remove Topic' button from the quick buttons 'More' menu.
	unset($output['quickbuttons']['more']['remove_topic']);
}

?>
