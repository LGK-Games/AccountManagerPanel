<?php

// If we are outside SMF throw an error.
if (!defined('SMF'))
{
	die('Hacking attempt...');
}

//Show the link to their liked content on member menu popup.
function My_Given_Likes_Profile_Popup(array &$profile_items)
{
	global $txt;

	$counter = 0;
	
	// Now check if these items are available.
	foreach ($profile_items as $item) 
	{
		$counter++;

		if ($item['area'] === 'showdrafts')
		{	
			break;
		}	
	}

	$profile_items = array_merge(
		array_slice($profile_items, 0, $counter, true),
			array(
				array(
					'menu'  => 'info',
					'area'  => 'mylikedcontent',
					'title' => $txt['my_liked_content']
				)
			),
			
		array_slice($profile_items, $counter, null, true)
	);
}

//Show the link to their liked content on their profiles.
function My_Given_Likes_Profile_Areas(&$profile_areas)
{
	global $txt, $context;
	
	loadLanguage('MyGivenLikes');

	$profile_areas['info']['areas'] += array(
		'mylikedcontent' => array(
			'label' => $txt['my_liked_content'],
			'function' => 'ContentILiked',
			'icon' => 'like',
			'enabled' => $context['user']['is_owner'],
			'permission' => array(
				'own' => 'profile_view_own'
			)
		),
	);
}

//Display to members all the posts that they liked.
function ContentILiked($memID)
{
	global $context, $user_profile, $sourcedir, $scripturl, $txt;

	$context['current_member'] = $memID;

	$context['page_title'] = $txt['my_liked_content'] . ' - ' . $user_profile[$memID]['real_name'];
	
	$context[$context['profile_menu_name']]['tab_data'] = array(
		'title' => $txt['my_liked_content'],
		'description' => $txt['my_liked_content_desc'],
		'icon' => 'like',
	);
	
	$listOptions = array(
		'id' => 'liked_content_list',
		'items_per_page' => 20,
		'base_href' => $scripturl . '?action=profile;area=mylikedcontent;u=' . $memID,
		'default_sort_col' => 'like_time',
		'no_items_label' => $txt['no_content_liked_yet_by_you'],
		'get_items' => array(
			'function' => 'list_getAllMyLikedContent',
		),
		'get_count' => array(
			'function' => 'list_countAllMyLikedContent',
		),
		'columns' => array(
			'id_msg' => array(
				'header' => array(
					'value' => $txt['liked_post_id'],
				),
				'data' => array(
					'db' => 'id_msg',
					'class' => 'centertext'
				),
				'sort' =>  array(
					'default' => 'id_msg',
					'reverse' => 'id_msg DESC',
				),
			),
			'subject' => array(
				'header' => array(
					'value' => $txt['liked_posts_topic'],
				),
				'data' => array(
					'db' => 'subject',
					'class' => 'centertext'
				),
				'sort' =>  array(
					'default' => 'subject',
					'reverse' => 'subject DESC',
				),
			),
			'like_time' => array(
				'header' => array(
					'value' => $txt['like_time'],
				),
				'data' => array(
					'db' => 'like_time',
					'class' => 'centertext'
				),
				'sort' =>  array(
					'default' => 'like_time',
					'reverse' => 'like_time DESC',
				),
			),
        ),
	);

	require_once($sourcedir . '/Subs-List.php');
	createList($listOptions);

	$context['sub_template'] = 'show_list';
	$context['default_list'] = 'liked_content_list';	
}

//Get all the posts liked by members.
function list_getAllMyLikedContent($start, $items_per_page, $sort)
{
	global $smcFunc, $context, $scripturl;

	$results = $smcFunc['db_query']('', '
		SELECT lc.id_member, lc.content_id, lc.content_type, lc.like_time, 
		m.id_msg, m.subject
		FROM {db_prefix}user_likes AS lc
		INNER JOIN {db_prefix}messages AS m ON (m.id_msg = lc.content_id)
		INNER JOIN {db_prefix}topics AS t ON (t.id_topic = m.id_topic)
		WHERE lc.id_member = {int:id_member}
		AND lc.content_type = {string:like_type}
		AND m.approved = {int:approved}
		ORDER BY {raw:sort}
		LIMIT {int:start}, {int:per_page}',
		array(
			'id_member' => $context['current_member'],
			'like_type' => 'msg',
			'approved' => 1,
			'sort' => $sort,
		    'start' => $start,
			'per_page' => $items_per_page,
		    )
	);

	$myLikedPosts = array();
	
	while ($row = $smcFunc['db_fetch_assoc']($results))
	{
		$myLikedPosts[] = array(
			'id_msg' => '<a href="' . $scripturl . '?msg=' . $row['id_msg'] . '"> # ' . $row['id_msg'] . '</a>',
			'subject' => '<a href="' . $scripturl . '?msg=' . $row['id_msg'] . '">' . $row['subject'] . '</a>',
			'like_time' => timeformat($row['like_time']),
		);
	}

	$smcFunc['db_free_result']($results);
	
	return $myLikedPosts;
}

//Do the count thing for the pagination.
function list_countAllMyLikedContent()
{
	global $smcFunc, $context;

	$results = $smcFunc['db_query']('', '
		SELECT COUNT(*)
		FROM {db_prefix}user_likes AS lc
		INNER JOIN {db_prefix}messages AS m ON (m.id_msg = lc.content_id)
		WHERE lc.id_member = {int:id_member}
		AND lc.content_type = {string:like_type}
		AND m.approved = {int:approved}',
		array(
			'id_member'  => $context['current_member'],
			'like_type'  => 'msg',
			'approved' => 1
			)
	);

	list ($count) = $smcFunc['db_fetch_row']($results);
	
    $smcFunc['db_free_result']($results);

	return $count;
}