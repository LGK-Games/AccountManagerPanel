<?php

//Require ssi.php file.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
{
	$ssi = true;
	require_once(dirname(__FILE__) . '/SSI.php');
}

// Can' t be defined outside of smf.
elseif (!defined('SMF'))
{
	exit('<strong>Error:</strong> Cannot install - please verify you put this in the same place as SMF\'s index.php.');
}

$hook_functions = array(
	'integrate_pre_include' => '$sourcedir/Subs-MyGivenLikes.php',
	'integrate_profile_popup' => 'My_Given_Likes_Profile_Popup',
	'integrate_pre_profile_areas' => 'My_Given_Likes_Profile_Areas',
);

if (!empty($context['uninstalling']))
{
	$call = 'remove_integration_function';
}
else
{
	$call = 'add_integration_function';
}

foreach ($hook_functions as $hook => $function)
{
	$call($hook, $function);
}	

if (!empty($ssi))
{
	echo 'Congratulations! You have successfully installed this mod!';
}