<?php

//Language strings for the mod.

$txt['my_liked_content'] = 'Posts I liked';
$txt['my_liked_content_desc'] = 'Here you can see all the posts that you have liked.';
$txt['no_content_liked_yet_by_you'] = 'You have not liked any posts yet!';
$txt['liked_post_id'] = 'Post ID';
$txt['liked_posts_topic'] = 'Topics';
$txt['like_time'] = 'Liked On';