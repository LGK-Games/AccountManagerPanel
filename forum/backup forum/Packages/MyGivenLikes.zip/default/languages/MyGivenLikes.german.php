<?php

//Language strings for the mod.

$txt['my_liked_content'] = 'Beiträge, die ich mag';
$txt['my_liked_content_desc'] = 'Hier können Sie alle Beiträge sehen, die von Ihnen ein "gefällt mir" bekommen haben.';
$txt['no_content_liked_yet_by_you'] = 'Sie haben noch keine Beiträge mit "gefällt mir" markiert.';
$txt['liked_post_id'] = 'Beitrags-ID';
$txt['liked_posts_topic'] = 'Themen';
$txt['like_time'] = 'Gefiel mir am';