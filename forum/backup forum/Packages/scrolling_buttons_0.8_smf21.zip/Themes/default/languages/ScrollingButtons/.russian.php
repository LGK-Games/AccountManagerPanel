<?php

$txt['show_scrolling_buttons'] = 'Показывать кнопки прокрутки «Вверх»/«Вниз»';
$txt['sb_top_anchor_name'] = 'Идентификатор блока для верхней прокрутки';
$txt['sb_top_anchor_description'] = 'По умолчанию: «top_section»';
$txt['sb_bot_anchor_name'] = 'Идентификатор блока для нижней прокрутки';
$txt['sb_bot_anchor_description'] = 'По умолчанию: «footer»';
