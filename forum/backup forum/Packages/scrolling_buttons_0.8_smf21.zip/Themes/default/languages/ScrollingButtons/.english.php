<?php

$txt['show_scrolling_buttons'] = 'Show Scroll-to-Top/Scroll-to-Down buttons';
$txt['sb_top_anchor_name'] = 'Block identifier for the top scroll';
$txt['sb_top_anchor_description'] = 'Default: "top_section"';
$txt['sb_bot_anchor_name'] = 'Block identifier for the bottom scroll';
$txt['sb_bot_anchor_description'] = 'Default: "footer"';
