[center][color=red][size=16pt][b]Scrolling Buttons[/b][/size][/color]
[color=blue][b][size=10pt]By Bugo[/size][/b][/color]

[color=green]This mod adds Scroll-to-Top/Scroll-to-Bottom buttons on your forum.[/color][/center][hr]This work is licensed under the [url=https://opensource.org/licenses/BSD-3-Clause BSD]BSD[/url] License