<?php

/**
 * @package Scrolling Buttons
 * @link https://custom.simplemachines.org/mods/index.php?mod=3433
 * @author Bugo https://dragomano.ru/mods/scrolling-buttons
 * @copyright 2012-2025 Bugo
 * @license https://opensource.org/licenses/BSD-3-Clause BSD
 *
 * @version 0.8
 */

if (!defined('SMF'))
	die('No direct access...');

final class ScrollingButtons
{
	public function hooks(): void
	{
		add_integration_function('integrate_load_theme', __CLASS__ . '::loadTheme#', false, __FILE__);
		add_integration_function('integrate_theme_settings', __CLASS__ . '::themeSettings#', false, __FILE__);
		add_integration_function('integrate_credits', __CLASS__ . '::credits#', false, __FILE__);
	}

	public function loadTheme(): void
	{
		global $settings, $context;

		if (empty($settings['show_scrolling_buttons']))
			return;

		if (
			isset($_REQUEST['xml'])
			|| isset($_REQUEST['sa']) && $_REQUEST['sa'] === 'showoperations'
			|| in_array($context['current_action'], ['helpadmin', 'printpage'])
		)
			return;

		loadCSSFile('scrolling_buttons.css');

		$topAnchor = empty($settings['sb_top_anchor_name']) ? 'top_section' : $settings['sb_top_anchor_name'];
		$botAnchor = empty($settings['sb_bot_anchor_name']) ? 'footer' : $settings['sb_bot_anchor_name'];

		$mobiles = [
			'is_iphone',
			'is_android',
			'is_blackberry',
			'is_nokia',
			'is_opera_mobi',
			'is_opera_mini'
		];

		foreach ($mobiles as $mobile) {
			if (isBrowser($mobile)) {
				// Use emoji arrows
				$context['insert_after_template'] .= '
				<a class="arrow_up" href="#' . $topAnchor . '">⬆</a>
				<a class="arrow_down" href="#' . $botAnchor . '">⬇</a>';

				return;
			}
		}

		// Use Unicode arrows
		$context['insert_after_template'] .= '
		<a class="arrow_up" href="#' . $topAnchor . '">🡱</a>
		<a class="arrow_down" href="#' . $botAnchor . '">🡳</a>';
	}

	public function themeSettings(): void
	{
		global $context, $txt;

		loadLanguage('ScrollingButtons/');

		$context['theme_settings'][] = [
			'id'    => 'show_scrolling_buttons',
			'label' => $txt['show_scrolling_buttons']
		];

		$context['theme_settings'][] = [
			'id'          => 'sb_top_anchor_name',
			'label'       => $txt['sb_top_anchor_name'],
			'description' => $txt['sb_top_anchor_description'],
			'type'        => 'text'
		];

		$context['theme_settings'][] = [
			'id'          => 'sb_bot_anchor_name',
			'label'       => $txt['sb_bot_anchor_name'],
			'description' => $txt['sb_bot_anchor_description'],
			'type'        => 'text'
		];
	}

	public function credits(): void
	{
		global $context;

		$replacements = [
			'{link}'      => 'https://custom.simplemachines.org/index.php?mod=3433',
			'{target}'    => '_blank',
			'{rel}'       => 'noopener',
			'{name}'      => 'Scrolling Buttons',
			'{copyright}' => '&copy; 2012&ndash;' . date('Y')
		];

		$context['credits_modifications'][] = strtr('<a href="{link}" target="{target}" rel="{rel}">{name}</a> {copyright}, Bugo', $replacements);
	}
}
