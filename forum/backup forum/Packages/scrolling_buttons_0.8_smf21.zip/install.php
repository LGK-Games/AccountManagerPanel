<?php

if (file_exists(dirname(__FILE__) . '/SSI.php') && ! defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif(! defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify that you put this file in the same place as SMF\'s index.php and SSI.php files.');

global $user_info, $smcFunc;

if ((SMF === 'SSI') && ! $user_info['is_admin'])
	die('Admin privileges required.');

$smcFunc['db_insert']('replace',
	'{db_prefix}themes',
	['id_theme' => 'int', 'variable' => 'string', 'value' => 'string'],
	[1, 'show_scrolling_buttons', '1'],
	['id_theme', 'variable']
);

if (SMF === 'SSI')
	echo 'Database changes are complete! Please wait...';
