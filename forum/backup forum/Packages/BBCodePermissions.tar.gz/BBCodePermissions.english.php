<?php

global $helptxt;

$txt['restricted_bbc'] = 'Restricted BBC';
$txt['bbc_title_restricted_bbc'] = 'Select the tags that require permission to use';

$helptxt['restricted_bbc'] = 'When a BBCode is marked as restricted, you can configure permissions to control who is allowed to use that BBCode in their posts.';
$helptxt['restricted_bbc_forced'] = 'The restrictions on this BBCode cannot be turned off.';

?>