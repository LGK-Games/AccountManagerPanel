[size=x-large][b]BBCode Permissions[/b][/size]

A modification for SMF 2.1 that allows the admin to set permissions for BBCodes. Any standard or custom BBCodes can be given permissions using this mod.


[size=large][b]Settings[/b][/size]

There are two settings to control BBCode permissions.

First, the "Restricted BBC" setting allows you to control which BBCodes will require permission to use and which will not.

Then, a separate setting is created for each restricted BBCode that allows you to set the permissions for that BBCode.


[size=large][b]Limitations[/b][/size]

This modification cannot be used to remove restrictions from BBCodes that already have them. For example, the [font=monospace]html[/font] BBCode is [i]always[/i] restricted by SMF itself, and this modification does not change that.


[size=large][b]License[/b][/size]

BBCode Permissions, © 2021 Jon Stovell, is released under the MIT License. A full copy of this license is included in the package file.


[size=large][b]Changelog[/b][/size]

Version 1.1:
[list]
	[li]Hides editor buttons for disallowed BBCodes[/li]
[/list]

Version 1.0:
[list]
	[li]Initial release[/li]
[/list]