<?php

/*******************************************************************************
 * BBcode Permissions
 *
 * A modification for SMF 2.1 that allows the admin to set permissions for
 * BBCodes. Any standard or custom BBCodes can be given permissions using this
 * mod.
 *
 * Copyright (c) 2021 Jon Stovell
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/

if (!defined('SMF'))
	die('No direct access...');

/**
 * Adds admin-selected BBC to context['restricted_bbc']
 *
 * Called by:
 * 		integrate_pre_load
 */
function bbcperms_pre_load()
{
	global $modSettings, $context;

	if (!empty($modSettings['restricted_bbc']))
		$context['restricted_bbc'] = array_unique(array_merge($context['restricted_bbc'], explode(',', $modSettings['restricted_bbc'])));
}

/**
 * Adds a "Restricted BBC" selection box to the BBC settings page.
 *
 * Called by:
 * 		integrate_modify_bbc_settings
 *
 * @param array &$config_vars The array of configuration variables to modify.
 */
function bbcperms_modify_bbc_settings(&$config_vars)
{
	global $context, $modSettings;

	loadLanguage('BBCodePermissions');

	// Add the BBC selection box.
	$added = false;
	$temp = array();

	foreach ($config_vars as $config_var)
	{
		if (!$added && isset($config_var[0]) && $config_var[0] === 'permissions')
		{
			$temp[] = array('bbc', 'restricted_bbc', 'help' => 'restricted_bbc');
			$added = true;
		}

		$temp[] = $config_var;
	}

	$config_vars = $temp;

	addInlineJavaScript('
		$("#bbc_restricted_bbc_select_all").prop("checked", ' . (empty($modSettings['restricted_bbc']) ? 'false' : 'true') . ');', true);

	// Hard coded restrictions can't be toggled.
	$hard_coded = empty($modSettings['restricted_bbc']) ? $context['restricted_bbc'] : array_diff($context['restricted_bbc'], explode(',', $modSettings['restricted_bbc']));
	foreach ($hard_coded as $tag)
	{
		addInlineJavaScript('
		$("#tag_restricted_bbc_' . $tag . '").prop("checked", true);
		$("#tag_restricted_bbc_' . $tag . '").prop("disabled", true);', true);
	}
}

/**
 * Ensures the UI has the correct checkboxes selected in the "Restricted BBC"
 * selection box on the BBC settings page.
 *
 * Called by:
 * 		integrate_prepare_db_settings
 *
 * @param array &$config_vars The array of configuration variables.
 */
function bbcperms_prepare_db_settings(&$config_vars)
{
	global $context, $modSettings;

	if (!isset($context['bbc_sections']['restricted_bbc']))
		return;

	loadLanguage('BBCodePermissions');

	$hard_coded = empty($modSettings['restricted_bbc']) ? $context['restricted_bbc'] : array_diff($context['restricted_bbc'], explode(',', $modSettings['restricted_bbc']));

	foreach ($context['bbc_sections']['restricted_bbc']['columns'] as &$bbcColumn)
	{
		foreach ($bbcColumn as &$bbcTag)
		{
			if (!in_array($bbcTag['tag'], $context['restricted_bbc']))
			{
				$context['bbc_sections']['restricted_bbc']['disabled'][] = $bbcTag['tag'];
			}
			elseif (in_array($bbcTag['tag'], $hard_coded))
			{
				$bbcTag['show_help'] = true;
			}
		}
	}
}

/**
 * Processes the submitted restricted_bbc settings.
 *
 * Called by:
 * 		integrate_modify_bbc_settings
 *
 * @param array &bbcTags Array of all existing BBCode tags.
 */
function bbcperms_save_bbc_settings($bbcTags)
{
	if (!isset($_POST['restricted_bbc_enabledTags']))
		$_POST['restricted_bbc_enabledTags'] = array();
	else
		$_POST['restricted_bbc_enabledTags'] = (array) $_POST['restricted_bbc_enabledTags'];

	$temp = array();

	foreach ($bbcTags as $tag)
	{
		if (!in_array($tag, $_POST['restricted_bbc_enabledTags']))
			$temp[] = $tag;
	}

	$_POST['restricted_bbc_enabledTags'] = $temp;
}

/**
 * Provides content regarding restricted BBCode settings for the help popup.
 *
 * Called by:
 * 		integrate_helpadmin
 */
function bbcperms_helpadmin()
{
	global $context, $modSettings, $txt, $helptxt;

	loadLanguage('BBCodePermissions');

	if (isset($helptxt[$_REQUEST['help']]) || substr($_REQUEST['help'], 0, 4) !== 'tag_')
		return;

	$tag = substr($_REQUEST['help'], 4);

	$hard_coded = empty($modSettings['restricted_bbc']) ? $context['restricted_bbc'] : array_diff($context['restricted_bbc'], explode(',', $modSettings['restricted_bbc']));

	if (!in_array($tag, $hard_coded))
		return;

	$helptxt['tag_' . $tag] = $helptxt['restricted_bbc_forced'];
}

/**
 * Hides buttons for restricted BBCodes.
 *
 * Called by:
 * 		integrate_bbc_buttons
 */
function bbcperms_bbc_buttons(&$bbc_tags, &$editor_tag_map)
{
	global $context, $editortxt;

	foreach ($context['restricted_bbc'] as $tag)
	{
		if (!allowedTo('bbc_' . $tag))
		{
			if ($tag === 'list')
			{
				$context['disabled_tags']['bulletlist'] = true;
				$context['disabled_tags']['orderedlist'] = true;
			}

			if ($tag === 'float')
			{
				$context['disabled_tags']['floatleft'] = true;
				$context['disabled_tags']['floatright'] = true;
			}

			foreach ($editor_tag_map as $thisTag => $tagNameBBC)
			{
				if ($tag === $thisTag)
					$context['disabled_tags'][$tagNameBBC] = true;
			}

			$context['disabled_tags'][$tag] = true;
		}
	}
}

/**
 * Mention who made this thing
 *
 * Called by:
 * 		integrate_credits
 */
function bbcperms_credits()
{
	global $context;

	$context['copyrights']['mods'][] = 'BBCode Permissions by Jon &quot;Sesquipedalian&quot; Stovell &copy; 2021';
}