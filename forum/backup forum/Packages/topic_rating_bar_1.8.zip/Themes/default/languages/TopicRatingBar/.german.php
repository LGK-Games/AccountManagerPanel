<?php

/**
 * .english.php
 *
 * @package Topic Rating Bar
 * @author Bugo https://dragomano.ru/mods/topic-rating-bar
 */

$txt['tr_title']        = 'Topic Rating Bar';
$txt['tr_rating']       = 'Themenbewertung:';
$txt['tr_top_stat']     = 'Beliebtheitsstatistik';
$txt['tr_top_topics']   = 'Die meistbewerteten Themen';
$txt['tr_top_desc']     = 'Hier kannst Du die am meisten bewerteten Themen (basierend nach Bewertung und insgesamt angegebener Bewertungen) sehen. Die Ansicht dieser Tabelle ist variabel sortierbar.';
$txt['tr_best_topic']   = 'The best topic';
$txt['tr_other_topics'] = 'Other popular topics';
$txt['tr_top_empty']    = 'nicht bewertet.';
$txt['tr_rate_pl']      = 'Bewerte dieses Thema: ';
$txt['tr_currently']    = 'Aktuell: ';
$txt['tr_average']      = 'Durchschnittsbewertung';
$txt['tr_rates']        = 'Furchtbar|Schlecht|So-so|Gut|Super';
$txt['tr_rates_10']     = 'Worse nowhere|Awful|Bad|Passably|Average|Not bad|Good|Very good|Perfect|Excellent';
$txt['tr_votes']        = 'Bewertungen (Gesamt): ';
$txt['tr_desc']         = 'Diese Modifikation erm&ouml;glicht das Bewerten von Themen in Deinem Forum.';

$txt['tr_rate_system']     = 'Rating system';
$txt['tr_system_array']    = array('5 stars', '10 stars');
$txt['tr_mini_rating']     = 'Zeige Minibewertung im Boardindex';
$txt['tr_show_best_topic'] = 'Display the best topic on the board index';
$txt['tr_count_topics']    = 'Anzahl der Themen in der Statistik';
$txt['tr_ignored_boards']  = 'Ignored boards';
$txt['tr_regular_members'] = 'Mitglieder';

$txt['groups_rate_topics']         = 'Wer darf die Themen bewerten?';
$txt['permissionname_rate_topics'] = $txt['group_perms_name_rate_topics'] = 'Themen bewerten';
$txt['permissionhelp_rate_topics'] = 'Mitglieder k&ouml;nnen alle Themen (au&szlig;er eigene) in ausgew&auml;hlten Boards bewerten.';
