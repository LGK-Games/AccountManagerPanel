<?php

/**
 * .english.php
 *
 * @package Topic Rating Bar
 * @author Bugo https://dragomano.ru/mods/topic-rating-bar
 */

$txt['tr_title']        = 'Topic Rating Bar';
$txt['tr_rating']       = 'Βαθμολογία θέματος:';
$txt['tr_top_stat']     = 'Τα κοινά στατιστικά δημοτικότητας';
$txt['tr_top_topics']   = 'Τα πιο δημοφιλή θέματα';
$txt['tr_top_desc']     = 'Εδώ μπορείτε να δείτε τα πιο δημοφιλή (κατά βαθμολογία και αριθμό ψήφων) θέματα. Έχετε τη δυνατότητα να ταξινομήσετε αυτόν τον πίνακα κατά οποιαδήποτε στήλη.';
$txt['tr_best_topic']   = 'Το καλύτερο θέμα';
$txt['tr_other_topics'] = 'Άλλα δημοφιλή θέματα';
$txt['tr_top_empty']    = 'Δεν υπάρχουν ακόμη τιμές.';
$txt['tr_rate_pl']      = 'Βαθμολογήστε αυτό το θέμα: ';
$txt['tr_currently']    = 'Έως τώρα:';
$txt['tr_average']      = 'Μέση βαθμολογία';
$txt['tr_rates']        = 'Φρικτό|Κακό|Μέτριο|Καλό|Εξαιρετικό';
$txt['tr_rates_10']     = 'Χειρότερο όλων|Απαίσιο|Κακό|Όχι κακό|Μέτριο|Καθόλου άσχημο|Καλό|Πολύ καλό|Τέλειο|Εξαιρετικό';
$txt['tr_votes']        = 'Σύνολο ψήφων: ';
$txt['tr_desc']         = 'Αυτή η τροποποίηση σάς βοηθά να δημιουργήσετε ένα σύστημα αξιολόγησης θεμάτων στο φόρουμ σας.';

$txt['tr_rate_system']     = 'Σύστημα αξιολόγησης';
$txt['tr_system_array']    = array('5 αστέρια', '10 αστέρια');
$txt['tr_mini_rating']     = 'Εμφάνιση μικρής βαθμολογίας στο ευρετήριο μηνυμάτων';
$txt['tr_show_best_topic'] = 'Εμφανίστε το καλύτερο θέμα στο ευρετήριο του πίνακα';
$txt['tr_count_topics']    = 'Αριθμός θεμάτων στη <a href="%1$s?action=rating" target="_blank">στη σελίδα κοινών στατιστικών</a>';
$txt['tr_ignored_boards']  = 'Αγνοημένοι πίνακες';
$txt['tr_regular_members'] = 'Τακτικά Μέλη';

$txt['groups_rate_topics']         = 'Ποιος μπορεί να αλλάξει τις βαθμολογίες θέματος';
$txt['permissionname_rate_topics'] = $txt['group_perms_name_rate_topics'] = 'Βαθμολογία θεμάτων';
$txt['permissionhelp_rate_topics'] = 'Οι χρήστες μπορούν να βαθμολογήσουν οποιαδήποτε θέματα (μη δικά τους) στους επιτρεπόμενους πίνακες.';
