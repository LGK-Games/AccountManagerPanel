<?php

/**
 * .english.php
 *
 * @package Topic Rating Bar
 * @author Bugo https://dragomano.ru/mods/topic-rating-bar
 */

$txt['tr_title']        = 'Topic Rating Bar';
$txt['tr_rating']       = 'Ocjenjivanje teme:';
$txt['tr_top_stat']     = 'Zajedničke statistike popularnosti';
$txt['tr_top_topics']   = 'Najpopularnije teme';
$txt['tr_top_desc']     = 'Ovdje možete vidjeti najpopularnije (prema ocjenama i broju glasova) teme. Imate mogućnost da sortirate tablicu u bilo kom stupcu.';
$txt['tr_best_topic']   = 'The best topic';
$txt['tr_other_topics'] = 'Other popular topics';
$txt['tr_top_empty']    = 'Nema ocjena.';
$txt['tr_rate_pl']      = 'Ocjeni ovu temu: ';
$txt['tr_currently']    = 'Trenutno: ';
$txt['tr_average']      = 'Prosječna ocjena ';
$txt['tr_rates']        = 'Strašno|Loše|Tako-Tako|Dobro|Odlično';
$txt['tr_rates_10']     = 'Worse nowhere|Awful|Bad|Passably|Average|Not bad|Good|Very good|Perfect|Excellent';
$txt['tr_votes']        = 'Ukupno glasova : ';
$txt['tr_desc']         = 'Ova modifikacija vam pomaže da napravite ocjenjivački sistem tema na vašem forumu.';

$txt['tr_rate_system']     = 'Rating system';
$txt['tr_system_array']    = array('5 stars', '10 stars');
$txt['tr_mini_rating']     = 'Prikaži mini-ocjenu u indeksu tema';
$txt['tr_show_best_topic'] = 'Display the best topic on the board index';
$txt['tr_count_topics']    = 'Broj tema na zajedničkoj statističkoj stranici';
$txt['tr_ignored_boards']  = 'Ignored boards';
$txt['tr_regular_members'] = 'Regularni Članovi';

$txt['groups_rate_topics']         = 'Tko može mjenjati ocjene teme';
$txt['permissionname_rate_topics'] = $txt['group_perms_name_rate_topics'] = 'Ocjenjivanje tema';
$txt['permissionhelp_rate_topics'] = 'Korisnici mogu ocjenjivati bilo koje teme (ne sopstvene) u odobrenim forumima.';
