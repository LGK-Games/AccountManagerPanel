<?php

/**
 * .english.php
 *
 * @package Topic Rating Bar
 * @author Bugo https://dragomano.ru/mods/topic-rating-bar
 */

$txt['tr_title']        = 'Topic Rating Bar';
$txt['tr_rating']       = 'Classifica&ccedil;&atilde;o do t&oacute;pico:';
$txt['tr_top_stat']     = 'Os comuns Estat&iacute;sticas popularidade';
$txt['tr_top_topics']   = 'Os t&oacute;picos mais populares';
$txt['tr_top_desc']     = 'Aqui voc&ecirc; pode ver as mais populares (por classifica&ccedil;&atilde;o e n&uacute;mero de votos) t&oacute;picos. Voc&ecirc; tem capacidade de classificar esta tabela por qualquer coluna.';
$txt['tr_best_topic']   = 'O melhor t&oacute;pico';
$txt['tr_other_topics'] = 'Outros t&oacute;picos mais populares';
$txt['tr_top_empty']    = 'N&atilde;o classificado ainda.';
$txt['tr_rate_pl']      = 'Classifique este t&oacute;pico: ';
$txt['tr_currently']    = 'actualmente: ';
$txt['tr_average']      = 'Classifica&ccedil;&atilde;o m&eacute;dia';
$txt['tr_rates']        = 'Terrivelmente|Bad|Mais ou menos|Bom|Excelente';
$txt['tr_rates_10']     = 'Worse nowhere|Awful|Bad|Passably|Average|Not bad|Good|Very good|Perfect|Excellent';
$txt['tr_votes']        = 'Total de votos: ';
$txt['tr_desc']         = 'Esta modifica&ccedil;&atilde;o permite que voc&ecirc; crie um sistema de classifica&ccedil;&atilde;o de t&oacute;picos em seu f&oacute;rum.';

$txt['tr_rate_system']     = 'Rating system';
$txt['tr_system_array']    = array('5 stars', '10 stars');
$txt['tr_mini_rating']     = 'Do mini ecr&atilde; classifica&ccedil;&atilde;o index da mensagem ';
$txt['tr_show_best_topic'] = 'Mostrar o melhor index no t&oacute;pico do quadro';
$txt['tr_count_topics']    = 'N&uacute;mero de t&oacute;picos sobre <a href="%1$s?action=rating" target="_blank">a p&aacute;gina de estat&iacute;sticas comum</a>';
$txt['tr_ignored_boards']  = 'Ignored boards';
$txt['tr_regular_members'] = 'Membros Regulares';

$txt['groups_rate_topics']         = 'Quem pode mudar classifica&ccedil;&atilde;o t&oacute;pico';
$txt['permissionname_rate_topics'] = $txt['group_perms_name_rate_topics'] = 'Classifique dos t&oacute;picos';
$txt['permissionhelp_rate_topics'] = 'Os utilizadores pode classificar todos os t&oacute;picos (n&atilde;o pr&oacute;prio) em quadros permitidas.';
