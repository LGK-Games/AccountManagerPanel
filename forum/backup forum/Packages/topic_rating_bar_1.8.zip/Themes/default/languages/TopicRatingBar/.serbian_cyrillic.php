<?php

/**
 * .english.php
 *
 * @package Topic Rating Bar
 * @author Bugo https://dragomano.ru/mods/topic-rating-bar
 */

$txt['tr_title']        = 'Topic Rating Bar';
$txt['tr_rating']       = 'Оцењивање теме:';
$txt['tr_top_stat']     = 'Заједничке статистике популарности';
$txt['tr_top_topics']   = 'Најпопуларније теме';
$txt['tr_top_desc']     = 'Овде можете видети најпопуларније (према оценама и броју гласова) теме. Имате могућност да сортирате табелу у било којој колони.';
$txt['tr_best_topic']   = 'The best topic';
$txt['tr_other_topics'] = 'Other popular topics';
$txt['tr_top_empty']    = 'Нема оцена.';
$txt['tr_rate_pl']      = 'Оцени ову тему: ';
$txt['tr_currently']    = 'Тренутно: ';
$txt['tr_average']      = 'Просечна оцена ';
$txt['tr_rates']        = 'Страшно|Лоше|Тако-Тако|Добро|Одлично';
$txt['tr_rates_10']     = 'Worse nowhere|Awful|Bad|Passably|Average|Not bad|Good|Very good|Perfect|Excellent';
$txt['tr_votes']        = 'Укупно гласова : ';
$txt['tr_desc']         = 'Ова модификација вам помаже да направите оцењивачки систем тема на вашем форуму.';

$txt['tr_rate_system']     = 'Rating system';
$txt['tr_system_array']    = array('5 stars', '10 stars');
$txt['tr_mini_rating']     = 'Прикажи мини-оцену у индексу тема';
$txt['tr_show_best_topic'] = 'Display the best topic on the board index';
$txt['tr_count_topics']    = 'Број тема на заједничкој статистичкој страници';
$txt['tr_ignored_boards']  = 'Ignored boards';
$txt['tr_regular_members'] = 'Регуларни Чланови';

$txt['groups_rate_topics']         = 'Ко може мењати оцене теме';
$txt['permissionname_rate_topics'] = $txt['group_perms_name_rate_topics'] = 'Оцењивање тема';
$txt['permissionhelp_rate_topics'] = 'Корисници могу оцењивати било које теме (не сопствене) у одобреним форумима.';
