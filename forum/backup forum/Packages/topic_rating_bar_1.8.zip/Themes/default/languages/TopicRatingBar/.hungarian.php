<?php

/**
 * .english.php
 *
 * @package Topic Rating Bar
 * @author Bugo https://dragomano.ru/mods/topic-rating-bar
 */

$txt['tr_title']        = 'Topic Rating Bar';
$txt['tr_rating']       = 'Téma értékelése:';
$txt['tr_top_stat']     = 'A közös népszerûségi statisztika';
$txt['tr_top_topics']   = 'A legnépszerûbb téma';
$txt['tr_top_desc']     = 'Itt láthatod a legnépszerûbb témát (értékelés és szavazatok száma alapján). Lehetõséged van rendezni a táblázatot bármely oszlop alapján.';
$txt['tr_best_topic']   = 'A legjobb téma';
$txt['tr_other_topics'] = 'A többi népszerû téma';
$txt['tr_top_empty']    = 'Nincsen még értékelés.';
$txt['tr_rate_pl']      = 'Értékeld ezt a témát: ';
$txt['tr_currently']    = 'Jelenleg: ';
$txt['tr_average']      = 'Átlagos értékelés';
$txt['tr_rates']        = 'Nagyon gyeneg|Gyenge|Elfogadható|Jó|Kiváló';
$txt['tr_rates_10']     = 'Worse nowhere|Awful|Bad|Passably|Average|Not bad|Good|Very good|Perfect|Excellent';
$txt['tr_votes']        = 'Összes szavazat: ';
$txt['tr_desc']         = 'Ez a módosítás segít értékelési rendszert készíteni a fórum témáidhoz.';

$txt['tr_rate_system']     = 'Rating system';
$txt['tr_system_array']    = array('5 stars', '10 stars');
$txt['tr_mini_rating']     = 'Mini értékelés kikapcsolása az üzenet ablakban';
$txt['tr_show_best_topic'] = 'Mutasd a legjobb témát a fõoldalon';
$txt['tr_count_topics']    = 'Témák száma <a href="%1$s?action=rating" target="_blank">a közös statisztikai oldalon.</a>';
$txt['tr_ignored_boards']  = 'Ignored boards';
$txt['tr_regular_members'] = 'Szabályos tagok';

$txt['groups_rate_topics']         = 'Ki változtathatja meg a témák értékelését';
$txt['permissionname_rate_topics'] = $txt['group_perms_name_rate_topics'] = 'Téma értékelése';
$txt['permissionhelp_rate_topics'] = 'Felhasználók értékelhetik bármelyik témát (sajátot nem) az engedélyezett témáknál.';
