<?php

$txt['cumulus_title']         = 'SMF Cumulus';
$txt['cumulus_desc']          = 'Здесь можно изменить настройки блока популярных тем, отображающегося на главной странице форума.';
$txt['cumulus_show']          = 'Показывать облако популярных тем в Информационном центре';
$txt['cumulus_ignoreboards']  = 'Игнорируемые разделы';
$txt['cumulus_count']         = 'Количество тем в облаке';
$txt['cumulus_variant']       = 'Критерий оценки популярности';
$txt['cumulus_variants']      = array('Количество просмотров', 'Количество ответов');
$txt['cumulus_height']        = 'Высота облака';
$txt['cumulus_text_color']    = 'Цвет ссылок в блоке';
$txt['cumulus_outline_color'] = 'Цвет ссылок при наведении';
$txt['cumulus_max_speed']     = 'Скорость вращения ссылок в облаке <div class="smalltext">От 0 до 100 (0 — отключить).</div>';
$txt['cumulus_maxfont']       = 'Максимальный размер шрифта';
$txt['cumulus_minfont']       = 'Минимальный размер шрифта';
$txt['cumulus_scale']         = 'Масштаб размера тегов';
$txt['cumulus_single']        = 'Самая популярная тема';
$txt['cumulus_compat']        = 'Интеграция с другими модами';
$txt['cumulus_compat_mods']   = array('Не использовать', 'trb' => 'Topic Rating Bar', 'sc' => 'Simple Classifieds', 'op' => 'Optimus', 'spp' => 'SMF Post Prefix');
$txt['cumulus_topics']        = 'Популярные темы';
$txt['cumulus_tags']          = 'Облако тегов';
