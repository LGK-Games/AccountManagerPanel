<?php

$txt['cumulus_title']         = 'SMF Cumulus';
$txt['cumulus_desc']          = 'Here you can change settings of the SMF Cumulus mod.';
$txt['cumulus_show']          = 'Show "Popular Topics" cloud within Info Center?';
$txt['cumulus_ignoreboards']  = 'Ignored boards';
$txt['cumulus_count']         = 'Number of topics in the cloud';
$txt['cumulus_variant']       = 'Criterion of popularity rating';
$txt['cumulus_variants']      = array('Number views', 'Number replies');
$txt['cumulus_height']        = 'Flash height';
$txt['cumulus_text_color']    = 'The default link color';
$txt['cumulus_outline_color'] = 'Tag mouseover/hover color';
$txt['cumulus_max_speed']     = 'Rotation speed <div class="smalltext">From 0 to 100 (0 = disabled).</div>';
$txt['cumulus_maxfont']       = 'Maximal font size';
$txt['cumulus_minfont']       = 'Minimanl font size';
$txt['cumulus_scale']         = 'Tagsize scale';
$txt['cumulus_single']        = 'Most Popular Topic';
$txt['cumulus_compat']        = 'Compatibility mode';
$txt['cumulus_compat_mods']   = array('Disable', 'trb' => 'Topic Rating Bar', 'sc' => 'Simple Classifieds', 'op' => 'Optimus', 'spp' => 'SMF Post Prefix');
$txt['cumulus_topics']        = 'Popular Topics';
$txt['cumulus_tags']          = 'Tag Cloud';
