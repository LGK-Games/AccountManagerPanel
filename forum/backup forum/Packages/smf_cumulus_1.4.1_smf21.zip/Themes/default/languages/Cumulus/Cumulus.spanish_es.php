<?php

$txt['cumulus_title']         = 'SMF Cumulus';
$txt['cumulus_desc']          = 'Aquí puedes cambiar la configuración del mod SMF Cumulus.';
$txt['cumulus_show']          = 'Mostrar nube de "Post populares" en Info Center?';
$txt['cumulus_ignoreboards']  = 'Foros ignorados';
$txt['cumulus_count']         = 'Número de post en la nube';
$txt['cumulus_variant']       = 'Criterio de popularidad';
$txt['cumulus_variants']      = array('Número de vistos', 'Número de respuestas');
$txt['cumulus_height']        = 'Altura del nubes';
$txt['cumulus_text_color']    = 'Color de enlace predeterminado';
$txt['cumulus_outline_color'] = 'Color del tag cursor encima/flotante ';
$txt['cumulus_max_speed']     = 'Velocidad de rotación <div class="smalltext">De 0 a 100 (0 = desactivado).</div>';
$txt['cumulus_maxfont']       = 'Tamaño de letra máximo';
$txt['cumulus_minfont']       = 'Tamaño de letra mínimo';
$txt['cumulus_scale']         = 'Escala de Tamaño del Tag';
$txt['cumulus_single']        = 'Post mas popular';
$txt['cumulus_compat']        = 'Modo de Compatibilidad';
$txt['cumulus_compat_mods']   = array('Desactivado', 'trb' => 'Topic Rating Bar', 'sc' => 'Simple Classifieds', 'op' => 'Optimus', 'spp' => 'SMF Post Prefix');
$txt['cumulus_topics']        = 'Post Populares';
$txt['cumulus_tags']          = 'Nube de Tags';
