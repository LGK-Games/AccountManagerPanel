<?php

/**
 * Class-Cumulus.php
 *
 * @package SMF Cumulus
 * @link https://custom.simplemachines.org/mods/index.php?mod=2936
 * @author Bugo https://dragomano.ru/mods/cumulus-congestus
 * @copyright 2011-2024 Bugo
 * @license https://opensource.org/licenses/BSD-3-Clause BSD
 *
 * @version 1.4.1
 */

if (!defined('SMF'))
	die('No direct access...');

final class Cumulus
{
	public function hooks(): void
	{
		add_integration_function('integrate_admin_areas', __CLASS__ . '::adminAreas#', false, __FILE__);
		add_integration_function('integrate_admin_search', __CLASS__ . '::adminSearch#', false, __FILE__);
		add_integration_function('integrate_modify_modifications', __CLASS__ . '::modifyModifications#', false, __FILE__);
		add_integration_function('integrate_buffer', __CLASS__ . '::buffer#', false, __FILE__);
		add_integration_function('integrate_cumulus_compat', __CLASS__ . '::baseTopics#', false, __FILE__);
		add_integration_function('integrate_cumulus_compat', __CLASS__ . '::topicRatingBarCompat#', false, __FILE__);
		add_integration_function('integrate_cumulus_compat', __CLASS__ . '::simpleClassifiedsCompat#', false, __FILE__);
		add_integration_function('integrate_cumulus_compat', __CLASS__ . '::optimusCompat#', false, __FILE__);
		add_integration_function('integrate_cumulus_compat', __CLASS__ . '::smfPostPrefixCompat#', false, __FILE__);
	}

	public function adminAreas(array &$admin_areas): void
	{
		global $txt;

		loadLanguage('Cumulus/Cumulus');

		$admin_areas['config']['areas']['modsettings']['subsections']['cumulus'] = [$txt['cumulus_title']];
	}

	public function adminSearch(array &$language_files, array &$include_files, array &$settings_search): void
	{
		$settings_search[] = [[$this, 'settings'], 'area=modsettings;sa=cumulus'];
	}

	public function modifyModifications(array &$subActions): void
	{
		$subActions['cumulus'] = [$this, 'settings'];
	}

	public function buffer(string $buffer): string
	{
		global $modSettings, $options;

		if (isset($_REQUEST['xml']) || empty($modSettings['cumulus_show']))
			return $buffer;

		$search  = '<div id="upshrink_stats"' . (empty($options['collapse_header_ic']) ? '' : ' style="display: none;"') . '>';
		$replace = $search . self::show();

		return str_replace($search, $replace, $buffer);
	}

	/**
	 * @return array|void
	 */
	public function settings(bool $return_config = false)
	{
		global $context, $txt, $scripturl, $modSettings;

		loadLanguage('Cumulus/Cumulus');

		$context['page_title']     = $txt['cumulus_title'];
		$context['settings_title'] = $txt['mods_cat_features'];
		$context['post_url']       = $scripturl . '?action=admin;area=modsettings;save;sa=cumulus';
		$context[$context['admin_menu_name']]['tab_data']['description'] = $txt['cumulus_desc'];

		$add_settings = [];
		if (!isset($modSettings['cumulus_show']))
			$add_settings['cumulus_show'] = true;
		if (!isset($modSettings['cumulus_variant']))
			$add_settings['cumulus_variant'] = 1;
		if (!isset($modSettings['cumulus_count']))
			$add_settings['cumulus_count'] = 15;
		if (!isset($modSettings['cumulus_height']))
			$add_settings['cumulus_height'] = 150;
		if (!isset($modSettings['cumulus_text_color']))
			$add_settings['cumulus_text_color'] = '#000000';
		if (!isset($modSettings['cumulus_outline_color']))
			$add_settings['cumulus_outline_color'] = '#ff0000';
		if (!isset($modSettings['cumulus_max_speed']))
			$add_settings['cumulus_max_speed'] = 60;
		if (!isset($modSettings['cumulus_maxfont']))
			$add_settings['cumulus_maxfont'] = 32;
		if (!isset($modSettings['cumulus_minfont']))
			$add_settings['cumulus_minfont'] = 22;
		if (!isset($modSettings['cumulus_scale']))
			$add_settings['cumulus_scale'] = 50;
		if (!empty($add_settings))
			updateSettings($add_settings);


		$config_vars = [
			['check', 'cumulus_show'],
			['select', 'cumulus_compat', $txt['cumulus_compat_mods']],
			['boards', 'cumulus_ignoreboards']
		];

		if (empty($modSettings['cumulus_compat'])) {
			$config_vars[] = ['select', 'cumulus_variant', $txt['cumulus_variants']];
			$config_vars[] = ['int', 'cumulus_count'];
		}

		$config_vars[] = ['int', 'cumulus_height', 'postinput' => 'px'];
		$config_vars[] = ['color', 'cumulus_text_color'];
		$config_vars[] = ['color', 'cumulus_outline_color'];
		$config_vars[] = ['int', 'cumulus_max_speed'];
		$config_vars[] = ['int', 'cumulus_maxfont', 'postinput' => 'pt'];
		$config_vars[] = ['int', 'cumulus_minfont', 'postinput' => 'pt'];

		if (!empty($modSettings['cumulus_type']))
			$config_vars[] = ['int', 'cumulus_scale', 'postinput' => '%'];

		if ($return_config)
			return $config_vars;

		// Saving?
		if (isset($_GET['save'])) {
			checkSession();

			$save_vars = $config_vars;
			saveDBSettings($save_vars);

			redirectexit('action=admin;area=modsettings;sa=cumulus');
		}

		prepareDBSettingContext($config_vars);
	}

	/**
	 * @param bool $notitle
	 * @return string|void
	 */
	public static function show(bool $notitle = false)
	{
		global $modSettings, $txt, $settings;

		loadLanguage('Cumulus/Cumulus');

		// Default values
		$modSettings['cumulus_count']         = !empty($modSettings['cumulus_count']) ? (int) $modSettings['cumulus_count'] : 1;
		$modSettings['cumulus_height']        = !empty($modSettings['cumulus_height']) ? (int) $modSettings['cumulus_height'] : 150;
		$modSettings['cumulus_text_color']    = !empty($modSettings['cumulus_text_color']) ? (string) $modSettings['cumulus_text_color'] : '#000000';
		$modSettings['cumulus_outline_color'] = !empty($modSettings['cumulus_outline_color']) ? (string) $modSettings['cumulus_outline_color'] : '#ff0000';
		$modSettings['cumulus_max_speed']     = !empty($modSettings['cumulus_max_speed']) ? (int) $modSettings['cumulus_max_speed'] : 0;
		$modSettings['cumulus_maxfont']       = !empty($modSettings['cumulus_maxfont']) ? (int) $modSettings['cumulus_maxfont'] : 32;
		$modSettings['cumulus_minfont']       = !empty($modSettings['cumulus_minfont']) ? (int) $modSettings['cumulus_minfont'] : 22;
		$modSettings['cumulus_scale']         = !empty($modSettings['cumulus_scale']) ? (int) $modSettings['cumulus_scale'] : 50;

		// Number of topics to display
		$limit = $modSettings['cumulus_count'];

		$ignored_boards = [];
		if (!empty($modSettings['cumulus_ignoreboards']))
			$ignored_boards = explode(",", $modSettings['cumulus_ignoreboards']);

		if (!empty($modSettings['recycle_board']))
			$ignored_boards[] = $modSettings['recycle_board'];

		$urls = [];

		call_integration_hook('integrate_cumulus_compat', array(&$urls, $ignored_boards, $limit));

		if (empty($urls))
			return;

		// Top area
		$cumulus = '
		<div class="sub_bar">
			<h4 class="subbg">
				<span class="main_icons details"></span> ' . ($limit === 1 ? $txt['cumulus_single'] : $txt['cumulus_topics']) . '
			</h4>
		</div>
		<div class="centertext">';

		if ($notitle)
			$cumulus = '
		<div class="centertext">';

		// Output
		$cumulus .= /** @lang text */ '
			<script src="' . $settings['default_theme_url'] . '/scripts/tagcanvas.min.js"></script>
			<script>
				window.onload = function() {
					try {
						TagCanvas.Start("cumulusCanvas", "tags", {
							textColour: "' . $modSettings['cumulus_text_color'] . '",
							textFont: null,
							outlineColour: "' . $modSettings['cumulus_outline_color'] . '",
							weight: true,
							weightMode: "colour",
							weightFrom: "data-weight",
							reverse: true,
							depth: 0.8,
							maxSpeed: ' . ($modSettings['cumulus_max_speed'] * 0.001) . '
						});
					} catch(e) {
						document.getElementById("cumulusCanvasContainer").style.display = "none";
					}
				};
			</script>
			<div id="cumulusCanvasContainer">
				<canvas id="cumulusCanvas" width="600" height="' . $modSettings['cumulus_height'] . '"></canvas>
			</div>
			<div id="tags" style="display: none">
				<ul>' . implode('', array_unique($urls)) . '</ul>
			</div>
		</div>';

		return $cumulus;
	}

	public function baseTopics(array &$urls, array $ignored_boards, int $limit): void
	{
		global $modSettings, $context, $smcFunc, $scripturl, $boarddir;

		if (!empty($modSettings['cumulus_compat']))
			return;

		if (!empty($ignored_boards)) {
			if (($topics = cache_get_data('cumulus_topics_' . $context['user']['id'], 7200)) === null) {
				$request = $smcFunc['db_query']('', '
					SELECT t.id_topic
					FROM {db_prefix}boards AS b
						INNER JOIN {db_prefix}topics AS t ON (b.id_board = t.id_board)
					WHERE t.id_board NOT IN ({array_int:ignored_boards})
						AND {query_wanna_see_board}
						AND {query_see_board}
					ORDER BY t.id_topic DESC
					LIMIT {int:limit}',
					[
						'ignored_boards' => $ignored_boards,
						'limit'          => $limit
					]
				);

				$id_topics = [];
				while ($row = $smcFunc['db_fetch_assoc']($request))
					$id_topics[] = $row['id_topic'];

				$smcFunc['db_free_result']($request);

				$request = $smcFunc['db_query']('', '
					SELECT m.subject, t.num_views, t.num_replies, t.id_topic
					FROM {db_prefix}topics AS t
						INNER JOIN {db_prefix}messages AS m ON (m.id_msg = t.id_first_msg)
					WHERE t.id_topic IN ({array_int:topic_list})
					LIMIT {int:limit}',
					[
						'topic_list' => $id_topics,
						'limit'      => $limit
					]
				);

				while ($row = $smcFunc['db_fetch_assoc']($request)) {
					censorText($row['subject']);

					if (!empty($modSettings['cumulus_variant'])) {
						if (!empty($row['num_replies'])) {
							$topics[] = [
								'id'          => $row['id_topic'],
								'subject'     => $row['subject'],
								'num_replies' => $row['num_replies'],
								'num_views'   => $row['num_views'],
								'href'        => $scripturl . '?topic=' . $row['id_topic'] . '.0'
							];
						}
					} else {
						if (!empty($row['num_views'])) {
							$topics[] = [
								'id'          => $row['id_topic'],
								'subject'     => $row['subject'],
								'num_replies' => $row['num_replies'],
								'num_views'   => $row['num_views'],
								'href'        => $scripturl . '?topic=' . $row['id_topic'] . '.0'
							];
						}
					}
				}

				$smcFunc['db_free_result']($request);

				cache_put_data('cumulus_topics_' . $context['user']['id'], $topics, 7200);
			}
		} else {
			require_once($boarddir . '/SSI.php');

			$topics = !empty($modSettings['cumulus_variant'])
				? ssi_topTopicsReplies($limit, 'array')
				: ssi_topTopicsViews($limit, 'array');
		}

		foreach ($topics as $topic)	{
			$size = $topic['num_views'];

			if ($size < $modSettings['cumulus_minfont'])
				$size = $modSettings['cumulus_minfont'];
			if ($size > $modSettings['cumulus_maxfont'])
				$size = $modSettings['cumulus_maxfont'];

			$urls[]  = '<li><a href="' . $topic['href'] . '" data-weight="'. $size . '">' . $topic['subject'] . '</a></li>';
		}
	}

	public function topicRatingBarCompat(array &$urls, array $ignored_boards, int $limit): void
	{
		global $modSettings, $sourcedir, $txt, $context, $smcFunc, $scripturl;

		if (empty($modSettings['cumulus_compat']))
			return;

		if ($modSettings['cumulus_compat'] !== 'trb' || !file_exists($sourcedir . '/Class-TopicRatingBar.php'))
			return;

		$txt['cumulus_topics'] = $txt['tr_top_topics'];

		if (($urls = cache_get_data('cumulus_topic_rating_bar_' . $context['user']['id'], 7200)) === null) {
			$context['top_rating'] = [];

			$query = $smcFunc['db_query']('', /** @lang text */ '
				SELECT tr.id, tr.total_votes, tr.total_value, ms.subject
				FROM {db_prefix}topic_ratings AS tr
					INNER JOIN {db_prefix}topics AS t ON (t.id_topic = tr.id)
					INNER JOIN {db_prefix}messages AS ms ON (ms.id_msg = t.id_first_msg)
					INNER JOIN {db_prefix}boards AS b ON (b.id_board = t.id_board)
				WHERE ' . (!empty($ignored_boards) ? 't.id_board NOT IN ({array_int:ignored_boards}) AND ' : '') . '
					{query_wanna_see_board}
					AND {query_see_board}
				LIMIT {int:limit}',
				[
					'ignored_boards' => $ignored_boards,
					'limit'          => $limit
				]
			);

			while ($row = $smcFunc['db_fetch_assoc']($query)) {
				$size = number_format($row['total_value'] / $row['total_votes'], 2) * 10;

				$urls[] = '<li>
					<a href="' . $scripturl . '?topic=' . $row['id'] . '.0" data-weight="' . $size . '">
						' . $row['subject'] . ' (~ ' . round($row['total_value'] / $row['total_votes']) . ')
					</a>
				</li>';
			}

			$smcFunc['db_free_result']($query);

			cache_put_data('cumulus_topic_rating_bar_' . $context['user']['id'], $urls, 7200);
		}
	}

	public function simpleClassifiedsCompat(array &$urls): void
	{
		global $modSettings, $context, $txt, $smcFunc, $scripturl;

		if (empty($modSettings['cumulus_compat']) || empty($context['view_classifieds']))
			return;

		if ($modSettings['cumulus_compat'] !== 'sc' || !class_exists('\Bugo\Classifieds\Integration'))
			return;

		$txt['cumulus_topics'] = $txt['sc_button'];

		if (($urls = cache_get_data('cumulus_simple_classifieds_' . $context['user']['id'], 7200)) === null) {
			$request = $smcFunc['db_query']('', '
				SELECT id, title, type, num_views
				FROM {db_prefix}bbs_items
				WHERE status = {int:is_approved}
				ORDER BY {raw:order} DESC
				LIMIT {int:limit}',
				[
					'is_approved' => 1,
					'order'       => 'num_views',
					'limit'       => (int) $modSettings['sc_recent_items'] ?: 10
				]
			);

			while ($row = $smcFunc['db_fetch_assoc']($request)) {
				$size = $row['num_views'];

				if ($size < $modSettings['cumulus_minfont'])
					$size = $modSettings['cumulus_minfont'];
				if ($size > $modSettings['cumulus_maxfont'])
					$size = $modSettings['cumulus_maxfont'];

				$type = '';
				if (isset($context['sc_types'][$row['type']]) && !empty($context['sc_types'][$row['type']]['name'])) {
					$type   = '[' . $context['sc_types'][$row['type']]['name'] . '] ';
				}

				$urls[] = '<li><a href="' . $scripturl . '?action=bbs;sa=item;id=' . $row['id'] . '" data-weight="' . $size . '">' . $type . $row['title'] . '</a></li>';
			}

			$smcFunc['db_free_result']($request);

			cache_put_data('cumulus_simple_classifeds_' . $context['user']['id'], $urls, 7200);
		}
	}

	public function optimusCompat(array &$urls, array $ignored_boards): void
	{
		global $modSettings, $sourcedir, $txt, $context, $smcFunc, $scripturl;

		if (empty($modSettings['cumulus_compat']))
			return;

		if ($modSettings['cumulus_compat'] !== 'op' || !file_exists($sourcedir . '/Optimus/Handlers/TagHandler.php'))
			return;

		$txt['cumulus_topics'] = $txt['optimus_all_keywords'];

		if (($urls = cache_get_data('cumulus_optimus_' . $context['user']['id'], 7200)) === null) {
			$request = $smcFunc['db_query']('', '
				SELECT ok.id, ok.name, COUNT(olk.keyword_id) AS frequency
				FROM {db_prefix}optimus_keywords AS ok
					INNER JOIN {db_prefix}optimus_log_keywords AS olk ON (ok.id = olk.keyword_id)
					INNER JOIN {db_prefix}topics AS t ON (olk.topic_id = t.id_topic)
				WHERE t.id_board NOT IN ({array_int:ignored_boards})
					AND {query_see_topic_board}
				GROUP BY ok.id, ok.name
				ORDER BY ok.name DESC',
				[
					'ignored_boards' => $ignored_boards
				]
			);

			while ($row = $smcFunc['db_fetch_assoc']($request)) {
				$urls[] = '<li>
					<a href="' . $scripturl . '?action=keywords;id=' . $row['id'] . '" data-weight="' . $row['frequency'] . '">' . $row['name'] . ' (' . $row['frequency'] . ')</a>
				</li>';
			}

			$smcFunc['db_free_result']($request);

			cache_put_data('cumulus_optimus_' . $context['user']['id'], $urls, 7200);
		}
	}

	public function smfPostPrefixCompat(array &$urls, array $ignored_boards): void
	{
		global $modSettings, $txt, $context, $smcFunc, $scripturl;

		if (empty($modSettings['cumulus_compat']))
			return;

		if ($modSettings['cumulus_compat'] !== 'spp' || !class_exists('\PostPrefix\PostPrefix'))
			return;

		loadLanguage('PostPrefix/');
		$txt['cumulus_topics'] = $txt['PostPrefix_main'];

		if (($urls = cache_get_data('cumulus_prefixes_' . $context['user']['id'], 7200)) === null) {
			$request = $smcFunc['db_query']('', '
				SELECT pp.id, pp.name, t.id_topic
				FROM {db_prefix}postprefixes AS pp
					LEFT JOIN {db_prefix}topics AS t ON (pp.id = t.id_prefix)
				WHERE t.id_board NOT IN ({array_int:ignored_boards})
					AND {query_see_topic_board}
					AND pp.status = {int:status}
				GROUP BY pp.id, pp.name, t.id_topic
				ORDER BY pp.name DESC',
				[
					'ignored_boards' => $ignored_boards,
					'status'         => 1
				]
			);

			while ($row = $smcFunc['db_fetch_assoc']($request)) {
				$urls[] = '<li><a href="' . $scripturl . '?topic=' . $row['id_topic'] . '">' . $row['name'] . '</a></li>';
			}

			$smcFunc['db_free_result']($request);

			cache_put_data('cumulus_prefixes_' . $context['user']['id'], $urls, 7200);
		}
	}
}
