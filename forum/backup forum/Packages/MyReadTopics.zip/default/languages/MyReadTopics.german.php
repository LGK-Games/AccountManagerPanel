<?php

/**
 * Language strings for the mod.
 */
$txt['my_read_topics'] = 'Gelesene Themen';
$txt['my_read_topics_desc'] = 'Hier können Sie alle Themen sehen, die Sie gelesen haben.';
$txt['no_topics_read_yet_by_you'] = 'Sie haben noch keine Themen gelesen!';
$txt['users_read_topics'] = 'Themen';
$txt['topic_read_boards'] = 'Boards';
$txt['read_time'] = 'Zuletzt gelesen';