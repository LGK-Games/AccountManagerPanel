<?php

/**
 * Language strings for the mod.
 */
$txt['my_read_topics'] = 'Topics I Read';
$txt['my_read_topics_desc'] = 'Here you can see all the topics that you have read.';
$txt['no_topics_read_yet_by_you'] = 'You have not read any topics yet!';
$txt['users_read_topics'] = 'Topics';
$txt['topic_read_boards'] = 'Boards';
$txt['read_time'] = 'Last Read On';