This mod will add a link on members profiles to display all the topics that they have read.
Admins can track members topic reading behaviour from cliclikng the Topics I Read link on members profiles