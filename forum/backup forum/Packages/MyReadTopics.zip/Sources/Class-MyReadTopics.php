<?php

/**
 * If we are outside SMF throw an error.
 */
if (!defined('SMF'))
{
	die('Hacking attempt...');
}

/**
 * Load read topics class.
 */
class Read
{
	/**
    * Log users read topics.
    */
	public static function LogTopicViews()
    {
	    global $context;
		
	    if (empty($context['current_action']) && !empty($_REQUEST['topic']))
	    {
		    Read::InsertTopicViews();
	    }	
    }
	
	/**
    * Insert the read topic data in the database.
    */
	public static function InsertTopicViews()
    {
		global $context, $smcFunc, $user_info;
		
		$topic = (int) $_REQUEST['topic'];
		
	    if (empty($topic))
		{
		   return false;
		}
		
	    $smcFunc['db_query']('', '
		    UPDATE {db_prefix}log_topic_readers
		    SET read_time = {int:read_time}
		    WHERE user_id = {int:user_id}
			AND topic_id = {int:topic_id}
		    LIMIT 1',
		    array(
			    'user_id' => $user_info['id'],
			    'topic_id' => $topic,
			    'read_time' => time(),
		    )
	    );

	    if ($smcFunc['db_affected_rows']() == 0)
	    {
		    $smcFunc['db_insert']('ignore',
			   '{db_prefix}log_topic_readers',
			   array('topic_id' => 'int', 'user_id' => 'int', 'read_time' => 'int'),
			   array($topic, $user_info['id'], time()),
			   array('id')
		    );
	    }
    }

    /**
    * Show the link to their visited topics on member menu popup.
    */
    public static function My_Read_Topics_Profile_Popup(array &$profile_items)
    {
	    global $txt;

	    $counter = 0;
	
	    // Now check if these items are available.
	    foreach ($profile_items as $item) 
	    {
		    $counter++;

		    if ($item['area'] === 'showdrafts')
		    {	
			   break;
		    }	
	    }

	    $profile_items = array_merge(
		    array_slice($profile_items, 0, $counter, true),
			    array(
				    array(
					  'menu'  => 'info',
					  'area'  => 'myreadtopics',
					  'title' => $txt['my_read_topics']
				    )
			    ),
			
		    array_slice($profile_items, $counter, null, true)
	    );
    }

    /**
    * Show the link to their visited topics on their profiles.
	*/
    public static function My_Read_Topics_Profile_Areas(&$profile_areas)
    {
	    global $txt, $user_info;
	
	    loadLanguage('MyReadTopics');

	    $profile_areas['info']['areas'] += array(
		    'myreadtopics' => array(
			   'label' => $txt['my_read_topics'],
			   'function' => 'Read::TopicsIRead',
			   'icon' => 'posts',
			   'permission' => array(
			       'own' => 'profile_view_own',
				   'any' => $user_info['is_admin'],
			   )
		    ),
	    );
    }

    /**
    * Display to members all the topics that they have read.
	*/
    public static function TopicsIRead($memID)
    {
	    global $context, $user_profile, $sourcedir, $scripturl, $txt;

	    $context['current_member'] = $memID;

	    $context['page_title'] = $txt['my_read_topics'] . ' - ' . $user_profile[$memID]['real_name'];
	
	    $context[$context['profile_menu_name']]['tab_data'] = array(
		   'title' => $txt['my_read_topics'],
		   'description' => $txt['my_read_topics_desc'],
		   'icon' => 'posts',
	    );
	
	    $listOptions = array(
		    'id' => 'read_topics_list',
		    'items_per_page' => 20,
		    'base_href' => $scripturl . '?action=profile;area=myreadtopics;u=' . $memID,
		    'default_sort_col' => 'read_time',
		    'no_items_label' => $txt['no_topics_read_yet_by_you'],
		    'get_items' => array(
			   'function' => 'Read::ListAllMyReadTopics',
		    ),
		    'get_count' => array(
			   'function' => 'Read::CountAllMyReadTopics',
		    ),
			'columns' => array(
			    'subject' => array(
				    'header' => array(
					   'value' => $txt['users_read_topics'],
					   'style' => 'width: 35%',
				    ),
				    'data' => array(
					   'db' => 'subject',
					   'class' => 'centertext'
				    ),
				    'sort' =>  array(
					   'default' => 'subject',
					   'reverse' => 'subject DESC',
				    ),
			    ),
				'name' => array(
				    'header' => array(
					   'value' => $txt['topic_read_boards'],
					   'style' => 'width: 35%',
				    ),
				    'data' => array(
					   'db' => 'name',
					   'class' => 'centertext'
				    ),
				    'sort' =>  array(
					   'default' => 'name',
					   'reverse' => 'name DESC',
				    ),
			    ),
			    'read_time' => array(
				    'header' => array(
					   'value' => $txt['read_time'],
					   'style' => 'width: 30%',
				    ),
				    'data' => array(
					   'db' => 'read_time',
					   'class' => 'centertext'
				    ),
				    'sort' =>  array(
					   'default' => 'read_time',
					   'reverse' => 'read_time DESC',
				    ),
               ),
			),
	    );

	    require_once($sourcedir . '/Subs-List.php');
	    createList($listOptions);

	    $context['sub_template'] = 'show_list';
	    $context['default_list'] = 'read_topics_list';	
    }

    /**
	* Get all the posts liked by members.
    */
	public static function ListAllMyReadTopics($start, $items_per_page, $sort)
    {
	    global $smcFunc, $context, $scripturl;

	    $results = $smcFunc['db_query']('', '
		    SELECT lr.user_id, lr.topic_id, lr.read_time, 
		    m.subject, t.id_topic, b.id_board, b.name
		    FROM {db_prefix}log_topic_readers AS lr
			INNER JOIN {db_prefix}topics AS t ON (t.id_topic = lr.topic_id)
		    INNER JOIN {db_prefix}messages AS m ON (m.id_msg = t.id_first_msg)
			INNER JOIN {db_prefix}boards AS b ON (b.id_board = t.id_board)
		    WHERE lr.user_id = {int:user_id}
		    AND t.approved = {int:approved}
			AND {query_see_board}
		    ORDER BY {raw:sort}
		    LIMIT {int:start}, {int:per_page}',
		    array(
			   'user_id' => $context['current_member'],
			   'approved' => 1,
			   'sort' => $sort,
		       'start' => $start,
			   'per_page' => $items_per_page,
		    )
	    );

	    $myReadTopics = array();
	
	    while ($row = $smcFunc['db_fetch_assoc']($results))
	    {
		    $myReadTopics[] = array(
			   'subject' => '<a href="' . $scripturl . '?topic=' . $row['id_topic'] . '.0" target="_blank" rel="noopener">' . $row['subject'] . '</a>',
			   'name' => '<a href="' . $scripturl . '?board=' . $row['id_board'] . '.0" target="_blank" rel="noopener">' . $row['name'] . '</a>',
			   'read_time' => timeformat($row['read_time']),
		    );
	    }

	    $smcFunc['db_free_result']($results);
	
	    return $myReadTopics;
    }

    /**
	* Do the count thing for the pagination.
	*/
    public static function CountAllMyReadTopics()
    {
	    global $smcFunc, $context;

	    $results = $smcFunc['db_query']('', '
		    SELECT COUNT(*)
		    FROM {db_prefix}log_topic_readers AS lr
		    INNER JOIN {db_prefix}topics AS t ON (t.id_topic = lr.topic_id)
		    WHERE lr.user_id = {int:user_id}
		    AND t.approved = {int:approved}',
		    array(
			   'user_id'  => $context['current_member'],
			   'approved' => 1
			)
	    );

	    list ($count) = $smcFunc['db_fetch_row']($results);
	
        $smcFunc['db_free_result']($results);

	    return $count;
    }
}