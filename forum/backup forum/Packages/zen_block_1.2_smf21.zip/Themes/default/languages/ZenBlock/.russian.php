<?php

$txt['zen_settings']                 = 'Zen Block';
$txt['zen_desc']                     = 'Здесь можно изменить настройки блока с содержанием первого сообщения.';
$txt['zen_block_enable']             = 'Блок с содержанием первого сообщения';
$txt['zen_block_status']             = 'Состояние по умолчанию';
$txt['zen_block_status_set']         = ['Свёрнутое', 'Развёрнутое'];
$txt['zen_block_link']               = 'Ссылка';
$txt['zen_block_topic']              = 'Тема популярна';
$txt['zen_where_is']                 = ['Отключить', 'Не показывать на первых страницах тем', 'Показывать на всех страницах тем'];
$txt['zen_ignored_boards']           = 'Игнорируемые разделы';
$txt['zen_ignored_boards_desc']      = 'Отметьте разделы, в которых Zen Block НЕ должен отображаться';
$txt['zen_yashare']                  = 'Показывать блок «Поделиться» от Яндекса';
$txt['zen_yashare_title']            = 'Настройка блока «Поделиться» от Яндекса';
$txt['zen_yashare_services_def']     = 'vkontakte, odnoklassniki, telegram, twitter, viber, whatsapp, skype';
$txt['zen_yashare_color_scheme']     = 'Цветовая схема кнопок соцсетей';
$txt['zen_yashare_color_scheme_set'] = [
    'normal'     => 'Белые иконки на индивидуальном фоне',
    'blackwhite' => 'Белые иконки на черном фоне',
    'whiteblack' => 'Чёрные иконки на белом фоне'
];
$txt['zen_yashare_limit']     = 'Количество соцсетей, отображаемых в виде кнопок';
$txt['zen_yashare_shape']     = 'Форма кнопок соцсетей';
$txt['zen_yashare_shape_set'] = ['round' => 'Круглая', 'normal' => 'Прямоугольная со скругленными углами'];
$txt['zen_yashare_size']      = 'Размер кнопок соцсетей';
$txt['zen_yashare_size_set']  = ['l' => 'Большой', 'm' => 'Средний', 's' => 'Маленький'];
