<?php

$txt['zen_settings']                 = 'Zen Block';
$txt['zen_desc']                     = 'You can change any settings of block with the first post content here.';
$txt['zen_block_enable']             = 'The first post content';
$txt['zen_block_status']             = 'Default status';
$txt['zen_block_status_set']         = ['Minimized', 'Expanded'];
$txt['zen_block_link']               = 'Link';
$txt['zen_block_topic']              = 'Popular topic';
$txt['zen_where_is']                 = ['Disable', 'Don\'t show on the first page of topics', 'Show on all pages of topics'];
$txt['zen_ignored_boards']           = 'Ignored boards';
$txt['zen_ignored_boards_desc']      = 'Select the boards in which Zen Block should NOT be displayed';
$txt['zen_yashare']                  = 'Display "Yandex.Share" block';
$txt['zen_yashare_title']            = 'Customization of the Yandex.Share block';
$txt['zen_yashare_services_def']     = 'twitter, skype, linkedin';
$txt['zen_yashare_color_scheme']     = 'The color scheme of the buttons';
$txt['zen_yashare_color_scheme_set'] = [
    'normal'     => 'White icons with an individual background',
    'blackwhite' => 'White icons with a black background',
    'whiteblack' => 'Black icons with a white background'
];
$txt['zen_yashare_limit']     = 'The number of social networks that are displayed as buttons';
$txt['zen_yashare_shape']     = 'The shape of buttons';
$txt['zen_yashare_shape_set'] = ['round' => 'Round', 'normal' => 'Rectangular with rounded corners'];
$txt['zen_yashare_size']      = 'The size of buttons';
$txt['zen_yashare_size_set']  = ['l' => 'Large', 'm' => 'Medium', 's' => 'Small'];
