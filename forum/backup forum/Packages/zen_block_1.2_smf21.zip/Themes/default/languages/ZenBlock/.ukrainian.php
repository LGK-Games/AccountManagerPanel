<?php

$txt['zen_settings']                 = 'Zen Block';
$txt['zen_desc']                     = 'Тут можна змінювати налаштування блока, що містить зміст першого повідомлення.';
$txt['zen_block_enable']             = 'Блок зі змістом першого повідомлення';
$txt['zen_block_status']             = 'Стан за замовчуванням';
$txt['zen_block_status_set']         = ['Згорнуте', 'Розгорнуте'];
$txt['zen_block_link']               = 'Посилання';
$txt['zen_block_topic']              = 'Тема популярна';
$txt['zen_where_is']                 = ['Відключити', 'Не показувати на перших сторінках тем', 'Показувати на всіх сторінках тем'];
$txt['zen_ignored_boards']           = 'Розділи, що ігноруються';
$txt['zen_ignored_boards_desc']      = 'Відмітьте розділи, в яких Zen Block НЕ повинен відображатись';
$txt['zen_yashare']                  = 'Показувати блок «Поділитись» від Яндекса';
$txt['zen_yashare_title']            = 'Налаштування блока &laquo;Поділитись&raquo; від Яндекса';
$txt['zen_yashare_services_def']     = 'twitter, skype, linkedin, telegram, viber, whatsapp';
$txt['zen_yashare_color_scheme']     = 'Цветовая схема кнопок соцсетей';
$txt['zen_yashare_color_scheme_set'] = [
    'normal'     => 'Белые иконки на индивидуальном фоне',
    'blackwhite' => 'Белые иконки на черном фоне',
    'whiteblack' => 'Чёрные иконки на белом фоне'
];
$txt['zen_yashare_limit']     = 'Количество соцсетей, отображаемых в виде кнопок';
$txt['zen_yashare_shape']     = 'Форма кнопок соцсетей';
$txt['zen_yashare_shape_set'] = ['round' => 'Круглая', 'normal' => 'Прямоугольная со скругленными углами'];
$txt['zen_yashare_size']      = 'Размер кнопок соцсетей';
$txt['zen_yashare_size_set']  = ['l' => 'Большой', 'm' => 'Средний', 's' => 'Маленький'];
