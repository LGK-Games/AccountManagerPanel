<?php

$txt['zen_settings']                 = 'Bloque Zen';
$txt['zen_desc']                     = 'Puede cambiar cualquier configuración del bloque con el contenido de la primera publicación aquí.';
$txt['zen_block_enable']             = 'El primer contenido de la publicación.';
$txt['zen_block_status']             = 'Estado por defecto';
$txt['zen_block_status_set']         = ['Minimizado', 'Maximizado'];
$txt['zen_block_link']               = 'Enlace';
$txt['zen_block_topic']              = 'Tema popular';
$txt['zen_where_is']                 = ['Desactivar', 'No mostrar en la primera página de temas', 'Mostrar en todas las páginas de temas'];
$txt['zen_ignored_boards']           = 'Foros ignorados';
$txt['zen_ignored_boards_desc']      = 'Ingrese la ID de los foros donde no se mostrará el Bloque Zen.';
$txt['zen_yashare']                  = 'Mostrar bloque de enlace de botón "Yandex.Compartir"';
$txt['zen_yashare_title']            = 'Customization of the Yandex.Share block';
$txt['zen_yashare_services_def']     = 'twitter, skype, linkedin';
$txt['zen_yashare_color_scheme']     = 'The color scheme of the buttons';
$txt['zen_yashare_color_scheme_set'] = [
    'normal'     => 'White icons with an individual background',
    'blackwhite' => 'White icons with a black background',
    'whiteblack' => 'Black icons with a white background'
];
$txt['zen_yashare_limit']     = 'The number of social networks that are displayed as buttons';
$txt['zen_yashare_shape']     = 'The shape of buttons';
$txt['zen_yashare_shape_set'] = ['round' => 'Round', 'normal' => 'Rectangular with rounded corners'];
$txt['zen_yashare_size']      = 'The size of buttons';
$txt['zen_yashare_size_set']  = ['l' => 'Large', 'm' => 'Medium', 's' => 'Small'];
