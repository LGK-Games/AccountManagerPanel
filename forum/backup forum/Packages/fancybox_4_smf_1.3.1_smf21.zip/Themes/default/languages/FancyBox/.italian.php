<?php

/**
 * .english language file
 *
 * @package FancyBox 4 SMF
 * @author Bugo https://dragomano.ru/mods/fancybox-4-smf
 */

$txt['fancybox_settings'] = 'FancyBox 4 SMF';
$txt['fancybox_desc'] = 'Questa mod aggiunge una lightbox in stile Mac per le immagini nel testo e per gli allegati.';
$txt['fancybox_prepare_img'] = 'Elaborazione immagini inserite con il tag <strong>[img]</strong>';
$txt['fancybox_show_thumb_for_img'] = 'Visualizza le miniature delle immagini inserite utilizzando il tag <strong>[img]</strong>';
$txt['fancybox_save_url_img'] = 'Se le immagini sono all\'interno dei links, non eseguire per non corrompere i collegamenti';
$txt['fancybox_show_thumb_for_img_subtext'] = 'Puoi specificare la larghezza delle immagini nelle <a href="%1$s">impostazioni per gli allegati</a>.';
$txt['fancybox_prepare_attach'] = 'Elaborazione immagini inserite con il tag <strong>[attach]</strong>';
$txt['fancybox_show_thumb_for_attach'] = 'Visualizza le miniature delle immagini inserite utilizzando il tag <strong>[attach]</strong>';
$txt['fancybox_show_thumb_for_attach_subtext'] = 'Disabilita per visualizzare le immagini invariate.';
$txt['fancybox_prepare_attachments'] = 'Elaborazione immagini allegate';
$txt['fancybox_show_download_link'] = 'Visualizza pulsante download';
$txt['fancybox_thumbnails'] = 'Visualizza le miniature sotto le slides';
$txt['fancybox_traffic'] = 'Risparmio di traffico <div class="smalltext">Se abilitato, gli utenti non registrati vedranno una piccola immagine speciale con un omino che corre invece delle immagini originali. Quando si fa clic su di esso, vedranno l\'immagine originale.</div>';

$txt['fancy_click'] = 'Clicca per caricare l\'immagine';
$txt['fancy_button_next'] = 'Successiva';
$txt['fancy_button_prev'] = 'Precedente';
$txt['fancy_text_error'] = 'Qualcosa è andato storto, prova più tardi';
$txt['fancy_text_modal'] = 'Puoi chiudere questa modale con il tasto ESC della tastiera';
$txt['fancy_image_error'] = 'Imagine non trovata';
$txt['fancy_element_not_found'] = 'Elementi HTML non trovati';
$txt['fancy_ajax_not_found'] = 'Errore caricamento AJAX: Non trovato';
$txt['fancy_ajax_forbidden'] = 'Errore caricamento AJAX: Negato';
$txt['fancy_iframe_error'] = 'Errore caricamento Pagina';
$txt['fancy_toggle_zoom'] = 'Attiva/disattiva il livello di zoom';
$txt['fancy_toggle_thumbs'] = 'Attiva/disattiva le miniature';
$txt['fancy_toggle_slideshow'] = 'Attiva/disattiva presentazione';
$txt['fancy_toggle_fullscreen'] = 'Attiva/disattiva modalità a schermo intero';
$txt['fancy_download'] = 'Download';
