<?php

/**
 * .english language file
 *
 * @package FancyBox 4 SMF
 * @author Bugo https://dragomano.ru/mods/fancybox-4-smf
 */

$txt['fancybox_settings'] = 'FancyBox 4 SMF';
$txt['fancybox_desc'] = 'Αυτή η τροποποίηση προσθέτει ωραία εφέ fancybox σε εν σειρά και συνημμένες εικόνες.';
$txt['fancybox_prepare_img'] = 'Επεξεργασία εικόνων που έχουν εισαχθεί με την ετικέτα <strong>[img]</strong>';
$txt['fancybox_show_thumb_for_img'] = 'Εμφάνιση μικρογραφιών εικόνων που έχουν εισαχθεί χρησιμοποιώντας την ετικέτα <strong>[img]</strong>';
$txt['fancybox_save_url_img'] = 'Εάν οι εικόνες βρίσκονται μέσα στους συνδέσμους, αφήστε τους συνδέσμους απείραχτους';
$txt['fancybox_show_thumb_for_img_subtext'] = 'Μπορείτε να καθορίσετε το πλάτος των εικόνων στις <a href="%1$s">ρυθμίσεις συνημμένου</a>.';
$txt['fancybox_prepare_attach'] = 'Επεξεργασία εικόνων που έχουν εισαχθεί με την ετικέτα <strong>[επισύναψη]</strong>';
$txt['fancybox_show_thumb_for_attach'] = 'Εμφάνιση μικρογραφιών εικόνων που έχουν εισαχθεί χρησιμοποιώντας την ετικέτα <strong>[επισύναψη]</strong>';
$txt['fancybox_show_thumb_for_attach_subtext'] = 'Απενεργοποιήστε για να εμφανίζονται οι εικόνες αμετάβλητες.';
$txt['fancybox_prepare_attachments'] = 'Επεξεργασία συνημμένων εικόνων';
$txt['fancybox_show_download_link'] = 'Εμφάνιση κουμπιού λήψης';
$txt['fancybox_thumbnails'] = 'Εμφάνιση μικρογραφιών κάτω από τις διαφάνειες';
$txt['fancybox_traffic'] = 'Εξοικονόμηση επισκεψιμότητας <div class="smalltext">Εάν είναι ενεργοποιημένη, οι μη εγγεγραμμένοι χρήστες θα δουν μια ειδική μικρή εικόνα με ανθρωπάκι που τρέχει αντί για πρωτότυπες εικόνες. Όταν κάνουν κλικ σε αυτό, θα δουν μια πρωτότυπη εικόνα.</div>';

$txt['fancy_click'] = 'Κάντε κλικ για να φορτώσετε την αρχική εικόνα';
$txt['fancy_button_next'] = 'Επόμενο';
$txt['fancy_button_prev'] = 'Προηγούμενο';
$txt['fancy_text_error'] = 'Κάτι πήγε στραβά, δοκιμάστε ξανά αργότερα';
$txt['fancy_text_modal'] = 'Μπορείτε να κλείσετε αυτό το περιεχόμενο με το κλειδί ESC';
$txt['fancy_image_error'] = 'Η εικόνα δεν βρέθηκε';
$txt['fancy_element_not_found'] = 'Το στοιχείο HTML δεν βρέθηκε';
$txt['fancy_ajax_not_found'] = 'Σφάλμα κατά τη φόρτωση του AJAX: Δεν βρέθηκε';
$txt['fancy_ajax_forbidden'] = 'Σφάλμα κατά τη φόρτωση του AJAX: Απαγορευμένο';
$txt['fancy_iframe_error'] = 'Σφάλμα κατά τη φόρτωση της σελίδας';
$txt['fancy_toggle_zoom'] = 'Εναλλαγή επιπέδου ζουμ';
$txt['fancy_toggle_thumbs'] = 'Εναλλαγή μικρογραφιών';
$txt['fancy_toggle_slideshow'] = 'Εναλλαγή παρουσίασης';
$txt['fancy_toggle_fullscreen'] = 'Εναλλαγή λειτουργίας πλήρους οθόνης';
$txt['fancy_download'] = 'Κατεβάστε';
