<?php

/**
 * .english language file
 *
 * @package FancyBox 4 SMF
 * @author Bugo https://dragomano.ru/mods/fancybox-4-smf
 */

$txt['fancybox_settings'] = 'FancyBox 4 SMF';
$txt['fancybox_desc'] = 'Esta modificación agrega agradables efectos al ver las imágenes en línea y adjuntas.';
$txt['fancybox_prepare_img'] = 'Procesamiento de imágenes que se insertaron con la etiqueta <strong>[img]</strong>';
$txt['fancybox_show_thumb_for_img'] = 'Mostrar miniaturas de imágenes insertadas con la etiqueta <strong>[img]</strong>';
$txt['fancybox_save_url_img'] = 'Si las imágenes están dentro de los enlaces, deje los enlaces intactos.';
$txt['fancybox_show_thumb_for_img_subtext'] = 'Puede especificar el ancho de las imágenes en <a href="%1$s">configuración de archivos adjuntos</a>.';
$txt['fancybox_prepare_attach'] = 'Procesamiento de imágenes que se insertaron con la etiqueta <strong>[attach]</strong>';
$txt['fancybox_show_thumb_for_attach'] = 'Mostrar miniaturas de imágenes insertadas con la etiqueta <strong>[attach]</strong>';
$txt['fancybox_show_thumb_for_attach_subtext'] = 'Desactivar para mostrar las imágenes sin cambios.';
$txt['fancybox_prepare_attachments'] = 'Procesamiento de imágenes adjuntas';
$txt['fancybox_show_download_link'] = 'Mostrar botón de descarga';
$txt['fancybox_thumbnails'] = 'Mostrar miniaturas debajo de las diapositivas';
$txt['fancybox_traffic'] = 'Ahorro de tráfico <div class="smalltext">Si está activado, los usuarios no registrados verán una imagen pequeña especial con un hombrecito corriendo en lugar de las imágenes originales. Al hacer clic en él, verán una imagen original.</div>';

$txt['fancy_click'] = 'Haga clic para cargar la imagen original';
$txt['fancy_button_next'] = 'Próximo';
$txt['fancy_button_prev'] = 'Previo';
$txt['fancy_text_error'] = 'Algo salió mal, inténtalo de nuevo más tarde';
$txt['fancy_text_modal'] = 'Puede cerrar esta ventana presionando la tecla ESC';
$txt['fancy_image_error'] = 'Imagen no encontrada';
$txt['fancy_element_not_found'] = 'Elemento HTML no encontrado';
$txt['fancy_ajax_not_found'] = 'Error al cargar AJAX: no encontrado';
$txt['fancy_ajax_forbidden'] = 'Error al cargar AJAX: Prohibido';
$txt['fancy_iframe_error'] = 'Error al cargar la página';
$txt['fancy_toggle_zoom'] = 'Alternar nivel de zoom';
$txt['fancy_toggle_thumbs'] = 'Alternar miniaturas';
$txt['fancy_toggle_slideshow'] = 'Alternar presentación de diapositivas';
$txt['fancy_toggle_fullscreen'] = 'Alternar el modo de pantalla completa';
$txt['fancy_download'] = 'Descargar';
