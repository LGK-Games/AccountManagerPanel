<?php

/**
 * .english language file
 *
 * @package FancyBox 4 SMF
 * @author Bugo https://dragomano.ru/mods/fancybox-4-smf
 */

$txt['fancybox_settings'] = 'FancyBox 4 SMF';
$txt['fancybox_desc'] = 'Această modificare adaugă efecte fancybox drăguțe la imaginile din linie și atașate.';
$txt['fancybox_prepare_img'] = 'Procesarea imaginilor care au fost introduse cu tag-ul <strong>[img]</strong>';
$txt['fancybox_show_thumb_for_img'] = 'Afișează miniaturile imaginilor inserate folosind tag-ul <strong>[img]</strong>';
$txt['fancybox_save_url_img'] = 'Dacă imaginile se află în interiorul link-urilor, lăsați link-urile neatinse';
$txt['fancybox_show_thumb_for_img_subtext'] = 'Poți specifica lățimea imaginilor în <a href="%1$s">setările atașamentului</a>.';
$txt['fancybox_prepare_attach'] = 'Procesarea imaginilor care au fost introduse cu tag-ul <strong>[attach]</strong>';
$txt['fancybox_show_thumb_for_attach'] = 'Afișează miniaturile imaginilor inserate folosind tag-ul <strong>[attach]</strong>';
$txt['fancybox_show_thumb_for_attach_subtext'] = 'Dezactivează pentru a afișa imagini nemodificate.';
$txt['fancybox_prepare_attachments'] = 'Prelucrarea imaginilor atașate';
$txt['fancybox_show_download_link'] = 'Arată butonul de descărcare';
$txt['fancybox_thumbnails'] = 'Arată miniaturi sub slide-uri';
$txt['fancybox_traffic'] = 'Economisirea traficului <div class="smalltext">Dacă este activată, utilizatorii neînregistrați vor vedea o imagine mică specială cu un om mic care rulează în locul imaginilor originale. Când se face clic pe el, vor vedea imaginea originală.</div>';

$txt['fancy_click'] = 'Clic pentru a încărca imaginea originală';
$txt['fancy_button_next'] = 'Următorul';
$txt['fancy_button_prev'] = 'Precedentul';
$txt['fancy_text_error'] = 'Ceva nu a mers bine. Te rugăm să încerci din nou mai târziu';
$txt['fancy_text_modal'] = 'Poți închide acest conținut modal apăsând tasta ESC';
$txt['fancy_image_error'] = 'Imaginea nu a fost găsită';
$txt['fancy_element_not_found'] = 'Elementul HTML nu a fost găsit';
$txt['fancy_ajax_not_found'] = 'Eroare la încărcarea AJAX: Nu a fost găsit';
$txt['fancy_ajax_forbidden'] = 'Eroare la încărcarea AJAX: Interzis';
$txt['fancy_iframe_error'] = 'Eroare la încărcarea paginii';
$txt['fancy_toggle_zoom'] = 'Comută nivelul de zoom';
$txt['fancy_toggle_thumbs'] = 'Comută miniaturile';
$txt['fancy_toggle_slideshow'] = 'Comută prezentarea';
$txt['fancy_toggle_fullscreen'] = 'Comută modul ecran complet';
$txt['fancy_download'] = 'Descarcă';
