<?php

/*******************************************************************************
 * Email Obfuscator
 *
 * A modification for SMF 2.1 that obfuscates email addresses in order to
 * protect them from being harvested by spammers. Real humans accessing your
 * forum with a normal browser will see the email address just like normal, but
 * harvesting bots will see only some inline JavaScript filled with random
 * characters.
 *
 * Copyright (c) 2023 Jon Stovell
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/

if (!defined('SMF'))
	die('No direct access...');

/**
 * Load the CSS and JavaScript
 * Called by:
 * 		integrate_load_theme
 */
function email_obfuscator_load_theme()
{
	loadCSSFile('EmailObfuscator.css', array('minimize' => true));

	// Sadly, JavaScript's built-in base64 functions mangle UTF-8 characters
	loadJavaScriptFile('base64.js', array('minimize' => true));
}

/**
 * Replace email addresses with an obfuscating JavaScript
 * Called by:
 * 		integrate_buffer
 */
function email_obfuscator_rewrite_buffer($buffer)
{
	global $modSettings, $context, $txt;

	static $depth = 0;

	$depth++;

	// Don't mess with non-HTML or Ajax requests
	if ($depth === 1 && (strpos($buffer, '<!DOCTYPE html') !== 0 || isset($_REQUEST['xml'])))
		return $buffer;

	// Don't mess with the contents of textareas
	$parts = preg_split('~(</textarea>|<textarea[^>]+>)~i', $buffer, -1, PREG_SPLIT_DELIM_CAPTURE);
	for ($i = 0, $n = count($parts); $i < $n; $i++)
	{
		// It goes 0 = outside, 1 = begin tag, 2 = inside, 3 = close tag, repeat.
		// @todo The isset bit is a bit of a hack to stop bots somehow generating occasional errors. I need to figure out why that happens and stop it properly.
		if ($i % 4 == 2 && isset($parts[$i + 1]))
		{
			$textarea_tag = $parts[$i - 1] . $parts[$i] . $parts[$i + 1];
			$substitute = $parts[$i - 1] . $i . $parts[$i + 1];
			$textarea_tags[$substitute] = $textarea_tag;
			$parts[$i] = $i;
		}
	}
	$buffer = implode('', $parts);

	// Don't mess with the contents of script tags
	$parts = preg_split('~(</script>|<script[^>]+>)~i', $buffer, -1, PREG_SPLIT_DELIM_CAPTURE);
	for ($i = 0, $n = count($parts); $i < $n; $i++)
	{
		// It goes 0 = outside, 1 = begin tag, 2 = inside, 3 = close tag, repeat.
		// @todo The isset bit is a bit of a hack to stop bots somehow generating occasional errors. I need to figure out why that happens and stop it properly.
		if ($i % 4 == 2 && isset($parts[$i + 1]))
		{
			$script_tag = $parts[$i - 1] . $parts[$i] . $parts[$i + 1];
			$substitute = $parts[$i - 1] . $i . $parts[$i + 1];
			$script_tags[$substitute] = $script_tag;
			$parts[$i] = $i;
		}
	}
	$buffer = implode('', $parts);

	if (empty($modSettings['tld_regex']))
	{
		if (function_exists('set_tld_regex'))
			set_tld_regex();
		else
			// This matches the basic 2012 list of gTLDs and ccTLDs
			$modSettings['tld_regex'] = '(?>xxx|qa|a(?>c|d|e(?>ro|)|f|g|i|l|m|n|o|q|r|s(?>ia|)|t|u|w|x|z)|b(?>a|b|d|e|f|g|h|i(?>z|)|j|m|n|o|r|s|t|v|w|y|z)|c(?>a(?>t|)|c|d|f|g|h|i|k|l|m|n|o(?>op|m|)|r|s|u|v|x|y|z)|d(?>d|e|j|k|m|o|z)|e(?>du|c|e|g|h|r|s|t|u)|f(?>i|j|k|m|o|r)|g(?>ov|a|b|d|e|f|g|h|i|l|m|n|p|q|r|s|t|u|w|y)|h(?>k|m|n|r|t|u)|i(?>d|e|l|m|n(?>fo|t|)|o|q|r|s|t)|j(?>a|e|m|o(?>bs|)|p)|k(?>e|g|h|i|m|n|p|r|w|y|z)|l(?>a|b|c|i|k|r|s|t|u|v|y)|m(?>il|a|c|d|e|g|h|k|l|m|n|o(?>bi|)|p|q|r|s|t|u(?>seum|)|v|w|x|y|z)|n(?>a(?>me|)|c|e(?>t|)|f|g|i|l|o|p|r|u|z)|o(?>rg|m)|p(?>ost|a|e|f|g|h|k|l|m|n|r(?>o|)|s|t|w|y)|r(?>e|o|s|u|w)|s(?>a|b|c|d|e|g|h|i|j|k|l|m|n|o|r|s|t|u|v|x|y|z)|t(?>el|c|d|f|g|h|j|k|l|m|n|o|p|r(?>avel|)|t|v|w|z)|u(?>a|g|k|s|y|z)|v(?>a|c|e|g|i|n|u)|w(?>f|s)|y(?>e|t|u)|z(?>a|m|w))';
	}

	$email_regex = '
	# Preceded by a non-domain character or start of line
	(?<=^|[^\p{L}\p{M}\p{N}\-\.])

	# An email address
	([\p{L}\p{M}\p{N}_\-.]{1,80})
	@
	([\p{L}\p{M}\p{N}\-.]+)
	\.
	('. $modSettings['tld_regex'] . ')

	# Followed by either:
	(?=
		# end of line or a non-domain character (excluding the dot)
		$|[^\p{L}\p{M}\p{N}\-]
		| # or
		# a dot followed by end of line or a non-domain character
		\.(?=$|[^\p{L}\p{M}\p{N}\-])
	)';

	$flags = 'xi' . ($context['utf8'] ? 'u' : '');

	loadLanguage('EmailObfuscator');

	// Deal with mailto links
	$buffer = preg_replace_callback('~<a\b[^>]*href="mailto:' . $email_regex . '"[^>]*>(.*?)</a>~' . $flags, function ($matches) use ($txt, $modSettings, $depth) {

		$fallback = email_obfuscator_rewrite_buffer($matches[4]);

		// If the email address was nowhere inside the link's content, append it in parentheses
		$email = $matches[1] . '@' . $matches[2] . '.' . $matches[3];
		if (preg_match('~' . $email . '~', $matches[4]) === 0 && !empty($modSettings['email_obfuscator_show_fallback']))
			$fallback .= ' (' . email_obfuscator_rewrite_buffer($email) . ')';

		email_obfuscator_set_script($script, $fallback, $matches, $depth);

		return $script . $fallback;

	}, $buffer);

	// Deal with any other non-selfclosing elements with email addresses in their attributes
	$buffer = preg_replace_callback('~<(\w+)\b[^>]*=["\'][^"\']*\b' . $email_regex . '\b[^"\']*["\'][^>]*>(.*?)</\1>~' . $flags, function ($matches) use ($txt, $modSettings, $depth) {

		$fallback = email_obfuscator_rewrite_buffer($matches[5]);

		email_obfuscator_set_script($script, $fallback, $matches, $depth);

		return $script . $fallback;

	}, $buffer);

	// Deal with any selfclosing elements with email addresses in their attributes
	$buffer = preg_replace_callback('~<(\w+)\b[^>]*=["\'][^"\']*\b' . $email_regex . '\b[^"\']*["\'][^>]*>~' . $flags, function ($matches) use ($txt, $modSettings, $depth) {

		$fallback = '[' . $txt['enable_js'] . ']';

		email_obfuscator_set_script($script, $fallback, $matches, $depth);

		return $script . $fallback;

	}, $buffer);

	// Finally, deal with any plain email addresses
	$buffer = preg_replace_callback('~' . $email_regex . '~' . $flags, function ($matches) use ($txt, $modSettings, $depth) {

		if (empty($modSettings['email_obfuscator_show_fallback']))
			$fallback = '[' . $txt['enable_js'] . ']';
		else
			$fallback = '<span>' . $matches[1] . '</span><span class="fluff">[' . $txt['delete_this'] . ' ' . uniqid() . ']</span><span class="zerowidth">[' . $txt['insert_at'] . ']</span><span class="em_domain">' . $matches[2] . '</span><span class="zerowidth">[' . $txt['insert_dot'] . ']</span><span>' . $matches[3] . '</span>';

		email_obfuscator_set_script($script, $fallback, $matches, $depth);

		return $script . $fallback;

	}, $buffer);

	// Restore scripts
	if (!empty($script_tags))
		$buffer = str_replace(array_keys($script_tags), array_values($script_tags), $buffer);

	// Restore textareas
	if (!empty($textarea_tags))
		$buffer = str_replace(array_keys($textarea_tags), array_values($textarea_tags), $buffer);

	$depth--;

	return $buffer;
}

/**
 * Sets <script> and <noscript> values as appropriate
 * Called by:
 * 		email_obfuscator_rewrite_buffer
 */
function email_obfuscator_set_script(&$script, &$fallback, $matches, $depth)
{
	global $user_info;

	// Try to prevent email addresses from being indexed by search engines
	if (!empty($user_info['possibly_robot']))
	{
		$script = $fallback;
		$fallback = '';
	}

	// Don't nest script elements. Madness and ruin stalk that path.
	elseif ($depth === 1)
	{
		$script = "<script>document.write(Base64.decode('" . str_replace("'", "\'", base64_encode($matches[0])) . "'));</script>";

		$fallback = '<noscript>' . $fallback . '</noscript>';
	}
	else
		$script = '';
}

/**
 * Give the admin some control
 * Called by:
 * 		integrate_general_mod_settings
 */
function email_obfuscator_settings(&$config_vars)
{
	loadLanguage('EmailObfuscator');

	$email_obfuscator[] = array('check', 'email_obfuscator_show_fallback');

	// If anything is already in $config_vars, add a separator
	if (!empty($config_vars) && reset($config_vars) !== '')
		$email_obfuscator[] = '';

	$config_vars = array_merge($email_obfuscator, $config_vars);

}

/**
 * Make the help popup work in the settings
 * Called by:
 * 		integrate_helpadmin
 */
function email_obfuscator_helpadmin()
{
	loadLanguage('EmailObfuscator');
}

/**
 * Mention who made this thing
 * Called by:
 * 		integrate_credits
 */
function email_obfuscator_credits()
{
	global $context;
	$context['copyrights']['mods'][] = 'Email Obfuscator by Jon &quot;Sesquipedalian&quot; Stovell &copy; 2019';
}
