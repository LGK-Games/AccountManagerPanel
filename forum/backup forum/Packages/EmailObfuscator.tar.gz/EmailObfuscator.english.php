<?php
global $helptxt;

$txt['enable_js'] = 'Please enable JavaScript to see this content';
$txt['insert_at'] = 'insert an at symbol here';
$txt['insert_dot'] = 'insert a dot here';
$txt['delete_this'] = 'delete this bit';

$txt['email_obfuscator_show_fallback'] = 'Show a fallback version of obfuscated email addresses to users without JavaScript';

$helptxt['email_obfuscator_show_fallback'] = 'When this option is disabled, users without JavaScript enabled will only see a message telling them that they must enable it to see the hidden content. When this option is enabled, they will see a fallback that uses various HTML and CSS tricks to make the email address illegible to a machine while still appearing to a human like a normal, readable address.
<br><br>
Since (1) most humans, including visually impaired ones using screen readers, will have JavaScript enabled when visiting your site, and (2) enabling the fallback makes it theoretically possible to extract the email from the raw HTML code (though still very unlikely), this option is disabled by default.';
?>