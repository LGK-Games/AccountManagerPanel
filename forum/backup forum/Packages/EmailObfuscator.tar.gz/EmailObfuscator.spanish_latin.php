<?php
// Spanish translation https://www.bombercode.net Copyright 2014-2019

global $helptxt;

$txt['enable_js'] = 'Por favor, active JavaScript para ver este contenido';
$txt['insert_at'] = 'Inserte un símbolo aquí';
$txt['insert_dot'] = 'Inserte un punto aquí';
$txt['delete_this'] = 'Borrar este bit';

$txt['email_obfuscator_show_fallback'] = 'Muestra una versión alternativa de direcciones de correo electrónico ofuscado a usuarios sin JavaScript';

$helptxt['email_obfuscator_show_fallback'] = 'Cuando esta opción está desactivada, los usuarios sin JavaScript habilitado solo verán un mensaje que les dice que deben habilitarla para ver el contenido oculto. Cuando esta opción está habilitada, verán un respaldo que utiliza varios trucos de HTML y CSS para hacer que la dirección de correo electrónico sea ilegible para una máquina, mientras que para un humano sigue apareciendo como una dirección normal y legible.
<br><br>
Dado que (1) la mayoría de los seres humanos, incluidos los que tienen deficiencias visuales y que usan lectores de pantalla, tendrán habilitado JavaScript cuando visiten su sitio, y (2) habilitar el respaldo hace que en teoría sea posible extraer el correo electrónico del código HTML sin procesar (aunque todavía es muy poco probable) , esta opción está deshabilitada por defecto.';
?>