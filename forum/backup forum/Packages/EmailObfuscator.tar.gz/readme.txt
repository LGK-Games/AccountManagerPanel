[size=x-large][b]Email Obfuscator[/b][/size]

A modification for Simple Machines Forum verion 2.1 that obfuscates email addresses in order to protect them from being harvested by spammers. Real humans accessing your site with a normal browser will see the email address just like normal, but harvesting bots will see only some inline JavaScript filled with random characters.

This should not be relied on as absolute, 100% protection against harvesting bots, but it will help a great deal.


[size=large][b]Settings[/b][/size]

There is one setting, "Show a fallback version of obfuscated email addresses to users without JavaScript", which is disabled by default. When this option is disabled, users without JavaScript enabled will only see a message telling them that they must enable it to see the hidden content. When this option is enabled, they will see a fallback that uses various HTML and CSS tricks to make the email address illegible to a machine while still appearing to a human like a normal, readable address.


[size=large][b]License[/b][/size]

Email Obfuscator is released under the MIT License. A full copy of this license is included in the package file.

Email Obfuscator includes a copy of Base64.js, which is released under the BSD 3-clause License. Please see https://github.com/dankogai/js-base64 for details.


[size=large][b]Changelog[/b][/size]

Version 1.3:
[list]
	[li]Fixes a bug on the Profile page when the "Require reactivation after email change" setting was enabled.[/li]
[/list]

Version 1.2:
[list]
	[li]More aggressively prevents search engines from indexing email addresses[/li]
[/list]

Version 1.1:
[list]
	[li]Added Latin Spanish translation[/li]
[/list]

Version 1.0:
[list]
	[li]Initial release[/li]
[/list]