redis mod for SMFsss
