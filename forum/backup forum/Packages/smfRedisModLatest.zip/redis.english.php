<?php
	$txt['cache_redis_settings'] = 'SMF redis caching settings';
	$helptxt['cache_cache_redis']	= 'Redis cache directory f.e. 127.0.0.1:6379';

	$txt['cache_cache_redis']	= 'Redis cache directory f.e. 127.0.0.1:6379';