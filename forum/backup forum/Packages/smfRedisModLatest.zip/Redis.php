<?php

namespace SMF\Cache\APIs;

require 'predis/autoload.php';
\Predis\Autoloader::register();

use SMF\Cache\CacheApi;
use SMF\Cache\CacheApiInterface;

if (!defined('SMF'))
	die('No direct access...');

class Redis extends CacheApi implements CacheApiInterface
{

	public static function integrate_helpadmin()
	{
		global $helptxt;
		loadLanguage('redis');

	}
	//used to register new redis config settings
	public static function integrate_update_settings_file (&$settings_defs)
	{
		global $txt;
		loadLanguage('redis');

		$settings_defs["cache_redis"] = array(
			'text' 		=> '/* redis connection string */',
			'default' 	=> '127.0.0.1:6379',
			'type' 		=> 'string',
		);
	}

	private $client;

	public function __construct()
	{
		parent::__construct();
	}

	public function cacheSettings(array &$config_vars)
	{
		global $context, $txt;
		loadLanguage('redis');

		$class_name = $this->getImplementationClassKeyName();
		$class_name_txt_key = strtolower($class_name);

		$config_vars[] = $txt['cache_'. $class_name_txt_key .'_settings'];
		$config_vars[] = array('cache_redis', $txt['cachedir'], 'file', 'text', 36, 'cache_cache_redis');

		if (!isset($context['settings_post_javascript']))
			$context['settings_post_javascript'] = '';

		$context['settings_post_javascript'] .= '
			$("#cache_accelerator").change(function (e) {
				var cache_type = e.currentTarget.value;
				$("#cache_redis").prop("disabled", cache_type != "'. $class_name .'");
			});';
	}

	public function cleanCache($type = '')
	{
		return $this->client->flushAll();
	}

	public function isSupported($test = false)
	{
		global $cache_redis;

		$supported = class_exists('Redis');

		if ($test)
			return $supported;

		return parent::isSupported() && $supported && !empty($cache_redis);
	}

	public function connect()
	{
		global $cache_redis;

		//on first install it would fail otherwise?!
		if(is_null($cache_redis))
			$cache_redis = '127.0.0.1:6379';

		$redisConnection = 'tcp://' . $cache_redis;

		$this->client = new \Predis\Client($redisConnection, ['prefix' => 'smf:']);
	}

	public function getData($key, $ttl = null)
	{
		return $this->client->get($key);
	}

	public function putData($key, $value, $ttl = null)
	{
		//if ttl is negative / null we need to remove the key
		if($ttl <= 0 || is_null($ttl))
		    return $this->client->del($key);

		return $this->client->set($key, $value, 'EX', intval($ttl * 60));
	}

}

?>