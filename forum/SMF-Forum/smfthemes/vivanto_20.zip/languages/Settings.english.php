<?php
// Version: 2.0; Settings

// Important! Before editing these language files please read the text at the top of index.english.php.

global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.gif';
$txt['theme_description'] = 'A fresh and vibrant theme combined with joyful colors. <br /><br />Vivanto by <a href="http://www.dzinerstudio.com">DzinerStudio</a>';

?>