<?php

// Version: 2.0; ThemeStrings
$txt['icons_check'] = 'Activar iconos sociales';
$txt['rs_facebook'] = 'Facebook';
$txt['facebook_check'] = 'Activar icono de Facebook';
$txt['facebook_text'] = 'Direccion de la pagina de Facebook';
$txt['rs_twitter'] = 'Twitter';
$txt['twitter_check'] = 'Activar icono de Twitter';
$txt['twitter_text'] = 'Direccion de la pagina de Twitter';
$txt['rs_youtube'] = 'Youtube';
$txt['youtube_check'] = 'Activar icono de Youtube';
$txt['youtube_text'] = 'Direccion de la pagina de  Youtube';
$txt['rs_rss'] = 'RSS';
$txt['rss_check'] = 'Activar icono de RSS';
$txt['rss_text'] = 'Direccion de la pagina de RSS';
$txt['redsy_copyright'] = 'Agrega tu copyright personalizado';
$txt['edit_profile'] = 'Editar perfil';
$txt['profile_account'] = 'Configuracion de la cuenta';
$txt['new_post'] = 'Nuevos temas';
$txt['new_replies'] = 'Nuevas respuestas';
$txt['redsy_navbar'] = 'Activar barra de navegacion fija';
$txt['redsy_navbar_height'] = 'Altura de la barra de navegacion';
$txt['redsy_navbar_height_desc'] = 'Minimo de altura: 50px';
$txt['st_actions'] = 'Acciones';

?>