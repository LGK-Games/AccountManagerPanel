<?php
/**
 * Simple Machines Forum (SMF)
 *
 * @package SMF
 * @author Simple Machines
 * @copyright 2011 Simple Machines
 * @license http://www.simplemachines.org/about/smf/license.php BSD
 *
 * @version 2.0
 */

/*	This template is, perhaps, the most important template in the theme. It
	contains the main template layer that displays the header and footer of
	the forum, namely with main_above and main_below. It also contains the
	menu sub template, which appropriately displays the menu; the init sub
	template, which is there to set the theme up; (init can be missing.) and
	the linktree sub template, which sorts out the link tree.

	The init sub template should load any data and set any hardcoded options.

	The main_above sub template is what is shown above the main content, and
	should contain anything that should be shown up there.

	The main_below sub template, conversely, is shown after the main content.
	It should probably contain the copyright statement and some other things.

	The linktree sub template should display the link tree, using the data
	in the $context['linktree'] variable.

	The menu sub template should display all the relevant buttons the user
	wants and or needs.

	For more information on the templating system, please see the site at:
	http://www.simplemachines.org/
*/

// Initialize the template... mainly little settings.
function template_init()
{
	global $context, $settings, $options, $txt;

	/* Use images from default theme when using templates from the default theme?
		if this is 'always', images from the default theme will be used.
		if this is 'defaults', images from the default theme will only be used with default templates.
		if this is 'never' or isn't set at all, images from the default theme will not be used. */
	$settings['use_default_images'] = 'never';

	/* What document type definition is being used? (for font size and other issues.)
		'xhtml' for an XHTML 1.0 document type definition.
		'html' for an HTML 4.01 document type definition. */
	$settings['doctype'] = 'xhtml';

	/* The version this template/theme is for.
		This should probably be the version of SMF it was created for. */
	$settings['theme_version'] = '2.0';

	/* Set a setting that tells the theme that it can render the tabs. */
	$settings['use_tabs'] = true;

	/* Use plain buttons - as opposed to text buttons? */
	$settings['use_buttons'] = true;

	/* Show sticky and lock status separate from topic icons? */
	$settings['separate_sticky_lock'] = true;

	/* Does this theme use the strict doctype? */
	$settings['strict_doctype'] = false;

	/* Does this theme use post previews on the message index? */
	$settings['message_index_preview'] = false;

	/* Set the following variable to true if this theme requires the optional theme strings file to be loaded. */
	$settings['require_theme_strings'] = true;
}

// The main sub template above the content.
function template_html_above()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

	// Show right to left and the character set for ease of translating.
	echo '<!DOCTYPE html>
<html', $context['right_to_left'] ? ' dir="rtl"' : '', '>
<head>';

	// The ?fin20 part of this link is just here to make sure browsers don't cache it wrongly.
	echo '
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
	<link rel="stylesheet" type="text/css" href="', $settings['theme_url'], '/css/all.css?fin20" />
	<link rel="stylesheet" href="', $settings['theme_url'], '/css/responsive.css" />
	<link rel="stylesheet" type="text/css" href="', $settings['theme_url'], '/css/index', $context['theme_variant'], '.css?fin20" />';

	// Some browsers need an extra stylesheet due to bugs/compatibility issues.
	foreach (array('ie7', 'ie6', 'webkit') as $cssfix)
		if ($context['browser']['is_' . $cssfix])
			echo '
	<link rel="stylesheet" type="text/css" href="', $settings['default_theme_url'], '/css/', $cssfix, '.css" />';

	// RTL languages require an additional stylesheet.
	if ($context['right_to_left'])
		echo '
	<link rel="stylesheet" type="text/css" href="', $settings['theme_url'], '/css/rtl.css" />';

	// Here comes the JavaScript bits!
	echo '
	<script type="text/javascript" src="', $settings['theme_url'], '/scripts/popper.min.js"></script>
	<script type="text/javascript" src="', $settings['theme_url'], '/scripts/jquery.min.js?fin20"></script>
	<script type="text/javascript" src="', $settings['theme_url'], '/scripts/bootstrap.min.js?fin20"></script>
	<script type="text/javascript" src="', $settings['default_theme_url'], '/scripts/script.js?fin20"></script>
	<script type="text/javascript" src="', $settings['theme_url'], '/scripts/theme.js?fin20"></script>
	<script type="text/javascript"><!-- // --><![CDATA[
		var smf_theme_url = "', $settings['theme_url'], '";
		var smf_default_theme_url = "', $settings['default_theme_url'], '";
		var smf_images_url = "', $settings['images_url'], '";
		var smf_scripturl = "', $scripturl, '";
		var smf_iso_case_folding = ', $context['server']['iso_case_folding'] ? 'true' : 'false', ';
		var smf_charset = "', $context['character_set'], '";', $context['show_pm_popup'] ? '
		var fPmPopup = function ()
		{
			if (confirm("' . $txt['show_personal_messages'] . '"))
				window.open(smf_prepareScriptUrl(smf_scripturl) + "action=pm");
		}
		addLoadEvent(fPmPopup);' : '', '
		var ajax_notification_text = "', $txt['ajax_in_progress'], '";
		var ajax_notification_cancel_text = "', $txt['modify_cancel'], '";
	// ]]></script>';

	echo '  
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="', $context['page_title_html_safe'], '" />', !empty($context['meta_keywords']) ? '
	<meta name="keywords" content="' . $context['meta_keywords'] . '" />' : '', '
	<title>', $context['page_title_html_safe'], '</title>';

        	echo '
	<style type="text/css">
	@media (min-width: 979px) 
	{
		.container {
			max-width: ' . $settings['forum_width'] . ';
		}
	}
	</style>';
	// Please don't index these Mr Robot.
	if (!empty($context['robot_no_index']))
		echo '
	<meta name="robots" content="noindex" />';

	// Present a canonical url for search engines to prevent duplicate content in their indices.
	if (!empty($context['canonical_url']))
		echo '
	<link rel="canonical" href="', $context['canonical_url'], '" />';

	// Show all the relative links, such as help, search, contents, and the like.
	echo '
	<link rel="help" href="', $scripturl, '?action=help" />
	<link rel="search" href="', $scripturl, '?action=search" />
	<link rel="contents" href="', $scripturl, '" />';

	// If RSS feeds are enabled, advertise the presence of one.
	if (!empty($modSettings['xmlnews_enable']) && (!empty($modSettings['allow_guestAccess']) || $context['user']['is_logged']))
		echo '
	<link rel="alternate" type="application/rss+xml" title="', $context['forum_name_html_safe'], ' - ', $txt['rss'], '" href="', $scripturl, '?type=rss;action=.xml" />';

	// If we're viewing a topic, these should be the previous and next topics, respectively.
	if (!empty($context['current_topic']))
		echo '
	<link rel="prev" href="', $scripturl, '?topic=', $context['current_topic'], '.0;prev_next=prev" />
	<link rel="next" href="', $scripturl, '?topic=', $context['current_topic'], '.0;prev_next=next" />';

	// If we're in a board, or a topic for that matter, the index will be the board's index.
	if (!empty($context['current_board']))
		echo '
	<link rel="index" href="', $scripturl, '?board=', $context['current_board'], '.0" />';

	// Output any remaining HTML headers. (from mods, maybe?)
	echo $context['html_headers'];

	echo '
</head>
<body>';
}

function template_body_above()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

echo '
	<div id="main" style="opacity: 1;">
	<header class="header_a">
		<div class="container">
			<div class="row">
				<div class="col-8 col-md-10 col-lg-9 col-xl-10">
					<div class="header__content">
						<!-- header menu btn -->
						<button class="header__btn" type="button">
							<span></span>
							<span></span>
							<span></span>
						</button>
						<!-- end header menu btn -->

						<!-- header logo -->
						<a class="header__logo" title="' . $context['forum_name'] . '" href="'.$scripturl.'">
						<img src="' . $settings['images_url'] . '/custom/logo.png" alt="' . $context['forum_name'] . '" title="' . $context['forum_name'] . '" />
						</a>
						<!-- end header logo -->

						<!-- header nav -->
						', template_menu(), '
						<!-- end header nav -->
						<form action="', $scripturl, '?action=search2" method="post" accept-charset="', $context['character_set'], '" class="header__search">
						<input class="header__search-input" type="text" name="search" value="', $txt['forum_search'], '" onfocus="this.value = \'\';" onblur="if(this.value==\'\') this.value=\'', $txt['forum_search'], '\';" />
						<button class="header__search-button" type="submit" name="submit">
            <svg id="svg-magnifying-glass" class="interactive-input-icon icon-magnifying-glass" viewBox="0 0 20 20" preserveAspectRatio="xMinYMin meet">
      <path d="M8,2c3.309,0,6,2.691,6,6s-2.691,6-6,6s-6-2.691-6-6S4.691,2,8,2 M8,0C3.582,0,0,3.582,0,8c0,4.418,3.582,8,8,8c4.418,0,8-3.582,8-8C16,3.582,12.418,0,8,0L8,0z"></path>
      <path d="M19.171,15.168l-3.134-3.134c-0.309,0.613-0.679,1.19-1.113,1.714l2.833,2.834c0.323,0.324,0.323,0.851,0,1.175C17.545,17.969,17.298,18,17.17,18c-0.129,0-0.376-0.031-0.588-0.243l-2.834-2.833c-0.523,0.435-1.101,0.805-1.714,1.113l3.134,3.134C15.721,19.724,16.445,20,17.169,20c0.725,0,1.449-0.276,2.002-0.829C20.276,18.065,20.276,16.273,19.171,15.168z"></path>
    </svg>
							</button>';

					// Search within current topic?
					if (!empty($context['current_topic']))
					echo '
						<input type="hidden" name="topic" value="', $context['current_topic'], '" />';

					// If we're on a certain board, limit it to this board ;).
					elseif (!empty($context['current_board']))
					echo '
						<input type="hidden" name="brd[', $context['current_board'], ']" value="', $context['current_board'], '" />';

				echo '
					</form>
					</div>
				</div>

				<div class="col-4 col-md-2 col-lg-3 col-xl-2">
					<div class="header__content header__content--end">

						<div class="header__profile">';

				if ($context['user']['is_logged'])
				{
				echo '
							<a class="dropdown-toggle header__profile-btn" href="#" role="button" id="dropdownMenuProfile" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">';
		if (!empty($context['user']['avatar']))
			echo '<img class="av rounded-circle" src="', $context['user']['avatar']['href'], '" alt="*"/>';
		else
			echo '<img class="av rounded-circle"  src="'.$settings['images_url'].'/noavatar.png" alt="*"/>';
		echo '
			
			<span class="user-name d-none d-sm-block float-right">', $context['user']['name'], ($context['user']['unread_messages'] == 0) ? '' : ' <span class="label label-primary visible-xs-inline">' . $context['user']['unread_messages'] . '</span>', ' <span class="caret"></span>
			</span></a>';
					
					echo '

							<ul class="dropdown-menu dropdown-menu-right header__dropdown-menu header__dropdown-menu--right" aria-labelledby="dropdownMenuProfile">
								<li><a class="dropdown-item" href="', $scripturl, '?action=profile">', $txt['summary'], '</a></li>
								<li><a class="dropdown-item" href="', $scripturl, '?action=profile;area=forumprofile">', $txt['forumprofile'], '</a></li>
								<li><a class="dropdown-item" href="', $scripturl, '?action=profile;area=account">', $txt['account'], '</a></li>
								<li><a class="dropdown-item" href="', $scripturl, '?action=unread">', $txt['unread_topics_visit'], '</a></li>
								<li><a class="dropdown-item" href="', $scripturl, '?action=unreadreplies">', $txt['unread_replies'], '</a></li>
								<li class="dropdown-divider"></li>';
		                         echo '
								<li><a class="dropdown-item" href="', $scripturl, '?action=logout;' . $context['session_var'] . '=' . $context['session_id']. '">', $txt['logout'], '</a></li>
							</ul>';
	}
	// Otherwise they're a guest - this time ask them to either register or login - lazy bums...
	elseif (!empty($context['show_login_bar']))
	{
		echo '
		<ul class="top-header-nav">
						<li class="btn-login"><a class="user-panel__item" href="', $scripturl, '?action=login"><i class="fa fa-lock" aria-hidden="true"></i><span class="hidden">',$txt['login'],'</span></a></li>
						<li class="btn-register"><a class="user-panel__item" href="', $scripturl, '?action=register"><i class="fa fa-user-plus" aria-hidden="true"></i><span class="hidden">',$txt['register'],'</span></a></li>
					</ul>';
				}
			echo '
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>';
		 echo '
		<div id="wrapper">
                <!-- content-->
                <div class="contentt">
                    <!--  section  -->
		  <section class="parallax-section single-par" data-scrollax-parent="true">
		  <div class="bg par-elem"></div>
                        <div class="overlay op7"></div>
			<div class="container">
				<div class="p-guest--message">
			<div class="p-guest--message--inner">
				<h1>', $txt['hello_member_ndt'], ' </h1>
				<span class="section-separator"></span>';
				if ($context['user']['is_logged'])
									echo '
				<span>', $context['user']['name'], '</span>';

				if ($context['user']['is_guest'])
			{
				echo '
				<p>', sprintf($txt['welcome_guest'], $txt['guest_title']), '</p>';
            }
              echo '
			</div>
		</div>
				</div>
			<div class="header-sec-link">
                            <a href="#bot" id="scrlBotm" class="custom-scroll-link"><i class="fas fa-angle-double-down"></i></a> 
                        </div>
		 </section>';
		 echo '
	<section class="gray-bg no-top-padding-sec" id="sec1">
                        <div class="container">
	<div class="breadcrumbs inline-breadcrumbs fl-wrap block-breadcrumbs">
			', theme_linktree(), '
			<ul class="p-nav-opposite">
				<li class="custom-control custom-switch">
            <input type="checkbox" class="custom-control-input" id="darkSwitch">
            <label class="custom-control-label" for="darkSwitch"></label>
          </li>
        </ul>
	</div>
			<div id="board-notice">';
	
			// Is the forum in maintenance mode?
			if ($context['in_maintenance'] && $context['user']['is_admin'])
			echo '
				<strong>', $txt['maintenance'], '</strong>';
	
			// Are there any members waiting for approval?
			if (!empty($context['unapproved_members']))
			echo '
				<a href="', $scripturl, '?action=admin;area=viewmembers;sa=browse;type=approve">', $txt['approval_member'], ': <span>', $context['unapproved_members'] , '</span></a>';
	
			if (!empty($context['open_mod_reports']) && $context['show_open_reports'])
			echo '
				<a href="', $scripturl, '?action=moderate;area=reports">', $txt['open_reports'], ': <span>', $context['open_mod_reports'], '</span></a>';
			
		echo '
			</div>';

}

function template_body_below()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

	echo '
	</div>
   </section>
   <div class="limit-box fl-wrap"></div>
</div>
	</div>';

// Show the "Powered by" and "Valid" logos, as well as the copyright. Remember, the copyright must be somewhere!
echo '
	<footer class="main-footer fl-wrap">
		<div class="container">		
					',theme_copyright(),' | ' , $txt['wt_copyright'], '
		</div>
	</footer></div>
	<a href="#" class="to-top backtop"><i class="fas fa-caret-up"></i></a>';
}

function template_html_below()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

	echo '
</body></html>';
}

// Show a linktree. This is that thing that shows "My Community | General Category | General Discussion"..
function theme_linktree($force_show = false)
{
	global $context, $settings, $options, $shown_linktree;

	// If linktree is empty, just return - also allow an override.
	if (empty($context['linktree']) || (!empty($context['dont_default_linktree']) && !$force_show))
		return;

	echo '
	<div class="navigate_section">
		<ul>';

	// Each tree item has a URL and name. Some may have extra_before and extra_after.
	foreach ($context['linktree'] as $link_num => $tree)
	{
		echo '
			<li', ($link_num == count($context['linktree']) - 1) ? ' class="last"' : '', '>';

		// Show something before the link?
		if (isset($tree['extra_before']))
			echo $tree['extra_before'];

		// Show the link, including a URL if it should have one.
		echo $settings['linktree_link'] && isset($tree['url']) ? '
				<a href="' . $tree['url'] . '"><span>' . $tree['name'] . '</span></a>' : '<span>' . $tree['name'] . '</span>';

		// Show something after the link...?
		if (isset($tree['extra_after']))
			echo $tree['extra_after'];

		echo '
			</li>';
	}
	echo '
		</ul>
	</div>';

	$shown_linktree = true;
}

// Show the menu up top. Something like [home] [help] [profile] [logout]...
function template_menu()
{
	global $context, $settings, $options, $scripturl, $txt;

	echo '
		<ul id="topnav" class="header__nav">';

	foreach ($context['menu_buttons'] as $act => $button)
	{
		echo '
				<li id="button_', $act, '">
					<a class="', $button['active_button'] ? 'active ' : '', 'firstlevel" href="', $button['href'], '"', isset($button['target']) ? ' target="' . $button['target'] . '"' : '', '>
						<i class="fa fa-', $act, ' fa-lg"></i><span class="', isset($button['is_last']) ? 'last ' : '', 'firstlevel">', $button['title'], '</span>
					</a>';
		if (!empty($button['sub_buttons']))
		{
			echo '
					<ul>';

			foreach ($button['sub_buttons'] as $childbutton)
			{
				echo '
						<li>
							<a href="', $childbutton['href'], '"', isset($childbutton['target']) ? ' target="' . $childbutton['target'] . '"' : '', '>
								<span', isset($childbutton['is_last']) ? ' class="last"' : '', '>', $childbutton['title'], !empty($childbutton['sub_buttons']) ? '...' : '', '</span>
							</a>';
				// 3rd level menus :)
				if (!empty($childbutton['sub_buttons']))
				{
					echo '
							<ul>';

					foreach ($childbutton['sub_buttons'] as $grandchildbutton)
						echo '
								<li>
									<a href="', $grandchildbutton['href'], '"', isset($grandchildbutton['target']) ? ' target="' . $grandchildbutton['target'] . '"' : '', '>
										<span', isset($grandchildbutton['is_last']) ? ' class="last"' : '', '>', $grandchildbutton['title'], '</span>
									</a>
								</li>';

					echo '
							</ul>';
				}

				echo '
						</li>';
			}
				echo '
					</ul>';
		}
		echo '
				</li>';
	}

	echo '
			</ul>';
}

// Generate a strip of buttons.
function template_button_strip($button_strip, $direction = 'top', $strip_options = array())
{
	global $settings, $context, $txt, $scripturl;

	if (!is_array($strip_options))
		$strip_options = array();

	// List the buttons in reverse order for RTL languages.
	if ($context['right_to_left'])
		$button_strip = array_reverse($button_strip, true);

	// Create the buttons...
	$buttons = array();
	foreach ($button_strip as $key => $value)
	{
		if (!isset($value['test']) || !empty($context[$value['test']]))
			$buttons[] = '
				<li><a' . (isset($value['id']) ? ' id="button_strip_' . $value['id'] . '"' : '') . ' class="button_strip_' . $key . (isset($value['active']) ? ' active' : '') . '" href="' . $value['url'] . '"' . (isset($value['custom']) ? ' ' . $value['custom'] : '') . '><i class="fa fa-'.$value['text'].' fa-fw"></i>&nbsp; <span class="d-none d-sm-block float-right">' . $txt[$value['text']] . '</span></a></li>';
	}

	// No buttons? No button strip either.
	if (empty($buttons))
		return;

	// Make the last one, as easy as possible.
	$buttons[count($buttons) - 1] = str_replace('<span>', '<span class="last">', $buttons[count($buttons) - 1]);

	echo '
		<div class="buttonlist', !empty($direction) ? ' float' . $direction : '', '"', (empty($buttons) ? ' style="display: none;"' : ''), (!empty($strip_options['id']) ? ' id="' . $strip_options['id'] . '"': ''), '>
			<ul class="nav nav-pills">',
				implode('', $buttons), '
			</ul>
		</div>';
}

?>