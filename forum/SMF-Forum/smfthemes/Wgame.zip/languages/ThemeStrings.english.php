<?php
// Version: 2.0; Themes

global $scripturl;

$txt['maintenance'] = 'Site in Maintenance!';
$txt['approval_member'] = 'Member Approvals';
$txt['open_reports'] = 'Open Reports';
$txt['forum_search'] = 'Search...';
$txt['wt_copyright'] = '<span>Design by <a href="https://webtiryaki.com" target="_blank">webtiryaki</a></span>';

?>