<?php
// Version: 2.0 GOLD; ThemeStrings.language.php

// Vertex text file because we cant have hard coded text...


$txt['social_icons_present'] = 'Social Icons Present';
$txt['social_icons_present_description'] = 'Social Icons(Facebook and Twitter) Present on Top Bar';

$txt['social_icon_facebook_text'] = 'Facebook URL';
$txt['social_icon_twitter_text'] = 'Twitter URL';

$txt['mlm_copyright'] = 'Theme by MLM from VisualPulse.net';

$txt['bar_symbol'] = '|';
$txt['vp_help'] = 'Hello';
$txt['view_inbox'] = 'View Inbox';
$txt['vp_welcome_guest'] = 'Welcome, Guest. Please';
$txt['vp_login'] = 'login';
$txt['vp_register'] = 'register';
$txt['vp_or'] = 'or';


?>