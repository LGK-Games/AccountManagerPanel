<?php

$txt['mb_title'] = 'Lesezeichen erstellen';
$txt['mb_subject'] = 'Name des Lesezeichens';
$txt['mb_note'] = 'Notiz (optional)';
$txt['mb_popup_bookmarks'] = 'Meine Lesezeichen';
$txt['mb_show_bookmarks'] = 'Zeigt eine Liste mit deinen Beitragslesezeichen an';
$txt['mb_settings'] = 'Beitragslesezeichen';
$txt['mb_mod_desc'] = 'Hier kannst du die Einstellungen für die "Message Bookmarks" Mod ändern.';

$txt['mb_ignore_boards'] = 'Boards, in denen keine Lesezeichen gesetzt werden dürfen';
$txt['mb_ignored_boards_desc'] = 'Wähle die Boards aus, in denen keine Lesezeichen gesetzt werden dürfen';
$txt['mb_class'] = 'CSS Klasse für die Hervorhebung der Beiträge mit einem Lesezeichen';
$txt['mb_add_icon'] = 'Icon zum Hinzufügen eines Lesezeichens';
$txt['mb_del_icon'] = 'Icon zum Löschen eines Lesezeichens';
$txt['mb_icon_subtext'] = 'Du kannst Emojis oder FA Code verwenden wie z.B. <i>fas fa-bookmark</i>';
$txt['mb_show_top_messages_stats'] = 'Häufig gesetzte Lesezeichen in den Statistiken anzeigen';
$txt['mb_show_top_messages_count'] = 'Benötigte Beiträge des Mitglieds zur Anzeige in den Statistiken';
$txt['mb_show_top_members_stats'] = 'Mitglieder mit den meisten Lesezeichen anzeigen';
$txt['mb_show_top_members_count'] = 'Mindestanzahl der Lesezeichen, damit ein Mitglied in der Statistik angezeigt wird';

$txt['permissiongroup_message_bookmarks'] = $txt['permissiongroup_simple_message_bookmarks'] = 'Beitragslesezeichen';
$txt['permissionname_use_message_bookmarks'] = $txt['group_perms_name_use_message_bookmarks'] = 'Using bookmarks';
$txt['permissionhelp_use_message_bookmarks'] = 'Mit dieser Berechtigung können Benutzer Beitragslesezeichen direkt in den Beiträgen setzen oder entfernen.
Ebenfalls können Beitragslesezeichen in einer Liste im Profil angeschaut, bearbeitet oder gelöscht werden.';
$txt['groups_use_message_bookmarks'] = 'Erlaubte Mitgliedergruppen';
$txt['cannot_use_message_bookmarks'] = 'Leider hast du zum Setzen von Beitragslesezeichen keine Berechtigung.';

$txt['mb_profile_title'] = $txt['permissiongroup_message_bookmarks'];
$txt['mb_profile_desc'] = 'Eine Liste mit deinen gesetzten Lesezeichen.';
$txt['mb_no_items'] = 'Du hast noch keine Lesezeichen gesetzt.';

$txt['mb_add_bookmark'] = 'Lesezeichen setzen';
$txt['mb_remove_bookmark'] = 'Lesezeichen löschen';

$txt['top_replies'] = 'Top Beiträge mit Beitragslesezeichen';
$txt['top_members'] = 'Benutzer mit den meisten Beitragslesezeichen';
