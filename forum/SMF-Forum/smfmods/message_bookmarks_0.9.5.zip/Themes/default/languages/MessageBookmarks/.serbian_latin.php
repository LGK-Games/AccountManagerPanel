<?php

$txt['mb_title'] = 'Obeležavanje poruke';
$txt['mb_subject'] = 'Ime obeležene poruke';
$txt['mb_note'] = 'Napomena (opciono)';
$txt['mb_popup_bookmarks'] = 'Moje obeležene poruke';
$txt['mb_show_bookmarks'] = 'Prikaži obeleživače poruka';
$txt['mb_settings'] = 'Obeleživači poruka';
$txt['mb_mod_desc'] = 'Ovde možete promeniti podešavanja moda obeleživača poruka.';

$txt['mb_ignore_boards'] = 'Zanemareni forumi';
$txt['mb_ignored_boards_desc'] = 'Izaberite forume na kojima obeleživač poruka neće raditi';
$txt['mb_class'] = 'Klasa za isticanje obeleženih poruka u temama';
$txt['mb_add_icon'] = 'Icon of adding a bookmark';
$txt['mb_del_icon'] = 'Icon of deleting a bookmark';
$txt['mb_icon_subtext'] = 'You can use emoji or FA code like <i>fas fa-bookmark</i>';
$txt['mb_show_top_messages_stats'] = 'Show frequently bookmarked posts';
$txt['mb_show_top_messages_count'] = 'Minimum number of posts to display in the top';
$txt['mb_show_top_members_stats'] = 'Show members with the most bookmarks';
$txt['mb_show_top_members_count'] = 'Minimum number of bookmarks members have to display in the top';

$txt['permissiongroup_message_bookmarks'] = $txt['permissiongroup_simple_message_bookmarks'] = 'Obeleživači poruka';
$txt['permissionname_use_message_bookmarks'] = $txt['group_perms_name_use_message_bookmarks'] = 'Using bookmarks';
$txt['permissionhelp_use_message_bookmarks'] = 'Sa ovom dozvolom korisnici će moći da pregledaju, dodaju i uklanjaju obeleživače poruka.';
$txt['groups_use_message_bookmarks'] = 'Dozvole za korišćenje obeleživača poruka';
$txt['cannot_use_message_bookmarks'] = 'Nažalost, nemate pravo da obeležavate poruke.';

$txt['mb_profile_title'] = $txt['permissiongroup_message_bookmarks'];
$txt['mb_profile_desc'] = 'Ovde možete da vidite svoje obeležene poruke.';
$txt['mb_no_items'] = 'Još uvek nema sačuvanih poruka.';

$txt['mb_add_bookmark'] = 'Sačuvaj poruku';
$txt['mb_remove_bookmark'] = 'Ukloni poruku iz sačuvanih';

$txt['top_replies'] = 'Most frequently bookmarked posts';
$txt['top_members'] = 'Users with the most bookmarks';
