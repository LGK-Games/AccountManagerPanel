<?php

$txt['mb_title'] = 'Δημιουργία σελιδοδείκτη';
$txt['mb_subject'] = 'Όνομα σελιδοδείκτη';
$txt['mb_note'] = 'Σημείωση (προαιρετικό)';
$txt['mb_popup_bookmarks'] = 'Οι σελιδοδείκτες μου';
$txt['mb_show_bookmarks'] = 'Εμφάνιση  μηνυμάτων σελιδοδεικτών';
$txt['mb_settings'] = 'Σελιδοδείκτες μηνυμάτων';
$txt['mb_mod_desc'] = 'Εδώ μπορείτε να αλλάξετε τις ρυθμίσεις του mod Message Bookmarks.';

$txt['mb_ignore_boards'] = 'Αγνοημένοι πίνακες';
$txt['mb_ignored_boards_desc'] = 'Επιλέξτε τους πίνακες στους οποίους ΔΕΝ πρέπει να λειτουργούν οι σελιδοδείκτες μηνυμάτων';
$txt['mb_class'] = 'Ένας ορισμός για την επισήμανση αναρτήσεων με σελιδοδείκτες σε θέματα';
$txt['mb_add_icon'] = 'Εικονίδιο προσθήκης σελιδοδείκτη';
$txt['mb_del_icon'] = 'Εικονίδιο διαγραφής σελιδοδείκτη';
$txt['mb_icon_subtext'] = 'Μπορείτε να χρησιμοποιήσετε emoji ή κωδικό FA όπως <i>fas fa-bookmark</i>';
$txt['mb_show_top_messages_stats'] = 'Εμφάνιση αναρτήσεων με συχνούς σελιδοδείκτες';
$txt['mb_show_top_messages_count'] = 'Ελάχιστος αριθμός αναρτήσεων για εμφάνιση στην κορυφή';
$txt['mb_show_top_members_stats'] = 'Εμφάνιση μελών με τους περισσότερους σελιδοδείκτες';
$txt['mb_show_top_members_count'] = 'Ελάχιστος αριθμός σελιδοδεικτών που πρέπει να εμφανίζονται για τα μέλη στην κορυφή';

$txt['permissiongroup_message_bookmarks'] = $txt['permissiongroup_simple_message_bookmarks'] = 'Σελιδοδείκτες μηνυμάτων';
$txt['permissionname_use_message_bookmarks'] = $txt['group_perms_name_use_message_bookmarks'] = 'Χρήση σελιδοδεικτών';
$txt['permissionhelp_use_message_bookmarks'] = 'Με αυτήν την άδεια οι χρήστες θα μπορούν να προβάλλουν, να προσθέτουν και να αφαιρούν σελιδοδείκτες μηνυμάτων.';
$txt['groups_use_message_bookmarks'] = 'Άδειες χρήσης σελιδοδεικτών μηνυμάτων';
$txt['cannot_use_message_bookmarks'] = 'Δυστυχώς, δεν έχετε δικαίωμα να δημιουργήσετε σελιδοδείκτες μηνυμάτων.';

$txt['mb_profile_title'] = $txt['permissiongroup_message_bookmarks'];
$txt['mb_profile_desc'] = 'Μπορείτε να δείτε τους σελιδοδείκτες σας εδώ.';
$txt['mb_no_items'] = 'Δεν υπάρχουν ακόμα σελιδοδείκτες.';

$txt['mb_add_bookmark'] = 'Πρόσθεσε σελιδοδείκτη';
$txt['mb_remove_bookmark'] = 'Αφαίρεση σελιδοδείκτη';

$txt['top_replies'] = 'Οι πιο συχνοί σελιδοδείκτες σε αναρτήσεις';
$txt['top_members'] = 'Χρήστες με τους περισσότερους σελιδοδείκτες';
