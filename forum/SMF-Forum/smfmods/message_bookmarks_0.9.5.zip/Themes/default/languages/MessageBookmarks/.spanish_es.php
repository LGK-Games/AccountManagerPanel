<?php

$txt['mb_title'] = 'Marcador de mensajes';
$txt['mb_subject'] = 'Nombre del marcador';
$txt['mb_note'] = 'Nota (opcional)';
$txt['mb_popup_bookmarks'] = 'Mis marcadores';
$txt['mb_show_bookmarks'] = 'Mostrar marcadores de mensajes';
$txt['mb_settings'] = 'Marcadores de mensajes';
$txt['mb_mod_desc'] = 'Aquí puede cambiar la configuración del mod Marcador de mensajes.';

$txt['mb_ignore_boards'] = 'Foros ignorados';
$txt['mb_ignored_boards_desc'] = 'Seleccione los foros en los que NO deberían funcionar los marcadores de mensajes';
$txt['mb_class'] = 'Una clase para resaltar publicaciones marcadas en temas';
$txt['mb_add_icon'] = 'Icono de agregar un marcador';
$txt['mb_del_icon'] = 'Icono de borrar un marcador';
$txt['mb_icon_subtext'] = 'Puede usar un emoji o código FA como <i>fas fa-bookmark</i>';
$txt['mb_show_top_messages_stats'] = 'Mostrar publicaciones marcadas con frecuencia';
$txt['mb_show_top_messages_count'] = 'Número mínimo de publicaciones para mostrar en la parte superior';
$txt['mb_show_top_members_stats'] = 'Mostrar usuarios con más marcadores';
$txt['mb_show_top_members_count'] = 'Número mínimo de marcadores que los usuarios deben mostrar en la parte superior';

$txt['permissiongroup_message_bookmarks'] = $txt['permissiongroup_simple_message_bookmarks'] = 'Marcadores de mensajes';
$txt['permissionname_use_message_bookmarks'] = $txt['group_perms_name_use_message_bookmarks'] = 'Using bookmarks';
$txt['permissionhelp_use_message_bookmarks'] = 'Con este permiso, los usuarios podrán ver, agregar y eliminar marcadores de mensajes.';
$txt['groups_use_message_bookmarks'] = 'Permisos para usar marcadores de mensajes';
$txt['cannot_use_message_bookmarks'] = 'Lamentablemente, no tiene permiso de crear marcadores de mensajes.';

$txt['mb_profile_title'] = $txt['permissiongroup_message_bookmarks'];
$txt['mb_profile_desc'] = 'Puedes ver tus marcadores aquí.';
$txt['mb_no_items'] = 'No hay marcadores todavía.';

$txt['mb_add_bookmark'] = 'Agregar marcador';
$txt['mb_remove_bookmark'] = 'Borrar marcador';

$txt['top_replies'] = 'Publicaciones marcadas con más frecuencia';
$txt['top_members'] = 'Usuarios con más marcadores';
