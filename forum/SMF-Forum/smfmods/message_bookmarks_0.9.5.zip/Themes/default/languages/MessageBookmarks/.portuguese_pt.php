<?php

$txt['mb_title'] = 'Criar favorito';
$txt['mb_subject'] = 'Nome do favorito';
$txt['mb_note'] = 'Notas (opcional)';
$txt['mb_popup_bookmarks'] = 'Os meus favoritos';
$txt['mb_show_bookmarks'] = 'Mostrar favoritos nas mensagens';
$txt['mb_settings'] = 'Favoritos nas mensagens';
$txt['mb_mod_desc'] = 'Aqui pode mudar as configurações do Mod de favoritos.';

$txt['mb_ignore_boards'] = 'Quadros ignorados';
$txt['mb_ignored_boards_desc'] = 'Selecione os quadros em que os favoritos NÃO devem funcionar';
$txt['mb_class'] = 'Uma classe para sobresair as mensagens favoritas nos tópicos';
$txt['mb_add_icon'] = 'Ícone para adicionar um favorito';
$txt['mb_del_icon'] = 'Ícone para apagar um favorito';
$txt['mb_icon_subtext'] = 'Pode usar um emoji ou código FA como <i>fas fa-bookmark</i>';
$txt['mb_show_top_messages_stats'] = 'Mostrar mensagens frequentemente favoritas';
$txt['mb_show_top_messages_count'] = 'Número mínimo de mensagens para mostrar no topo';
$txt['mb_show_top_members_stats'] = 'Mostrar utilizadores com mais favoritos';
$txt['mb_show_top_members_count'] = 'Número mínimo de favoritos que os membros têm para serem mostrados no topo';

$txt['permissiongroup_message_bookmarks'] = $txt['permissiongroup_simple_message_bookmarks'] = 'Favoritos de mensagens';
$txt['permissionname_use_message_bookmarks'] = $txt['group_perms_name_use_message_bookmarks'] = 'Using bookmarks';
$txt['permissionhelp_use_message_bookmarks'] = 'Com esta permissão, os utilizadores podem ver, adicionar e remover favoritos.';
$txt['groups_use_message_bookmarks'] = 'Permisssões para usar favoritos das mensagens';
$txt['cannot_use_message_bookmarks'] = 'Infelzimente, você não tem direito de usar favoritos.';

$txt['mb_profile_title'] = $txt['permissiongroup_message_bookmarks'];
$txt['mb_profile_desc'] = 'Pode ver os seus favoritos aqui.';
$txt['mb_no_items'] = 'Ainda não há favoritos.';

$txt['mb_add_bookmark'] = 'Adicionar aos favoritos';
$txt['mb_remove_bookmark'] = 'Remover dos favoritos';

$txt['top_replies'] = 'Mensagens mais frequentemnte colocadas nos favoritos';
$txt['top_members'] = 'Utilizadores com mais favoritos';
