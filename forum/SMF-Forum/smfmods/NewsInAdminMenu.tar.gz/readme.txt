[size=x-large][b]News in Admin Menu[/b][/size]

A modification for SMF 2.1 that adds a link to the News and Newsletters section into the admin menu.

There are no settings. Install to enable, uninstall to disable.

[size=large][b]License[/b][/size]

News in Admin Menu is released under the MIT License. A full copy of this license is included in the package file.


[size=large][b]Changelog[/b][/size]

Version 1.0:
[list]
	[li]Initial release[/li]
[/list]