<?php

/*******************************************************************************
 * News in Admin Menu
 *
 * A modification for Simple Machines Forum 2.1 that adds a link to the News and
 * Newsletters section into the Admin dropmenu in the main menu.
 *
 * Copyright (c) 2019 Jon Stovell
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/

if (!defined('SMF'))
	die('No direct access...');

/**
 * Adds the News and Newsletters button to the Admin menu
 * Called by:
 * 		integrate_actions
 */
function news_in_admin_menu(&$buttons)
{
	global $txt, $scripturl;

	loadLanguage('Admin');

	$news_button = array(
		'news' => array(
			'title' => allowedTo('send_mail') ? $txt['news_title'] : $txt['admin_edit_news'],
			'href' => $scripturl . '?action=admin;area=news',
			'show' => allowedTo(array('edit_news', 'send_mail', 'admin_forum')),
		),
	);

	$buttons['admin']['sub_buttons'] = array_merge($news_button, $buttons['admin']['sub_buttons']);
}

/**
 * Mention who made this thing
 * Called by:
 * 		integrate_credits
 */
function news_in_admin_menu_credits()
{
	global $context;
	$context['copyrights']['mods'][] = 'News in Admin Menu by Jon &quot;Sesquipedalian&quot; Stovell &copy; 2019';
}
