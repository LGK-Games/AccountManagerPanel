<?php

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
	die('<b>Error:</b> Cannot update database.');
	
if(!array_key_exists('db_insert', $smcFunc))
	db_extend('packages');
	
$smcFunc['db_insert']('ignore', '{db_prefix}settings',
	array ('variable' => 'string', 'value' => 'string'),
	array ('arrange_mclegend', '1,2,8,7,6,5,4'),
	array()
);

?>