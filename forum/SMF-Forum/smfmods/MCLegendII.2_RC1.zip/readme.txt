[color=blue][b]Author[/b]: JohnyB   [b]Mod Name[/b]: MCLegendIIRC1   [b]Version[/b]: 3.0
[b]Tested[/b]: Freshly installed SMF 2.0 RC1[/color]
[hr]		
[b]MCLegendII[/b]
 - This mod will display the membergroups color legend under the list of online members.
 - The displayed member color legend by default is:
    ~ [Administrator] [Global Moderator] [Hero Member] [Sr. Member] [Full Member] [Jr. Member] [Newbie]
 - Re-arrange the display of groups the way you want it by going to 
    ~ [color=blue]Admin -> Features and options -> Membergroup legend display arrangement.[/color]
 - Separate the arranged group id with comma except for the the last number (i.e. 1,2,8,7,6,5,4).
 - Remove or add group id's from the list to select the groups you want to be displayed.[/li]
 - To enable the display of the membergroup color legend, disable the built-in group key from
    ~ Admin -> Current Theme, under Themes Settings tab, untick "Show group key on board index" checkbox.

[b]Supported Themes[/b]
 - Default Core
 - Babylon
 - Classic
 - ShinyBlue2b3

[b]Supported languages[/b]
 - English
 - Swedish
 - Polish
 - Spanish Latin
 
 