<?php

/*******************************************************************************
 * Quick Reply Attachments Button
 *
 * A modification for SMF 2.1 that adds a button to the quick reply form that
 * makes it easier for users to add attachments. This button is a one-click
 * shortcut that takes the user straight to the attachment upload interface on
 * the full posting form, already open and ready to go.
 *
 * Copyright (c) 2022 Jon Stovell
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/

if (!defined('SMF'))
	die('No direct access...');

/**
 * Adds an attachments button to the quick reply form.
 *
 * Called by:
 * 		integrate_sceditor_options
 */
function quickreplyattachments_sceditor_options(&$sce_options)
{
	global $context, $txt, $modSettings, $board;

	if (!empty($context['controls']['richedit']['quickReply']))
	{
		loadLanguage('Post');

		$context['richedit_buttons'] = array_merge(
			array(
				'attachments' => array(
					'type' => 'submit',
					'value' => $txt['attach_add'],
					'show' => !empty($modSettings['attachmentEnable']) && (allowedTo('post_attachment', $board) || (!empty($modSettings['postmod_active']) && allowedTo('post_unapproved_attachments', $board))),
					'onclick' => 'return submitThisOnce(this);'
				)
			),
			$context['richedit_buttons']
		);
	}
}

/**
 * Adds an attachments button to the quick reply form.
 *
 * Called by:
 * 		integrate_post2_pre
 */
function quickreplyattachments_post2_pre(&$post_errors)
{
	if (isset($_REQUEST['quickReply']) && isset($_REQUEST['attachments']))
	{
		$_REQUEST['preview'] = true;

		$_POST['additional_options'] = true;

		addInlineJavaScript('
			document.getElementById("post_additional_options").scrollIntoView();', true);

		addInlineCss('
			#attachment_upload { border: 3px solid red; }', true);
	}
}

/**
 * Mention who made this thing
 *
 * Called by:
 * 		integrate_credits
 */
function quickreplyattachments_credits()
{
	global $context;

	$context['copyrights']['mods'][] = 'Quick Reply Attachments Button by Jon &quot;Sesquipedalian&quot; Stovell &copy; 2022';
}