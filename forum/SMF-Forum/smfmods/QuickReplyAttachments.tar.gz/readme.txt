[size=x-large][b]Quick Reply Attachments Button[/b][/size]

A modification for SMF 2.1 that adds a button to the quick reply form that makes it easier for users to add attachments. This button is a one-click shortcut that takes the user straight to the attachment upload interface on the full posting form, already open and ready to go.


[size=large][b]Settings[/b][/size]

There are no settings. Install to enable, uninstall to disable.


[size=large][b]License[/b][/size]

Quick Reply Attachments Button, © 2022 Jon Stovell, is released under the MIT License. A full copy of this license is included in the package file.


[size=large][b]Changelog[/b][/size]

Version 1.0:
[list]
	[li]Initial release[/li]
[/list]