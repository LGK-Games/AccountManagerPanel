<?php

$txt['similar_topics'] = 'Tópicos semelhantes';
$txt['simtopics_desc'] = 'Here you can change settings of the Similar Topics mod. You can also buy <a class="bbc_link" href="https://ko-fi.com/dragomano/">a cup of coffee</a> for the developer.';
$txt['simtopics_settings'] = 'Tópicos semelhantes - Configurações';
$txt['simtopics_num_topics'] = 'Máximo de tópicos a mostrar';
$txt['simtopics_nt_desc'] = 'Defina 0 para desligar a modificação.';
$txt['simtopics_only_cur_board'] = 'Procure por tópicos semelhantes apenas no quadro atual';
$txt['simtopics_ocb_desc'] = 'Tire o visto se desejar procurar em todos os quadros.';
$txt['simtopics_when_new_topic'] = 'Mostrar uma lista de tópicos semelhantes quando criar um novo tópico';
$txt['simtopics_when_new_topic_variants'] = array($txt['no'], 'Above a post form', 'Below a post form');
$txt['simtopics_on_display'] = 'Mostrar uma lista de tópicos semelhantes dentro desses tópicos';
$txt['simtopics_position'] = 'Onde mostrar o bloco de tópicos semelhantes';
$txt['simtopics_position_variants'] = array('Acima do tópico', 'abaixo do tópico', 'Above and below a topic');

$txt['simtopics_sorting'] = 'Tipo de ordenação';
$txt['simtopics_sorting_variants'] = array(
    'Por relevancia',
    'Por relevancia (descendente)',
    'Por título',
    'Por título (descendente)',
    'Por data de criação',
    'Por data de criação (descendente)',
    'Pela data da última mensagem',
    'Pela data da última mensagem (descendente)'
);

$txt['simtopics_cache_int'] = 'Intervalo de atualização da Cache';
$txt['simtopics_ci_post'] = 'seg.';
$txt['groups_simtopics_view'] = $txt['group_perms_name_simtopics_view'] = 'Permissões para ver a lista de tópicos semelhantes';
$txt['groups_simtopics_post'] = $txt['group_perms_name_simtopics_post'] = 'Acesso à lista de tópicos semelhantes numa nova mensagem';

$txt['simtopics_ignored_boards'] = 'Quadros ignorados';

$txt['permissiongroup_simtopics'] = $txt['permissiongroup_simple_simtopics'] = $txt['similar_topics'];
$txt['permissionname_simtopics_view'] = 'Ver a lista de tópicos semelhantes';
$txt['permissionhelp_simtopics_view'] = 'Com esta permissão os utilizadores podem ver o bloco de tópicos semelhantes.';
$txt['permissionname_simtopics_post'] = 'Ver a lista de tópicos semelhantes quando cria um novo tópico';
$txt['permissionhelp_simtopics_post'] = 'Quando os utilizadores criam um novo tópico podem ver uma lista de tópicos semelhantes.';

$txt['simtopics_displayed_columns'] = 'Colunas a mostrar';

$txt['simtopics_no_result'] = 'Não existem tópicos semelhantes.';
$txt['simtopics_no_subject'] = 'Digite o assunto, por favor..';
