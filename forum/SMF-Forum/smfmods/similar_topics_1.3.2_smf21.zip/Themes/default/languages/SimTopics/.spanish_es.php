<?php

$txt['similar_topics'] = 'Temas Similares';
$txt['simtopics_desc'] = 'Here you can change settings of the Similar Topics mod. You can also buy <a class="bbc_link" href="https://ko-fi.com/dragomano/">a cup of coffee</a> for the developer.';
$txt['simtopics_settings'] = 'Configuracion temas similares';
$txt['simtopics_num_topics'] = 'Temas máximos para mostrar';
$txt['simtopics_nt_desc'] = '0 para desactivar el mod.';
$txt['simtopics_only_cur_board'] = 'Buscar temas similares solo en el foro actual';
$txt['simtopics_ocb_desc'] = 'Desmarque si desea buscar temas similares en todos los foros.';
$txt['simtopics_when_new_topic'] = 'Mostrar temas similares cuando se esta creando un nuevo tema';
$txt['simtopics_when_new_topic_variants'] = array($txt['no'], 'Above a post form', 'Below a post form');
$txt['simtopics_on_display'] = 'Mostrar una lista de temas similares dentro de estos temas';
$txt['simtopics_position'] = 'Dónde mostrar el bloque de temas similares';
$txt['simtopics_position_variants'] = array('Tema anterior', 'Tema siguiente', 'Above and below a topic');

$txt['simtopics_sorting'] = 'Tipo de clasificación';
$txt['simtopics_sorting_variants'] = array(
    'Por relevancia',
    'Por relevancia (descendente)',
    'Por titulo',
    'Por título (descendente)',
    'Por tiempo de creación',
    'Por tiempo de creación (descendente)',
    'Por hora de la última publicación',
    'Por hora de la última publicación (descendente)'
);

$txt['simtopics_cache_int'] = 'Intervalo de actualizacion de cache';
$txt['simtopics_ci_post'] = 'segundos.';
$txt['groups_simtopics_view'] = $txt['group_perms_name_simtopics_view'] = 'Permisos para ver temas similares';
$txt['groups_simtopics_post'] = $txt['group_perms_name_simtopics_post'] = 'Permisos para ver temas similares en nuevo tema';

$txt['simtopics_ignored_boards'] = 'Foros ignorados';

$txt['permissiongroup_simtopics'] = $txt['permissiongroup_simple_simtopics'] = $txt['similar_topics'];
$txt['permissionname_simtopics_view'] = 'Visualizacion de la lista de temas similares';
$txt['permissionhelp_simtopics_view'] = 'Con este permiso los usuarios pueden ver la lista de temas similares.';
$txt['permissionname_simtopics_post'] = 'Visualizacion de la lista de temas similares al crear nuevo tema';
$txt['permissionhelp_simtopics_post'] = 'Cuando los usuarios estan creando un nuevo tema podran ver una lista de temas similares.';

$txt['simtopics_displayed_columns'] = 'Columnas mostradas';

$txt['simtopics_no_result'] = 'No existen temas similares.';
$txt['simtopics_no_subject'] = 'Escriba un titulo por favor.';
