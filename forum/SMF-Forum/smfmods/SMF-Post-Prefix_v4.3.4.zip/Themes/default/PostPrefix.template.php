<?php

/**
 * @package SMF Post Prefix
 * @version 4.2
 * @author Diego Andrés <diegoandres_cortes@outlook.com>
 * @copyright Copyright (c) 2023, SMF Tricks
 * @license https://www.mozilla.org/en-US/MPL/2.0/
 */

function template_postprefix_filter_above()
{
	global $context, $scripturl, $txt;

	// Prefixes
	echo'
		<div class="cat_bar">
			<h3 class="catbg">
				', $txt['PostPrefix_filter'],'
			</h3>
		</div>
		<div class="windowbg">
			<div class="content">';

		// Show all the prefixes for this board.
		foreach ($context['prefixes']['filter'] as $prefix)
		{
			echo'
				<a href="' . $scripturl . '?board=' . $context['current_board'] . '.0;prefix=' . $prefix['prefix_id'] . '">' . $prefix['real_prefix'] . '</a>,';
		}

			echo '
				<a href="', $scripturl, '?board=', $context['current_board'], '.0;prefix=0">', $txt['PostPrefix_filter_noprefix'], '</a>, 
				<a href="', $scripturl, '?board=', $context['current_board'], '.0">', $txt['PostPrefix_filter_all'], '</a>
			</div>
		</div>';
}

function template_postprefix_filter_below(){}

/**
 * Edit or add a prefix
 */
function template_postprefix()
{
	global $context, $txt, $scripturl;

	echo '
	<div class="windowbg">
		<form name="set_prefix" id="set_prefix" method="post" action="', $scripturl, '?action=admin;area=postprefix;sa=save">
			', isset($_REQUEST['id']) && !empty($context['prefix']['prefix_id']) ? '<input type="hidden" name="id" value="'.$context['prefix']['prefix_id'].'">' : '', '
			<input type="hidden" name="', $context['session_var'], '" value="', $context['session_id'], '">
			<dl class="settings">
				<dt>
					<label for="name">
						<strong>', $txt['PostPrefix_prefix_name'], ':</strong>
					</label>
				</dt>
				<dd>
					<input class="input_text" name="name" id="name" type="text" value="', !empty($context['prefix']['prefix_name']) ? $context['prefix']['prefix_name'] : '', '" style="width: 100%">
				</dd>

				<dt>
					<label for="status">
						<strong>', $txt['PostPrefix_prefix_enable'], ':</strong>
					</label>
				</dt>
				<dd>
					<input class="input_check" type="checkbox" name="status" id="status"', !empty($context['prefix']['prefix_status']) ? ' checked' : '', ' value="1">
				</dd>
			</dl>
			<hr>
			<dl class="settings">
				<dt>
					<label for="usecolor">
						<strong>', $txt['PostPrefix_prefix_color'], ':</strong>
					</label>
				</dt>
				<dd>
					<input class="input_check" type="checkbox" id="usecolor" name="usecolor" value="1"', !empty($context['prefix']['prefix_color']) ? ' checked' : '', ' onclick="document.getElementById(\'color\').style.display = this.checked ? \'block\' : \'none\'; document.getElementById(\'bgcolor1\').style.display = this.checked ? \'block\' : \'none\'; document.getElementById(\'bgcolor2\').style.display = this.checked ? \'block\' : \'none\'; document.getElementById(\'invert1\').style.display = this.checked ? \'block\' : \'none\'; document.getElementById(\'invert2\').style.display = this.checked ? \'block\' : \'none\';"><br>
					<input class="input_text" data-coloris name="color" id="color" type="text" style="', empty($context['prefix']['prefix_color']) ? 'display:none;"' : 'display:block;border-color:'.$context['prefix']['prefix_color'].';" value="'. $context['prefix']['prefix_color'] . '"', '>
				</dd>
				<dt id="bgcolor1"', empty($context['prefix']['prefix_color']) ? 'style="display:none;"' : '', '>
					<label for="bgcolor">
						<strong>', $txt['PostPrefix_use_bgcolor'], ':</strong>
					</label>
				</dt>
				<dd id="bgcolor2"', empty($context['prefix']['prefix_color']) ? 'style="display:none;"' : '', '>
					<input class="input_check" name="bgcolor" id="bgcolor"', !empty($context['prefix']['prefix_bgcolor']) ? ' checked' : '', ' type="checkbox" value="1">
				</dd>
				<dt id="invert1"', empty($context['prefix']['prefix_color']) ? 'style="display:none;"' : '', '>
					<label for="invert">
						<strong>', $txt['PostPrefix_invert_color'], ':</strong>
					</label><br>
					<span class="smalltext">', $txt['PostPrefix_invert_color_desc'], '</span>
				</dt>
				<dd id="invert2"', empty($context['prefix']['prefix_color']) ? 'style="display:none;"' : '', '>
					<input class="input_check" name="invert" id="invert"', !empty($context['prefix']['prefix_invert_color']) ? ' checked' : '', ' type="checkbox" value="1">
				</dd>
				<dt>
					<label for="use_iconClass">
						<strong>', $txt['PostPrefix_use_iconClass'], ':</strong>
					</label>
					<label for="icon_class" id="lab_icon_class"', empty($context['prefix']['prefix_icon_class']) ? 'style="display:none;"' : 'style="display:block;"', '>
						<strong>', $txt['PostPrefix_icon_class'], ':</strong>
					</label>
				</dt>
				<dd>
					<input class="input_check" type="checkbox" id="use_iconClass" name="use_iconClass" value="1"', !empty($context['prefix']['prefix_icon_class']) ? ' checked' : '', ' onclick="document.getElementById(\'icon_class\').style.display = this.checked ? \'block\' : \'none\'; document.getElementById(\'lab_icon_class\').style.display = this.checked ? \'block\' : \'none\';">
					<input class="input_text" name="icon_class" id="icon_class" type="text" style="width:25ch;', empty($context['prefix']['prefix_icon_class']) ? 'display:none;' : 'display:block;', '" value="', !empty($context['prefix']['prefix_icon_class']) ? $context['prefix']['prefix_icon_class'] : '', '" />
				</dd>
			</dl>
			<hr>
			<dl class="settings">
				<dt>
					<label for="groups">
						<strong>', $txt['PostPrefix_prefix_groups'], ':</strong>
					</label></span><br>
					<span class="smalltext">', $txt['PostPrefix_prefix_groups_desc'], '</span>
				</dt>
				<dd>
					', groups_list(), '
				</dd>
				<dt>
					<label for="boards">
						<strong>', $txt['PostPrefix_prefix_boards'], ':</strong>
					</label><br>
					<span class="smalltext">', $txt['PostPrefix_prefix_boards_desc'], '</span>
				</dt>
				<dd>
					', boards_list(), '
				</dd>
			</dl>
			<input class="button" type="submit" value="', $txt['PostPrefix_save_prefix'], '">
		</form>
	</div>';
}

/**
 * The template for determining which groups can access a board.
 * 
 * @author Simple Machines https://www.simplemachines.org
 * @copyright 2020 Simple Machines and individual contributors
 */

function groups_list()
{
	global $context, $txt;

	echo '
				<fieldset id="visible_groups">
					<legend>', $txt['PostPrefix_prefix_groups'], '</legend>
					<ul class="padding floatleft">';

	// List all the membergroups so the user can choose who may access this board.
	foreach ($context['forum_groups'] as $group)
	{
		$group['allow'] = in_array($group['id_group'], $context['prefix']['groups']) ? true : false;
			
		echo '
						<li class="group">
							<input type="checkbox" name="groups[', $group['id_group'], ']" value="', $group['id_group'], '" id="groups_', $group['id_group'], '"', $group['allow'] ? ' checked' : '', '> <label for="groups_', $group['id_group'], '">', $group['group_name'], '</label>
						</li>';
	}
				echo '
					</ul>
					<br class="clear">
					<input type="checkbox" id="checkall_groups" onclick="invertAll(this, this.form, \'groups\');">
					<label for="checkall_groups"><em>', $txt['check_all'], '</em></label>
				</fieldset>
				<a href="javascript:void(0);" onclick="document.getElementById(\'visible_groups\').classList.remove(\'hidden\'); document.getElementById(\'visible_groups_link\').classList.add(\'hidden\'); return false;" id="visible_groups_link" class="hidden">[ ', $txt['PostPrefix_select_visible_groups'], ' ]</a>
				<script>
					document.getElementById("visible_groups_link").classList.remove(\'hidden\');
					document.getElementById("visible_groups").classList.add(\'hidden\');
				</script>';
}

/**
 * The template for determining which boards a group has access to.
 * 
 * @author Simple Machines https://www.simplemachines.org
 * @copyright 2020 Simple Machines and individual contributors
 * @param bool $collapse Whether to collapse the list by default
 */
function boards_list($collapse = true, $form_id = 'set_prefix')
{
	global $context, $txt;

	echo '
							<fieldset id="visible_boards">
								<legend>', $txt['PostPrefix_prefix_boards'], '</legend>
								<ul class="padding floatleft">';

	foreach ($context['forum_categories'] as $category)
	{
		echo '
									<li class="category">
										<a href="javascript:void(0);" onclick="selectBoards([', implode(', ', $category['child_ids']), '], \''.$form_id.'\'); return false;"><strong>', $category['cat_name'], '</strong></a>
										<ul>';

		foreach ($category['boards'] as $board)
		{
			$board['allow'] = in_array($board['id_board'], $context['prefix']['boards']) ? true : false;
			$board['deny'] = false;

			echo '
											<li class="board" style="margin-', $context['right_to_left'] ? 'right' : 'left', ': ', $board['child_level'], 'em;">
												<input type="checkbox" name="boardset[', $board['id_board'], ']" id="brd', $board['id_board'], '" value="', $board['id_board'], '"', $board['allow'] ? ' checked' : '', '> <label for="brd', $board['id_board'], '">', $board['name'], '</label>
											</li>';
		}
		echo '
										</ul>
									</li>';
	}
	echo '
								</ul>
								<br class="clear">
								<input type="checkbox" id="checkall_boards" onclick="invertAll(this, this.form, \'boardset\');">
								<label for="checkall_boards"><em>', $txt['check_all'], '</em></label>
							</fieldset>';

	if ($collapse)
		echo '
							<a href="javascript:void(0);" onclick="document.getElementById(\'visible_boards\').classList.remove(\'hidden\'); document.getElementById(\'visible_boards_link\').classList.add(\'hidden\'); return false;" id="visible_boards_link" class="hidden">[ ', $txt['PostPrefix_select_visible_boards'], ' ]</a>
							<script>
								document.getElementById("visible_boards_link").classList.remove(\'hidden\');
								document.getElementById("visible_boards").classList.add(\'hidden\');
							</script>';
}

function template_postprefix_show_above()
{
	global $context, $modSettings, $settings, $txt;

	echo '
	<!DOCTYPE html>
	<html', $context['right_to_left'] ? ' dir="rtl"' : '', !empty($txt['lang_locale']) ? ' lang="' . str_replace("_", "-", substr($txt['lang_locale'], 0, strcspn($txt['lang_locale'], "."))) . '"' : '', '>
		<head>
			<meta charset="', $context['character_set'], '">
			<meta name="robots" content="noindex">
			<title>', $context['page_title'], '</title>
			<link rel="stylesheet" type="text/css" href="', $settings['theme_url'], '/css/index', $context['theme_variant'], '.css', $modSettings['browser_cache'] ,'">
			<script src="', $settings['default_theme_url'], '/scripts/script.js', $modSettings['browser_cache'] ,'"></script>
		</head>';
}

function template_postprefix_show()
{
	global $context, $txt;

	echo '
		<body id="postprefix_show' . $context['prefix']['show'] . '_popup">
			<div class="cat_bar">
				<h3 class="catbg">
					', $txt['PostPrefix_prefix_' . $context['prefix']['show']], '
				</h3>
			</div>
			<div class="windowbg">';

		// Nothing?
		if (empty($context['prefix']['get_type']))
		{
			echo '
				<div class="roundframe">
					', $txt['PostPrefix_empty_' . $context['prefix']['show']], '
				</div>';
		}

		// Show the boards or groups
		else
		{
			echo '
				<ul>';

			// Loop through the items
			foreach($context['prefix']['get_type'] as $type)
			{
				echo '
					<li', isset($type['cat_order']) ? '' : ' class="windowbg"' , '>
						<div', isset($type['cat_order']) ? ' class="cat_bar"' : '' , '>
							<h3', isset($type['cat_order']) ? ' class="catbg"' : ' style="font-weight:normal;', !empty($type['online_color']) ? 'color:' . $type['online_color'] . ';"' : '"', '>
								', $type['cat_name'], '
							</h3>
						</div>';

				// Boards?
				if (!empty($type['boards']))
				{
					echo '
						<ul>';

					foreach ($type['boards'] as $board)
					{
						echo '
								<li class="windowbg board" style="margin-', $context['right_to_left'] ? 'right' : 'left', ': ', $board['child_level'], 'em; margin-block: 5px">
									', $board['name'], '
								</li>';
					}
					echo '
							</ul>';
				}
				echo '
					</li>';
			}
			echo '
				</ul>';
		}
			echo '
				<br class="clear">
				<a href="javascript:self.close();">', $txt['close_window'], '</a>
			</div>';
}

function template_postprefix_show_below()
{
	echo '
		</body>
	</html>';
}

function template_postprefix_board_group_list_above()
{
}

function template_postprefix_board_group_list_below(bool $groups = true)
{
	global $context, $txt;

	$prefix_list = '';

	// For groups
	if (!empty($groups))
	{
		$prefix_list .= '
		<div class="cat_bar">
			<h3 class="catbg">' . $txt['PostPrefix_tab_prefixes'] . '</h3>
		</div>
		<div class="windowbg">
			<dl class="settings">
				<dt>
					<strong>' . $txt['PostPrefix_prefix_selection_prefixes'] . '</strong><br><span class="smalltext">' . $txt['PostPrefix_prefix_selection_prefixes_desc'] . '</span>
				</dt>
				<dd>';
	}

	// Prefixes
	$prefix_list .= '
					<details id="prefixes_list_selection">
						<summary style="cursor: pointer;">' . $txt['permissionname_postprefix_manage'] . '</summary>';

	foreach ($context['PostPrefix_prefixes_selection'] as $id => $prefix)
	{
		$prefix_list .= '
						<input' . (!empty($context['prefixes_form']) ? ' form="' . $context['prefixes_form'] . '"' : '') . ' type="checkbox" name="postprefixSelect[' . $id . ']" id="postprefixSelect_' . $id . '" value="' . $id . '"' . (!empty($prefix['active']) ? ' checked' : '') . ' />
						<label for="postprefixSelect_' . $id .'">' . $prefix['name'] . '</label><br>';
	}

	$prefix_list .= '
						<input type="checkbox" id="checkall_prefixes" onclick="togglePrefixes();">
						<label for="checkall_prefixes"><em>' . $txt['check_all'] . '</em></label>
					</details>';

	// Groups
	if (!empty($groups))
	{
		$prefix_list .= '
				</dd>
			</dl><br>
		</div>';

		echo $prefix_list;
	}
	else
		return $prefix_list;
}