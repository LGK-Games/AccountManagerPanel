[b] This is Green smiley set for SMF 2.1.4 users.

This Smileyes made by [url=https://visualpharm.com]Visualpharm[/url] which is under license [url=https://creativecommons.org/licenses/by-nd/3.0/]Creative Commons Attribution-No Derivative Works 3.0 Unported License[/url]

Also check [url=https://www.iconarchive.com/show/green-emo-icons-by-visualpharm/angel-icon.html]Iconarchive[/url][/b]