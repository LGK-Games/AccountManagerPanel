<?php

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif(!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify that you put this file in the same place as SMF\'s index.php and SSI.php files.');

if ((SMF == 'SSI') && !$user_info['is_admin'])
	die('Admin privileges required.');

global $modSettings;

$smiley_sets_known = $modSettings['smiley_sets_known'] . ',green';

$temp = explode(PHP_EOL, $modSettings['smiley_sets_names']);
$temp[] = 'Green';
$temp = implode(PHP_EOL, $temp);
$smiley_sets_names = $temp;

updateSettings(
	array(
		'smiley_sets_known'   => $smiley_sets_known,
		'smiley_sets_names'   => $smiley_sets_names,
		'smiley_sets_default' => 'green'
	)
);

$smileys = [
	'Angel',
	'Wink',
	'Batman',
	'Clown',
	'Angry',
	'Sad',
	'Crying',
	'Cool',
	'Devil',
	'Displeased',
	'Happy',
	'Harrypotter',
	'Hypnotize',
	'Hyponotized',
	'Inlove',
	'Kiss',
	'Kissed',
	'Laughtingoutloud',
	'Money',
	'Party',
	'Pirate',
	'Question',
	'Sleeping',
	'Surprized',
	'Terminator',
	'Tongue',
	'Vomited',
	'Watermelon'
];

$sql = "INSERT INTO {db_prefix}smiley_files (`id_smiley`, `smiley_set`, `filename`)
	VALUES ";

$cnt = count($smileys);
$i = 0;
foreach ($smileys as $smiley) {
	if ($i > 0)
		$sql .= ', ';

	$i++;
	$sql .= "('" . $i . "', 'green', '" . $smiley . ".png') ";
}

$smcFunc['db_query']('', $sql);

if (SMF == 'SSI')
	echo 'Database changes are complete! Please wait...';
