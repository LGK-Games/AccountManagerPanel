<?php

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif(!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify that you put this file in the same place as SMF\'s index.php and SSI.php files.');

if ((SMF == 'SSI') && !$user_info['is_admin'])
	die('Admin privileges required.');

global $modSettings;

$temp = explode(',', $modSettings['smiley_sets_known']);
foreach ($temp as $tm => $name)
	if (in_array($name, array('green'))) unset($temp[$tm]);
$temp = implode(',', $temp);
$smiley_sets_known = $temp;


$temp = explode(PHP_EOL, $modSettings['smiley_sets_names']);
foreach ($temp as $tm => $name)
	if (in_array($name, array('Green'))) unset($temp[$tm]);
$temp = implode(PHP_EOL, $temp);
$smiley_sets_names = $temp;

updateSettings(
	array(
		'smiley_sets_known'   => $smiley_sets_known,
		'smiley_sets_names'   => $smiley_sets_names,
		'smiley_sets_default' => explode(',', $smiley_sets_known)[0]
	)
);

$smcFunc['db_query']('', '
	DELETE FROM {db_prefix}smiley_files
	WHERE smiley_set IN ({array_string:sets})',
	array(
		'sets' => ['green']
	)
);

if (SMF == 'SSI')
	echo 'Database changes are complete! Please wait...';
