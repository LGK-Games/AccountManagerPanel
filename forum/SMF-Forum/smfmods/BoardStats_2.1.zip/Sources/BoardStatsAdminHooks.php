<?php

if (!defined('SMF'))
	die('Hacking attempt...');
	
function BoardStatsAdminArea(&$admin_areas)
{
	global $txt;
	
	loadLanguage('BoardStats');
	
	return $admin_areas['config']['areas']['modsettings']['subsections'] += array('boardstats' => array(sprintf($txt['boardstats_settings'])));
}

function BoardStatsSubAction(&$subActions)
{
	return $subActions += array('boardstats' => 'BoardStatsSettings');
}

function BoardStatsSettings($return_config = false) 
{
	global $context, $txt, $scripturl, $modSettings, $settings;

	$context['page_title'] = $txt['boardstats_settings'];
	
	$config_vars = array(
		array('check', 'enable_board_stats'),
		array('select', 'board_stats_topic_order', array('views' => $txt['views'], 'replies' => $txt['replies'])),
		array('int', 'board_stats_limit'),
		array('text', 'board_stats_excluded_forums'),
	);

	if ($return_config)
		return $config_vars;

	if (isset($_GET['save'])) 
	{
		checkSession();

		saveDBSettings($config_vars);
		writeLog();

		redirectexit('action=admin;area=modsettings;sa=boardstats');
	}

	$context['post_url'] = $scripturl . '?action=admin;area=modsettings;save;sa=boardstats';

	prepareDBSettingContext($config_vars);
}