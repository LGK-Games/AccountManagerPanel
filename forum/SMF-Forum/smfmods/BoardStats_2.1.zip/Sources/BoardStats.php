<?php

if (!defined('SMF'))
	die('Hacking attempt...');

function BoardStats_load_theme()
{
	global $context;

	if (!empty($_REQUEST['board']))
	{
	    loadLanguage('BoardStats');
		loadTemplate('BoardStats');
		$context['template_layers'][] = 'board_stats';
		DisplayThisBoardStats();
	}
}
	
function DisplayThisBoardStats()
{
	global $txt, $scripturl, $board, $modSettings, $context, $settings, $smcFunc;
	
	$context['show_stats'] = false;
	
	$orderby = (isset($modSettings['board_stats_topic_order']) && $modSettings['board_stats_topic_order'] == "views" ) ? 'views' : 'replies';
	$limit = (!empty($modSettings['board_stats_limit'])) ? $modSettings['board_stats_limit'] : 5;
	
	$excluded_settings = !empty($modSettings['board_stats_excluded_forums']) ? $modSettings['board_stats_excluded_forums'] : '';
	$excluded_boards = explode(",",$excluded_settings);

	$context['topicordering'] = ($orderby == 'views') ? $txt['views'] : $txt['replies'];
	
	if(!empty($modSettings['enable_board_stats']))
	{
		if(!in_array($board, $excluded_boards))
		{
		    $context['show_stats'] = true;
			
			//Get top posters for this board.
			$top_posters = $smcFunc['db_query']('', '
				SELECT m.id_member, mem.real_name, mg.online_color, count(*) AS total_posts
				FROM {db_prefix}messages as m
				LEFT JOIN {db_prefix}members AS mem ON (mem.id_member = m.id_member)
				LEFT JOIN {db_prefix}membergroups AS mg ON (mg.id_group = mem.id_member)
				WHERE m.id_board = {int:board}
				GROUP BY m.id_member, mem.real_name, mg.online_color
				ORDER BY total_posts DESC
				LIMIT {int:limit} ',
				array(
					'board' => $board,
					'limit' => $limit,
					'is_approved' => 1,
				)
			);
			
			$context['top_posters'] = array();
	
            while ($row = $smcFunc['db_fetch_assoc']($top_posters))
            {
                if (strlen($row['real_name']) > 6)
	            {
	                 $row['real_name'] = substr($row['real_name'], 0, 6) . "..."; 
	            } 
				
				if (empty($row['id_member']))
	            {
	                 continue; 
	            } 
	   
                $context['top_posters'][] = array(
		             'posts' => $row['total_posts'],
                     'link' => !empty($row['id_member']) ? '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '" style="color: ' . $row['online_color'] . ';">' . $row['real_name'] . '</a>' : $txt['guest']
                 );
           }
		   
           $smcFunc['db_free_result']($top_posters);

	       //Get top topic starters for this board.
		   $top_topicers = $smcFunc['db_query']('', '
				SELECT t.id_member_started,mem.real_name, mem.id_member, mg.online_color, count(*) AS total_topics
				FROM {db_prefix}topics as t
				LEFT JOIN {db_prefix}members AS mem ON (mem.id_member = t.id_member_started)
				LEFT JOIN {db_prefix}membergroups AS mg ON (mg.id_group = mem.id_member)
				WHERE t.id_board = {int:board}
				GROUP BY t.id_member_started, mem.real_name, mem.id_member, mg.online_color
				ORDER BY total_topics DESC
				LIMIT {int:limit} ',
				array(
					'board' => $board,
					'limit' => $limit,
					'is_approved' => 1,
				)
			);
			
			$context['top_topicers'] = array();
	 
            while ($row = $smcFunc['db_fetch_assoc']($top_topicers))
            {
                if (strlen($row['real_name']) > 6)
	            {
	               $row['real_name'] = substr($row['real_name'], 0, 6) . "..."; 
	            }
 
			    if (empty($row['id_member']))
	            {
	                 continue; 
	            } 
	  
               $context['top_topicers'][] = array(
                  'topics' => $row['total_topics'],
                  'link' => !empty($row['id_member']) ?  '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '" style="color: ' . $row['online_color'] . ';">' . $row['real_name'] . '</a>' : $txt['guest']
               );
            }
			
            $smcFunc['db_free_result']($top_topicers);
   
            //Get most viewed/replied topics for this board.
			$top_topics = $smcFunc['db_query']('', '
				SELECT t.id_topic, t.id_board, m.subject, m.id_topic, m.poster_time, m.poster_name, t.num_views, t.num_replies, m.id_member, mg.online_color
				FROM {db_prefix}topics as t
				INNER JOIN {db_prefix}messages AS m ON (m.id_msg = t.id_first_msg)
				INNER JOIN {db_prefix}boards AS b ON (b.id_board = t.id_board)
				LEFT JOIN {db_prefix}membergroups AS mg ON (mg.id_group = m.id_member)
				WHERE {query_wanna_see_board}' . ($modSettings['postmod_active'] ? '
				AND t.approved = {int:is_approved}' : '') . (!empty($modSettings['recycle_enable']) && $modSettings['recycle_board'] > 0 ? '
				AND b.id_board != {int:recycle_enable}' : '') . '
				AND t.id_board = {int:board}
				ORDER BY t.num_' . $orderby . ' DESC
				LIMIT {int:limit} ',
				array(
					'board' => $board,
					'limit' => $limit,
					'is_approved' => 1,
					'recycle_enable' => $modSettings['recycle_board'],
				)
			);
			
			$context['top_topics'] = array();
	
            while ($row = $smcFunc['db_fetch_assoc']($top_topics))
            {
                if (strlen($row['subject']) > 20)
	            {
	                $row['subject'] = substr($row['subject'], 0, 14) . "..."; 
	            }
		
	            if (strlen($row['poster_name']) > 10)
	            {
	                $row['poster_name'] = substr($row['poster_name'], 0, 10) . "..."; 
	            }
	        
                $context['top_topics'][] = array(
		             'link' => '<a href="' . $scripturl . '?topic=' . $row['id_topic'] . '.new;topicseen#new">' . $row['subject'] . '</a>',
                     'time' => timeformat($row['poster_time']),
		             'starter' => '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '" style="color: ' . $row['online_color'] . ';">' . $row['poster_name'] . '</a>',
					 'orderby' => ($orderby == 'views') ? $row['num_views'] : $row['num_replies'],
                );
            }
   
            $smcFunc['db_free_result']($top_topics);
		}
	}
}