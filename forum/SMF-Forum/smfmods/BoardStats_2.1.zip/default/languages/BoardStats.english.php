<?php

global $modSettings;

$txt['top_posters'] = 'Top Posters';
$txt['top_topic_starters'] = 'Top Topicers';
$txt['top_topics'] = 'Top Topics';
$txt['boardstats_settings'] = 'Board Stats Settings';
$txt['enable_board_stats'] = 'Enable Mod <div class="smalltext">Here you can enable/disable the mod.</div>';
$txt['board_stats_topic_order'] = 'Topics Order By Criteria <div class="smalltext">This field controls the display order of topics. By default it set to be ordered by views.</div>';
$txt['board_stats_limit'] = 'Board Stats Limit <div class="smalltext">This field controls the number of stats that will be displayed. By default it is set to show 5.</div>';
$txt['board_stats_excluded_forums'] = 'Excluded Forums <div class="smalltext">Enter the id(s) of the board(s) that you want to exclude from showing their top stats. To exclude more than one board, separate the ids by a comma. i.e. 1,2,3,4.</div>';
$txt['board_top_stats_title'] = 'Top '.isset($modSettings['board_stats_limit']).' Stats';