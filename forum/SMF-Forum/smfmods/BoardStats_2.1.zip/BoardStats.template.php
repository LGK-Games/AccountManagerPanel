<?php

function template_board_stats_above()
{
     global $context, $modSettings, $txt;

	 //Display each board top stats.
     if (!empty($context['show_stats']) && !empty($modSettings['enable_board_stats']) && !empty($context['top_topics']))
     {	  
            echo '<br />
            <div class="cat_bar">
			<h3 class="catbg" style = "text-align:center">
				<span class="main_icons stats"></span>', $context['name'], ' - ', $txt['board_top_stats_title'], '
			</h3>
		    </div>	
            <div class="roundframe">
            <table class="table_grid">
                <tr class="title_bar">
                     <th width="15%">' . $txt['top_posters'] . '</th>
                     <th width="15%">' . $txt['top_topic_starters'] . '</th>
                     <th width="75%">' . $txt['top_topics'] . '</th>
                </tr>
                    <tr class="windowbg">
                      <td width="15%" valign="top">
            <table width="100%">';
            
			//Get top posters for this board.
            foreach ($context['top_posters'] AS $posters)
            {
                echo '
                      <tr>
                          <td width="50%">', $posters['link'], '</td>
                          <td width="50%" align="right">', $posters['posts'], '</td> 
                      </tr>'; 
            }
            echo '
            </table>
                  </td>
                     <td width="15%" valign="top">
           <table width="100%">';

           //Get top topic starters for this board.
           foreach ($context['top_topicers'] AS $topicers)
           {
               echo '
                     <tr>
                         <td width="50%">', $topicers['link'], '</td>
                         <td width="50%" align="right">', $topicers['topics'], '</td>
                     </tr>'; 
          }
          echo '
          </table>
                 </td>
                    <td width="70%" valign="top">
         <table width="100%">';

         //Get most viewed/replied topics for this board.
         foreach ($context['top_topics'] as $topic)
         {
              echo '
                    <tr>
                        <td width="45%" valign="top">', $topic['link'], ' - '.$topic['orderby'].' '.$context['topicordering'].'</td>
                        <td width="20%" align="right" style = "text-align:center" valign="top">', $topic['starter'], '</td>
                        <td width="35%" align="right" valign="top">', $topic['time'], '</td>
                    </tr>';
         }
         echo '
		 </table></td></tr></table>
            </div><span class="botslice"><span></span></span><br />'; 
    }
}

function template_board_stats_below()
{
    
}