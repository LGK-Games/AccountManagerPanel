<?php

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
{
	$ssi = true;
	require_once(dirname(__FILE__) . '/SSI.php');
}

elseif (!defined('SMF'))
	exit('<strong>Error:</strong> Cannot install - please verify you put this in the same place as SMF\'s index.php.');
	
$hook_functions = array(
    'integrate_admin_include' => '$sourcedir/BoardStatsAdminHooks.php',
	'integrate_pre_include' => '$sourcedir/BoardStats.php',
	'integrate_admin_areas' => 'BoardStatsAdminArea',
	'integrate_modify_modifications' => 'BoardStatsSubAction',
	'integrate_load_theme' => 'BoardStats_load_theme',
);

if (!empty($context['uninstalling']))
	$call = 'remove_integration_function';
else
	$call = 'add_integration_function';

foreach ($hook_functions as $hook => $function)
	$call($hook, $function);			

if (!empty($ssi))
	echo 'Congratulations! You have successfully installed this mod!';