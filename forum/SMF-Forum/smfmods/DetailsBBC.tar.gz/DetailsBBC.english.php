<?php
global $editortxt;

$editortxt['bbc_details_description'] = 'Details';
$editortxt['bbc_details_summary_prompt'] = 'Summary text (required):';
$editortxt['bbc_details_summary_default'] = 'Show details...';
$editortxt['bbc_details_summary_warning'] = 'Sorry, but the summary cannot be empty. Please try again.';

$txt['details_bbc_show_button'] = 'Show Details BBC button in editor toolbar';

?>