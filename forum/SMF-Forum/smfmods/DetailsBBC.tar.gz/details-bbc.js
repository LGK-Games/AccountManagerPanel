/*******************************************************************************
 * Details BBC
 *
 * A modification for SMF 2.1 that adds some BBCodes to allow users to create
 * HTML5 summary & details elements.
 *
 * Copyright (c) 2022 Jon Stovell
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/

// Defines the formatting info that SCEditor uses to render a BBCode in the editor.
// See https://www.sceditor.com/documentation/custom-bbcodes for info.
sceditor.formats.bbcode.set(
	'details', {
		// The HTML tags that this command will act on when toggling view modes.
		tags: {
			details: null,
			summary: null,
		},
		// Called when toggling from WYSIWYG mode to source mode.
		format: function (element, content) {
			var element = $(element)[0];

			if ($(element)[0].tagName.toLowerCase() === 'summary')
				return '';

			var summary_element, summary;
			if ($(element)[0].tagName.toLowerCase() === 'details')
			{
				summary_element = $(element).children('summary');
				summary = summary_element.text().replace('"', '\\"');

				return '[details summary="' + summary + '"]' + content + '[/details]'
			}
		},
		// Called when toggling from source mode to WYSIWYG mode.
		html: function (token, attrs, content) {
			if (typeof attrs.summary === "undefined")
				return content;

			var summary = attrs.summary.replace('"', '\\"');

			content = content.replace(/^<br ?\/?>/, '').replace(/<br ?\/?>$/, '');

			return '<details open class="bbc_details" style="border:1px dotted #aaa;"><summary class="bbc_summary" style="margin:5px;">' + summary + '</summary><div class="bbc_details_content" style="min-height:1em;margin:2px;border:1px dotted #aaa;padding:2px;">' + content + '</div></details>';
		},
		// Other options
		allowsEmpty: true,
		isInline: false,
		breakEnd: true,
		breakAfter: true,
		quoteType: $.sceditor.BBCodeParser.QuoteType.always,
	}
);

// Defines the command info that SCEditor uses when the user clicks a BBCode's button.
// See https://www.sceditor.com/documentation/custom-commands for info.
sceditor.command.set(
	'details', {
		// Called when editor is in WYSIWYG mode.
		exec: function(caller) {
			var summary = prompt(this._(bbc_details_summary_prompt), bbc_details_summary_default);

			if (summary == null) {
				return;
			}

			summary = summary.replace('"', '\\"');

			if (summary.length < 1) {
				alert(bbc_details_summary_warning);
				return;
			}

			this.insert('[details summary="' + summary + '"]', '[/details]');
		},
		// Called when editor is in source mode.
		txtExec: function(caller) {
			var summary = prompt(this._(bbc_details_summary_prompt), bbc_details_summary_default);

			if (summary == null) {
				return;
			}

			summary = summary.replace('"', '\\"');

			if (summary.length < 1) {
				alert(bbc_details_summary_warning);
				return;
			}

			this.insert('[details summary="' + summary + '"]', '[/details]');
		}
	}
);