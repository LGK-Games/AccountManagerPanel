[size=x-large][b]Details BBC[/b][/size]

A modification for SMF 2.1 that adds some BBCodes to allow users to create HTML5 [url=https://developer.mozilla.org/en-US/docs/Web/HTML/Element/details]summary & details[/url] elements.


[size=large][b]Settings[/b][/size]

The [b]Show Details BBC button in editor toolbar[/b] admin setting is available in [b]Administration Center ► Modification Settings ► Miscellaneous[/b]. If this setting is not enabled, users must manually enter the BBCode in their posts.


[size=large][b]License[/b][/size]

Details BBC, © 2022 Jon Stovell, is released under the MIT License. A full copy of this license is included in the package file.


[size=large][b]Credits[/b][/size]

Details BBC includes a copy of [url=https://github.com/javan/details-element-polyfill]details-element-polyfill.js[/url], © 2019 Javan Makhmali.


[size=large][b]Changelog[/b][/size]

Version 1.0:
[list]
	[li]Initial release[/li]
[/list]