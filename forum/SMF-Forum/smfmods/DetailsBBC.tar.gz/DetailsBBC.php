<?php
/*******************************************************************************
 * Details BBC
 *
 * A modification for SMF 2.1 that adds some BBCodes to allow users to create
 * HTML5 summary & details elements.
 *
 * Copyright (c) 2022 Jon Stovell
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/


if (!defined('SMF'))
	die('No direct access...');

/**
 * Adds parsing instructions to parse_bbc()
 *
 * Called by:
 * 		integrate_bbc_codes
 */
function details_bbc_codes(&$codes, &$no_autolink_tags)
{
	global $txt;

	$codes[] = array(
		'tag' => 'details',
		'parameters' => array(
			'summary' => array('quoted' => true),
		),
		'before' => '<details class="bbc_details"><summary class="bbc_summary">{summary} <a class="bbc_summary_hint bbc_link">' . $txt['code_expand'] . '...</a></summary><div class="bbc_details_content">',
		'after' => '</div></details>',
		'trim' => 'both',
		'block_level' => true,
		'disabled_before' => '<div>',
		'disabled_after' => '</div>',
	);

	loadJavaScriptFile('details-element-polyfill.js', array(), 'smf_details_polyfill');
}

/**
 * Adds button to the editor toolbar
 *
 * Called by:
 * 		integrate_bbc_buttons
 */
function details_bbc_buttons(&$bbc_tags, &$editor_tag_map)
{
	global $context, $editortxt, $modSettings;

	// This language file contains the description text for the button
	loadLanguage('DetailsBBC');

	if (!empty($modSettings['details_bbc_show_button']))
	{
		$before = !in_array('hr', explode(',', $modSettings['disabledBBC'])) ? 'horizontalrule' : 'maximize';

		$temp = array();
		foreach ($context['bbc_tags'] as $section => $buttons)
		{
			$temp[$section] = array();
			foreach ($buttons as $button)
			{
				if (isset($button['code']) && $button['code'] === $before)
				{
					$temp[$section][] = array(
						'image' => 'details',
						'code' => 'details',
						'description' => $editortxt['bbc_details_description'],
					);

					if ($button['code'] === 'maximize')
						$temp[$section][] = array();
				}

				$temp[$section][] = $button;
			}
		}
		$context['bbc_tags'] = $temp;

		addJavaScriptVar('bbc_details_summary_prompt', $editortxt['bbc_details_summary_prompt'], true);
		addJavaScriptVar('bbc_details_summary_default', $editortxt['bbc_details_summary_default'], true);
		addJavaScriptVar('bbc_details_summary_warning', $editortxt['bbc_details_summary_warning'], true);
	}

	loadJavaScriptFile('details-bbc.js', array('minimize' => true), 'smf_details_button');
	loadJavaScriptFile('details-element-polyfill.js', array(), 'smf_details_polyfill');
}

/**
 * Load the CSS
 * Called by:
 * 		integrate_pre_css_output
 */
function details_bbc_pre_css_output()
{
	loadCSSFile('details-bbc.css', array('minimize' => true), 'smf_details');
}

/**
 * Give the admin some control
 * Called by:
 * 		integrate_general_mod_settings
 */
function details_bbc_settings(&$config_vars)
{
	loadLanguage('DetailsBBC');

	// If anything is already in $config_vars, add a separator
	if (!empty($config_vars) && end($config_vars) !== '')
		$config_vars[] = '';

	$config_vars[] = array('check', 'details_bbc_show_button');
	$config_vars[] = '';

	// Be nice to others...
	reset($config_vars);
}

/**
 * Mention who made this thing
 *
 * Called by:
 * 		integrate_credits
 */
function details_bbc_credits()
{
	global $context;
	$context['copyrights']['mods'][] = 'Details BBC by Jon &quot;Sesquipedalian&quot; Stovell &copy; 2020';
}
