<?php

if (!defined('SMF'))
	die('Hacking attempt...');

// Hook Add Action
function amp_actions(&$actionArray)
{
  global $sourcedir, $modSettings;

  $actionArray += array('amp' => array('Amp.php', 'Amp'));
}

function amp_headers() {
  global $context, $scripturl, $topic;

	if (!empty($topic)) {
		echo '
	<link rel="amphtml" href="'. $scripturl . '?action=amp;topic=' . $topic .'">';
	}
}

function amp_disable_bbc($smileys = true) {
	global $context;

	if ($smileys == 'amp') {
		$disabled['img'] = true;
		$disabled['code'] = true;
	}
}