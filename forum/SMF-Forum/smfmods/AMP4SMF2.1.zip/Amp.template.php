<?php
/**
 * Simple Machines Forum (SMF)
 *
 * @package SMF
 * @author Simple Machines https://www.simplemachines.org
 * @copyright 2020 Simple Machines and individual contributors
 * @license https://www.simplemachines.org/about/smf/license.php BSD
 *
 * @version 2.1 RC2
 */

/**
 * The header. Defines the look and layout of the page as well as a form for choosing print options.
 */
function template_amp_above()
{
	global $context, $txt;

	echo '
	<!doctype html>
	<html amp lang="en"', $context['right_to_left'] ? ' dir="rtl"' : '', '>
	  <head>
		<meta charset="utf-8">
		<script async src="https://cdn.ampproject.org/v0.js"></script>
		<title>', $context['topic_subject'], '</title>
		<link rel="canonical" href="', $context['canonical_url'], '">
		<meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">
		<style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style><noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
		<style amp-custom>
			html {
				background: #3e5a78;
			}
			body {
				background: #e9eef2;
				font: 83.33%/150% "Segoe UI", "Helvetica Neue", "Nimbus Sans L", Arial, "Liberation Sans", sans-serif;
				color: #4d4d4d;
				display: flex;
				flex-flow: row wrap;
				min-height: 100vh;
			}
			body > * {
				flex: 1 100%;
			}
			::selection {
				text-shadow: none;
				background: #99d4ff;
				color: rgba(0, 0, 0, 0.6);
			}
			* {
				box-sizing: border-box;
				padding: 0;
				margin: 0;
			}
			main {
				width: 90%;
				clear: both;
				background: #fff;
				border: 1px solid #b8b8b8;
				border-radius: 8px;
				box-shadow: 0 2px 3px rgba(0, 0, 0, 0.14);
				padding: 0 0 10px 0;
			}
			#top_section .inner_wrap, main, #header, footer .inner_wrap {
				max-width: 1200px;
				margin: 0 auto;
			}
			#header {
				padding: 2px 2px 12px 2px;
				width: 90%;
				display: flex;
				align-items: center;
			}
			#header::after {
				content: "";
				display: block;
				clear: both;
			}
			h1.forumtitle {
				font-size: 1.8em;
				font-family: "Tahoma", sans-serif;
				padding: 22px 12px 6px 10px;
				font-weight: normal;
				flex: 1 1 auto;
			}
			h1.forumtitle a {
				color: #a85400;
				text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.3);
			}
			.postheader {
				border-bottom: 1px solid #bfbfbf;
				padding-bottom: 5px;
				margin-bottom: 5px;
			}
			.windowbg {
				background: #f0f4f7;
				margin: 12px 0 0 0;
				padding: 12px 16px;
				border: 1px solid #ddd;
				border-radius: 6px;
				box-shadow: 0 -2px 2px rgba(0, 0, 0, 0.1);
				overflow: auto;
			}
			.windowbg:nth-of-type(even), .bg.even {
				background: #f0f4f7;
			}
			.windowbg:nth-of-type(odd), .bg.odd {
				background: #fdfdfd;
			}
			.padding {
				padding: 8px;
			}
			a, a:visited {
				color: #346;
				text-decoration: none;
			}
			a:hover {
				text-decoration: underline;
				cursor: pointer;
			}
			h1, h2, h3, h4, h5, h6 {
				font-size: 1em;
				color: #444;
			}
			.button {
				display: inline-block;
				text-transform: uppercase;
				cursor: pointer;
				background: #fff; /* fallback for some browsers */
				background-image: linear-gradient(to bottom, #e2e9f3 0%, #fff 70%);
				border: 1px solid #ddd;
				border-right: 1px solid #bbb;
				border-bottom: 1px solid #aaa;
				border-radius: 3px;
				box-shadow: 1px 1px 1px rgba(0, 0, 0, 0.1);
				padding: 0 0.7em;
				overflow: visible;
				color: #444;
				font-size: 0.85em;
				height: calc(2em + 2em * (0.9 - 0.85)); /* "input" font size minus ".button" font size */
				line-height: 2em;
			}
			.button:not(:first-child) {
				margin-left: 4px;
			}
			.button:hover {
				color: #af6700;
				background: #fff;
				background-image: linear-gradient(to bottom, #fff 0%, #e2e9f3 70%);
				text-decoration: none;
				border: 1px solid #ddd;
				border-left: 1px solid #bbb;
				border-top: 1px solid #aaa;
				box-shadow: -1px -1px 2px rgba(0, 0, 0, 0.07), -1px -2px 4px rgba(255, 255, 255, 0.33) inset;
			}
			/* the active one */
			.button.active {
				background: #557ea0;
				color: #fff;
				font-weight: bold;
				border: 1px solid #558080;
				text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.6);
			}
			.button.active:hover {
				color: #ffc187;
				background: #557ea0;
			}
			.floatright {
				float: right;
			}
			.floatleft {
				float: left;
			}
			.floatnone {
				float: none;
			}
			.flow_auto {
				overflow: auto;
			}
			.flow_hidden {
				overflow: hidden;
			}
			.clear {
				clear: both;
			}
			.clear_left {
				clear: left;
			}
			.clear_right {
				clear: right;
			}
			.smalltext {
				font-size: 0.9em;
			}
			blockquote {
				margin: 0 0 8px 0;
				padding: 6px 10px;
				font-size: small;
				border: 1px solid #d6dfe2;
				border-left: 2px solid #aaa;
				border-right: 2px solid #aaa;
			}
			blockquote cite {
				display: block;
				border-bottom: 1px solid rgba(0, 0, 0, 0.1);
				font-size: 0.9em;
				margin-bottom: 3px;
			}
			blockquote cite::before {
				color: #aaa;
				font-size: 22px;
				font-style: normal;
				content: \'\275D\';
				margin-right: 3px;
				vertical-align: middle;
			}
			.bbc_standard_quote {
				background-color: #e0e6f6;
			}
			.bbc_alternate_quote {
				background-color: #ebf4f8;
			}
			footer {
				margin: 4em 0 0 0;
				padding: 10px 5%;
				background: #3e5a78;
				border-top: 3px solid #b2b6bd;
				align-self: flex-end;
			}
			footer li, footer p, footer a {
				font-size: 0.9em;
				color: #fff;
			}
			footer li.copyright {
				display: block;
				font-family: Verdana, sans-serif; /* Copyright must be Verdana! */
			}
			.codeheader {
				display: none;
			}
		</style>
	</head>
	<body>';

	echo '
		<header id="header">
			<h1 class="forumtitle">', $context['forum_name_html_safe'], '</h1>
		</header>
		<main class="padding">
			<h3>
				', $context['category_name'], ' => ', (!empty($context['parent_boards']) ? implode(' => ', $context['parent_boards']) . ' => ' : ''), $context['board_name'], ' => ', $txt['topic_started'], ': ', $context['poster_name'], ' ', $txt['search_on'], ' ', $context['post_time'], '
				<a href="', $context['canonical_url'], '" class="button floatright">Return to Full Version</a>
			</h3>
			<div id="posts">';
}

/**
 * The main page. This shows the relevant info in a printer-friendly format
 */
function template_main()
{
	global $context, $options, $txt, $scripturl, $settings, $topic;

	foreach ($context['posts'] as $post)
	{
		echo '
				<div class="windowbg">
					<div class="postheader">
						', $txt['title'], ': <strong>', $post['subject'], '</strong><br>
						', $txt['post_by'], ': <strong>', $post['member'], '</strong> ', $txt['search_on'], ' <strong>', $post['time'], '</strong>
					</div>
					<div class="postbody">
						', $post['body'] ,'
					</div><!-- .postbody -->
				</div>';

	$date_modified = $post['time'];
	}

	echo '
	<script type="application/ld+json">
	{
	  "@context": "http://schema.org",
	  "@type": "NewsArticle",
	  "headline": "', $context['topic_subject'], '",
	  "mainEntityOfPage":{
		"@type":"WebPage",
		"@id":"', $context['canonical_url'], '"
	  },
	  "datePublished": "' , $context['posts'][0]['time'] , '",
	  "dateModified": "' , $date_modified , '",
	  "author": {
		"@type": "Person",
		"name": "' , $context['posts'][0]['member'] , '"
	  },
	  "publisher": {
		"@type": "Organization",
		"name": "', $context['forum_name_html_safe'], '",
		"logo": {
			"@type": "ImageObject",
			"url": "' . $settings['default_theme_url'] . '/images/amp_logo.jpg",
			"width": 600,
			"height": 60
		  }
	  },
	}
  	</script>';
}

/**
 * The footer.
 */
function template_amp_below()
{
	echo '
			</div><!-- #posts -->
		</main>
		<footer class="smalltext">', theme_copyright(), '</footer>
	</body>
</html>';
}

?>