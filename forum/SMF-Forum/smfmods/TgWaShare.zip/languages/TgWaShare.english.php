<?php
$txt['TgWaShare']='Share';
?>