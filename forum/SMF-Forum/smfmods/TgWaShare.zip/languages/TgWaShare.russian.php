<?php
$txt['TgWaShare']='Поделиться';
?>