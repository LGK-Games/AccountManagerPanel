<?php
if (!defined('SMF'))
    die('Hacking attempt...');

function post_quickbuttons(&$list_items)
{
	global $settings,$txt;
	loadLanguage('TgWaShare');

	$url=preg_replace('%(index.php\?)(.*)(msg=)%i', '$1$3', $list_items['more']['report']['href']);
	
	$tg_button['tg_button']=array(
        'label' => '<img style="width: 20px; margin-bottom: -5px;" src="'. $settings['images_url'] . '/icons/Telegram.png">'.$txt['TgWaShare'],
        'href'  => 'https://t.me/share/url?url='.rawurlencode($url),
		'show'  => true
    );
	
	$wa_button['wa_button']=array(
        'label' => '<img style="width: 20px; margin-bottom: -5px;" src="'. $settings['images_url'] . '/icons/Whatsapp.png">'.$txt['TgWaShare'],
        'href'  => 'https://api.whatsapp.com/send?text='.rawurlencode($url),
		'show'  => true
    );

	$list_items['more']=array_merge($wa_button,$list_items['more']);
	$list_items['more']=array_merge($tg_button,$list_items['more']);
}
?>