<?php
/*
 * Personalized BBC was developed for SMF forums c/o Chen Zhen @ https://web-develop.ca
 * Copyright 2025  @ web-develop.ca
 * Distributed under the CC BY-ND 4.0 License (http://creativecommons.org/licenses/by-nd/4.0/)
 * Spanish translation by Rock Lee (https://www.bombercode.org) Copyright 2014-2018
*/
global $txt, $helptxt;

/* Personalized BBC general text variables */
$txt['PersonalizedBBC_tabtitle'] = 'BBC personalizado';
$txt['PersonalizedBBC_tabtitle_list'] = 'Lista de BBC personalizado';
$txt['PersonalizedBBC_tabtitle_rev'] = 'Revisi&oacute;n de BBC personalizado';
$txt['PersonalizedBBC_Settings'] = 'Configuracion de BBC personalizado';
$txt['PersonalizedBBC_AdminSettings'] = 'Configuraciones';
$txt['PersonalizedBBC_add'] = '<< Crear un nuevo BBCode >>';
$txt['PersonalizedBBC'] = 'personalizado_bbc_';
$txt['personalizedBBC_confirm'] = '&iquest;Seguro que quieres guardar estos cambios?';
$txt['personalizedBBC_name'] = 'Nombre BBCode';
$txt['personalizedBBC_description'] = 'Descripci&oacute;n';
$txt['personalizedBBC_type'] = 'Tipo';
$txt['personalizedBBC_parse'] = 'An&aacute;lisis';
$txt['personalizedBBC_trim'] = 'Recortar el espacio en blanco';
$txt['personalizedBBC_blockLvl'] = 'Nivel de bloque';
$txt['personalizedBBC_code'] = 'BBC HTML';
$txt['personalizedBBC_bbc'] = 'Uso de BBCode';
$txt['personalizedBBC_enable'] = 'Habilitar';
$txt['personalizedBBC_display'] = 'Mostrar';
$txt['personalizedBBC_delete'] = 'Borrar';
$txt['personalizedBBC_allow'] = 'Permitir';
$txt['personalizedBBC_deny'] = 'Denegar';
$txt['personalizedBBC_submit'] = 'Enviar';
$txt['personalizedBBC_image'] = 'Icono BBC';
$txt['personalizedBBC_imageUpload'] = 'Subir una imagen';
$txt['personalizedBBC_membergroups'] = 'Permisos de grupo de miembros';
$txt['personalizedBBC_membergroups_view'] = 'Visita';
$txt['personalizedBBC_membergroups_use'] = 'Uso';
$txt['personalizedBBC_membergroups_check'] = 'Marcar/Desmarcar todo';
$txt['PersonalizedBBC_page'] = 'P&aacute;gina';
$txt['PersonalizedBBC_Override'] = 'Invalidar:';
$txt['personalizedBBC_viewSource'] = 'Deshabilitar Autolink';
$txt['PersonalizedBBC_UrlCheck'] = 'Ajustar Enlace';
$txt['PersonalizedBBC_UrlCheckDisable'] = 'N/A';
$txt['PersonalizedBBC_UrlCheck3986x'] = 'RFC-3986-A';
$txt['PersonalizedBBC_UrlCheck3986'] = 'RFC-3986-B';
$txt['personalizedBBC_test_button'] = 'Prueba';
$txt['PersonalizedBBC_viewBBC'] = 'Icono de pantalla: %s';
$txt['PersonalizedBBC_viewNoBBC'] = '[n/a]';
$txt['personalizedBBC_testBBC'] = 'Prueba de BBCode';
$txt['personalizedBBC_test_content'] = 'Contenido:';
$txt['personalizedBBC_test_option'] = 'Opci&oacute;n:';
$txt['personalizedBBC_test_option1'] = 'Opci&oacute;n 1:';
$txt['personalizedBBC_test_option2'] = 'Opci&oacute;n 2:';
$txt['personalizedBBC_test_postarea'] = 'Cuadro de texto';
$txt['PersonalizedBBC_disabledFeature'] = 'Esta funci&oacute;n est&aacute; actualmente deshabilitada para esta versi&oacute;n.';
$txt['personalizedBBC_jQuery'] = '&iquest;Habilitar el soporte jQuery externo?';

// drop-down options
$txt['personalizedBBC_type_options'] = array('[tag]content[/tag]', '[tag=option]content[/tag]', '[tag=option1,option2]content[/tag]', '[tag]');
$txt['personalizedBBC_type_display'] = array('[#%^@!]content[/#%^@!]', '[#%^@!=option]content[/#%^@!]', '[#%^@!=option1,option2]content[/#%^@!]', '[#%^@!]');
$txt['personalizedBBC_parse_options'] = array('no parsing', '{content} only', '{content} and {option}');
$txt['personalizedBBC_trim_options'] = array('none', 'inside', 'outside', 'both');

// error message
$txt['PersonalizedBBC_ErrorMessage'] = 'No tienes permiso para acceder a la secci&oacute;n de administraci&oacute;n de BBC personalizado.';
$txt['PersonalizedBBC_PHP_ErrorMessage'] = 'Su versi&oacute;n de PHP es demasiado antigua, actualice a una versi&oacute;n m&aacute;s nueva.<br />Tu versi&oacute;n actual es #@#$! mientras que este complemento requiere una versi&oacute;n mínima de 5.3.0';
$txt['PersonalizedBBC_DuplicateErrorMessage'] = '<span class="error">Advertencia:</span>Esta BBC ya existe dentro de los valores predeterminados de SMF, opte por otro nombre de etiqueta de BBC.';
$txt['PersonalizedBBC_LengthErrorMessage'] = '<span class="error">Advertencia:</span> La longitud m&aacute;xima de cada nombre de etiqueta BBC no puede exceder los 25 caracteres.';
$txt['PersonalizedBBC_IllegalErrorMessage'] = '<span class="error">Advertencia:</span> Solo letras, n&uacute;meros y guiones bajos est&aacute;n permitidos dentro de los nombres de etiqueta de BBC.';

// permissions
$txt['permissiongroup_PersonalizedBBC_perms'] = 'BBC personalizado';
$txt['permissiongroup_simple_PersonalizedBBC_perms'] = 'BBC personalizado';
$txt['permissionname_PersonalizedBBC_perm_view'] = 'Ver BBCode: #@#$!';
$txt['permissionname_PersonalizedBBC_perm_use'] = 'Use BBCode: #@#$!';
$txt['permissionhelp_PersonalizedBBC_perm_view'] = 'Permitir que este grupo de miembros vea el #@#$! BBCode.';
$txt['permissionhelp_PersonalizedBBC_perm_use'] = 'Permitir que este grupo de miembros use el #@#$! BBCode.';
$txt['PersonalizedBBC_perms'] = 'Personalized BB Codes';

// help text
$helptxt['personalizedBBC_tagHelp'] = 'La designaci&oacute;n de la etiqueta BBC. Esta entrada es restrictiva, mientras que solo se permiten letras, n&uacute;meros y guiones bajos. Los espacios ingresados en esta entrada se convertir&aacute;n en guiones bajos y todo el texto se convertir&aacute; en min&uacute;sculas.<br /><br />Normalmente, cuando el nombre de la etiqueta BBC ya existe dentro de los valores predeterminados de SMF, recibir&aacute; una advertencia y no podr&aacute; guardar la etiqueta. Se proporciona una casilla de verificaci&oacute;n de anulaci&oacute;n que, cuando se analiza/controla, eludir&aacute; la advertencia y le permitir&aacute; guardar la etiqueta. Su nueva etiqueta BBC anular&aacute; cualquier etiqueta SMF predeterminada cuando se use.<br /><br />La introducci&oacute;n de nombres de etiquetas de BBC que existen dentro de la lista de BBC personalizada siempre sobrescribir&aacute; dicha etiqueta.';
$helptxt['personalizedBBC_tagDescription'] = 'La descripci&oacute;n de la etiqueta BBC. Esto se mostrar&aacute; a los usuarios cuando pasen el cursor sobre este BBCode.';
$helptxt['personalizedBBC_tagType'] = 'Seleccione el tipo de BBC que se utilizar&aacute; mientras que las descripciones de tipo son bastante auto explicativas.<br /><br />M&uacute;ltiples instancias de {content} dentro de su c&oacute;digo probablemente requieran la opci&oacute;n &quot;sin an&aacute;lisis&quot;.<br /><br />Cambiar entre &quot;an&aacute;lisis sint&aacute;ctico&quot; y &quot;sin an&aacute;lisis sint&aacute;ctico&quot; puede tener efectos no deseados en el c&oacute;digo que se ingres&oacute;, por lo tanto, uno debe verificar que el c&oacute;digo sea correcto si esa opci&oacute;n ha sido modificada.<hr /><hr />Las etiquetas de BBC cerradas se establecer&aacute;n autom&aacute;ticamente sin analizar.';
$helptxt['personalizedBBC_tagParse'] = 'Seleccione el tipo de an&aacute;lisis que se utilizar&aacute;, que determinar&aacute; el comportamiento de este BBCode.<br /><br />sin an&aacute;lisis: se ignorar&aacute; la entrada del usuario entre las etiquetas (solo se mostrar&aacute; HTML ingresado en la configuraci&oacute;n del c&oacute;digo).<br /><br />{content} solamente: {content}ser&aacute; reemplazado por lo que un usuario ingrese entre las etiquetas bbc.<br /><br />{content} y {option}: {content} ser&aacute; reemplazado por lo que un usuario ingrese entre las etiquetas bbc. {option} ser&aacute; reemplazado por lo que un usuario ingrese despu&eacute;s &quot;=&quot; dentro de una etiqueta inicial de bbc.';
$helptxt['personalizedBBC_tagTrim'] = 'Seleccione c&oacute;mo se recortar&aacute; cualquier espacio en blanco de la salida de texto BBCode.<br /><br />Esta opci&oacute;n editar&aacute; su c&oacute;digo bbc cuando se guarde en admin.<br /><br />none: No recortar&aacute; tu c&oacute;digo.<br /><br />inside: Recorte cualquier espacio en blanco entre las etiquetas HTML.<br /><br />outside: Recorta cualquier espacio en blanco fuera de las etiquetas HTML.<br /><br />both: Recortar todos los espacios en blanco.';
$helptxt['personalizedBBC_tagBlockLvl'] = 'Decida si se implementar&aacute; una pantalla de nivel de bloque.';
$helptxt['personalizedBBC_tagCode'] = 'El HTML que se utilizar&aacute; para la BBC.<br />es decir, &lt;tag&gt;{content}&lt;/tag&gt; o &lt;tag alt={option}&gt;{content}&lt;/tag&gt;<br /><br />Usted tiene la opci&oacute;n de habilitar/verificar el ajuste de [Adjust Url].<br />Esto se aplicar&aacute; cuando se ingrese una URL dentro de esta entrada y usted desee que sus fragmentos se filtren para que se ajusten a <a href="http://tools.ietf.org/html/rfc1738">est&aacute;ndares RFC 3986</a>.<br />Esto s&oacute;lo se debe utilizar cuando sea necesario/requerido, ya que puede hacer que sus enlaces in&uacute;tiles si se usa incorrectamente.<br />La opci&oacute;n en deshabilitado por defecto.';
$helptxt['personalizedBBC_tagImage'] = 'Seleccione la imagen que se utilizar&aacute; para esta BBC. Las im&aacute;genes predeterminadas se incluyen con esta modificaci&oacute;n, sin embargo, las im&aacute;genes personalizadas se pueden agregar al siguiente directorio: ../Themes/default/images/bbc/PersonalizedBBC. Solamente &@!%@ son los tipos de archivos son aceptables.';
$helptxt['personalizedBBC_tagImageUpload'] = 'Suba una imagen a la carpeta Personalized BBCode images.';
$helptxt['personalizedBBC_membergroups'] = 'La configuraci&oacute;n de permisos del grupo de miembros permite controlar la visualizaci&oacute;n y el uso.<br /><br />[Viewing]<br />Los grupos de miembros que est&aacute;n habilitados/controlados tendr&aacute;n permiso para ver este BBcode dentro de las publicaciones. Los grupos de miembros desmarcados/deshabilitados no podr&aacute;n ver este contenido BBCode.<br /><br />[Usage]<br />Los grupos de miembros que est&aacute;n habilitados/controlados tendr&aacute;n permiso para usar este BBcode dentro de las publicaciones. Los grupos de miembros no marcados/deshabilitados no podr&aacute;n usar este BBCode y se analizar&aacute;n desde su publicaci&oacute;n antes de guardarlos en la base de datos..';
$helptxt['personalizedBBC_tagViewSource'] = 'Optar si la funci&oacute;n autolink se desactivar&aacute; durante el uso de este BBCode. Permitiendo esto no har&aacute; que el analizador BBCode de cambiar sus enlaces hacia el enlace o ftp BBCode.<br /><br />Nota: Los enlaces autom&aacute;ticos se desactivan autom&aacute;ticamente cuando se deshabilita el an&aacute;lisis a pesar de esta opci&oacute;n.';
$helptxt['personalizedBBC_testBBC'] = 'Ingrese los datos apropiados en las &aacute;reas de entrada y luego presione el bot&oacute;n [prueba] para probar su BBCode.<br /><br />El resultado aparecer&aacute; debajo de las entradas en la parte inferior de esta plantilla.<br /><br />Tenga en cuenta que la prueba de un BBCode tambi&eacute;n lo guarda en la base de datos,<br />por lo tanto, si no desea usarlo despu&eacute;s de la prueba, tendr&aacute; que ajustarlo o eliminarlo dentro de la lista bbcode.';
?>