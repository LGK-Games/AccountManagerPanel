<?php
/*
 * Personalized BBC was developed for SMF forums c/o Chen Zhen @ https://web-develop.ca
 * Copyright 2025  @ web-develop.ca
 * Distributed under the CC BY-ND 4.0 License (http://creativecommons.org/licenses/by-nd/4.0/)
 * Spanish translation by Rock Lee (https://www.bombercode.org) Copyright 2014-2018
*/
global $txt, $helptxt;

/* Personalized BBC general text variables */
$txt['PersonalizedBBC_tabtitle'] = 'BBC personalizado';
$txt['PersonalizedBBC_tabtitle_list'] = 'Lista de BBC personalizado';
$txt['PersonalizedBBC_tabtitle_rev'] = 'Revisión de BBC personalizado';
$txt['PersonalizedBBC_Settings'] = 'Configuracion de BBC personalizado';
$txt['PersonalizedBBC_AdminSettings'] = 'Configuraciones';
$txt['PersonalizedBBC_add'] = '<< Crear un nuevo BBCode >>';
$txt['PersonalizedBBC'] = 'personalizado_bbc_';
$txt['personalizedBBC_confirm'] = '¿Seguro que quieres guardar estos cambios?';
$txt['personalizedBBC_name'] = 'Nombre BBCode';
$txt['personalizedBBC_description'] = 'Descripción';
$txt['personalizedBBC_type'] = 'Tipo';
$txt['personalizedBBC_parse'] = 'Análisis';
$txt['personalizedBBC_trim'] = 'Recortar el espacio en blanco';
$txt['personalizedBBC_blockLvl'] = 'Nivel de bloque';
$txt['personalizedBBC_code'] = 'BBC HTML';
$txt['personalizedBBC_bbc'] = 'Uso de BBCode';
$txt['personalizedBBC_enable'] = 'Habilitar';
$txt['personalizedBBC_display'] = 'Mostrar';
$txt['personalizedBBC_delete'] = 'Borrar';
$txt['personalizedBBC_allow'] = 'Permitir';
$txt['personalizedBBC_deny'] = 'Denegar';
$txt['personalizedBBC_submit'] = 'Enviar';
$txt['personalizedBBC_image'] = 'Icono BBC';
$txt['personalizedBBC_imageUpload'] = 'Subir una imagen';
$txt['personalizedBBC_membergroups'] = 'Permisos de grupo de miembros';
$txt['personalizedBBC_membergroups_view'] = 'Visita';
$txt['personalizedBBC_membergroups_use'] = 'Uso';
$txt['personalizedBBC_membergroups_check'] = 'Marcar/Desmarcar todo';
$txt['PersonalizedBBC_page'] = 'Página';
$txt['PersonalizedBBC_Override'] = 'Invalidar:';
$txt['personalizedBBC_viewSource'] = 'Deshabilitar Autolink';
$txt['PersonalizedBBC_UrlCheck'] = 'Ajustar Enlace';
$txt['PersonalizedBBC_UrlCheckDisable'] = 'N/A';
$txt['PersonalizedBBC_UrlCheck3986x'] = 'RFC-3986-A';
$txt['PersonalizedBBC_UrlCheck3986'] = 'RFC-3986-B';
$txt['personalizedBBC_test_button'] = 'Prueba';
$txt['PersonalizedBBC_viewBBC'] = 'Icono de pantalla: %s';
$txt['PersonalizedBBC_viewNoBBC'] = '[n/a]';
$txt['personalizedBBC_testBBC'] = 'Prueba de BBCode';
$txt['personalizedBBC_test_content'] = 'Contenido:';
$txt['personalizedBBC_test_option'] = 'Opción:';
$txt['personalizedBBC_test_option1'] = 'Opción 1:';
$txt['personalizedBBC_test_option2'] = 'Opción 2:';
$txt['personalizedBBC_test_postarea'] = 'Cuadro de texto';
$txt['PersonalizedBBC_disabledFeature'] = 'Esta función está actualmente deshabilitada para esta versión.';
$txt['personalizedBBC_jQuery'] = '¿Habilitar el soporte jQuery externo?';

// drop-down options
$txt['personalizedBBC_type_options'] = array('[tag]content[/tag]', '[tag=option]content[/tag]', '[tag=option1,option2]content[/tag]', '[tag]');
$txt['personalizedBBC_type_display'] = array('[#%^@!]content[/#%^@!]', '[#%^@!=option]content[/#%^@!]', '[#%^@!=option1,option2]content[/#%^@!]', '[#%^@!]');
$txt['personalizedBBC_parse_options'] = array('no parsing', '{content} only', '{content} and {option}');
$txt['personalizedBBC_trim_options'] = array('none', 'inside', 'outside', 'both');

// error message
$txt['PersonalizedBBC_ErrorMessage'] = 'No tienes permiso para acceder a la sección de administración de BBC personalizado.';
$txt['PersonalizedBBC_PHP_ErrorMessage'] = 'Su versión de PHP es demasiado antigua, actualice a una versión más nueva.<br />Tu versión actual es #@#$! mientras que este complemento requiere una versión mínima de 5.3.0';
$txt['PersonalizedBBC_DuplicateErrorMessage'] = '<span class="error">Advertencia:</span>Esta BBC ya existe dentro de los valores predeterminados de SMF, opte por otro nombre de etiqueta de BBC.';
$txt['PersonalizedBBC_LengthErrorMessage'] = '<span class="error">Advertencia:</span> La longitud máxima de cada nombre de etiqueta BBC no puede exceder los 25 caracteres.';
$txt['PersonalizedBBC_IllegalErrorMessage'] = '<span class="error">Advertencia:</span> Solo letras, números y guiones bajos están permitidos dentro de los nombres de etiqueta de BBC.';

// permissions
$txt['permissiongroup_PersonalizedBBC_perms'] = 'BBC personalizado';
$txt['permissiongroup_simple_PersonalizedBBC_perms'] = 'BBC personalizado';
$txt['permissionname_PersonalizedBBC_perm_view'] = 'Ver BBCode: #@#$!';
$txt['permissionname_PersonalizedBBC_perm_use'] = 'Use BBCode: #@#$!';
$txt['permissionhelp_PersonalizedBBC_perm_view'] = 'Permitir que este grupo de miembros vea el #@#$! BBCode.';
$txt['permissionhelp_PersonalizedBBC_perm_use'] = 'Permitir que este grupo de miembros use el #@#$! BBCode.';
$txt['PersonalizedBBC_perms'] = 'Personalized BB Codes';

// help text
$helptxt['personalizedBBC_tagHelp'] = 'La designación de la etiqueta BBC. Esta entrada es restrictiva, mientras que solo se permiten letras, números y guiones bajos. Los espacios ingresados en esta entrada se convertirán en guiones bajos y todo el texto se convertirá en minúsculas.<br /><br />Normalmente, cuando el nombre de la etiqueta BBC ya existe dentro de los valores predeterminados de SMF, recibirá una advertencia y no podrá guardar la etiqueta. Se proporciona una casilla de verificación de anulación que, cuando se analiza/controla, eludirá la advertencia y le permitirá guardar la etiqueta. Su nueva etiqueta BBC anulará cualquier etiqueta SMF predeterminada cuando se use.<br /><br />La introducción de nombres de etiquetas de BBC que existen dentro de la lista de BBC personalizada siempre sobrescribirá dicha etiqueta.';
$helptxt['personalizedBBC_tagDescription'] = 'La descripción de la etiqueta BBC. Esto se mostrará a los usuarios cuando pasen el cursor sobre este BBCode.';
$helptxt['personalizedBBC_tagType'] = 'Seleccione el tipo de BBC que se utilizará mientras que las descripciones de tipo son bastante auto explicativas.<br /><br />Múltiples instancias de {content} dentro de su código probablemente requieran la opción &quot;sin análisis&quot;.<br /><br />Cambiar entre &quot;análisis sintáctico&quot; y &quot;sin análisis sintáctico&quot; puede tener efectos no deseados en el código que se ingresó, por lo tanto, uno debe verificar que el código sea correcto si esa opción ha sido modificada.<hr /><hr />Las etiquetas de BBC cerradas se establecerán automáticamente sin analizar.';
$helptxt['personalizedBBC_tagParse'] = 'Seleccione el tipo de análisis que se utilizará, que determinará el comportamiento de este BBCode.<br /><br />sin análisis: se ignorará la entrada del usuario entre las etiquetas (solo se mostrará HTML ingresado en la configuración del código).<br /><br />{content} solamente: {content}será reemplazado por lo que un usuario ingrese entre las etiquetas bbc.<br /><br />{content} y {option}: {content} será reemplazado por lo que un usuario ingrese entre las etiquetas bbc. {option} será reemplazado por lo que un usuario ingrese después &quot;=&quot; dentro de una etiqueta inicial de bbc.';
$helptxt['personalizedBBC_tagTrim'] = 'Seleccione cómo se recortará cualquier espacio en blanco de la salida de texto BBCode.<br /><br />Esta opción editará su código bbc cuando se guarde en admin.<br /><br />none: No recortará tu código.<br /><br />inside: Recorte cualquier espacio en blanco entre las etiquetas HTML.<br /><br />outside: Recorta cualquier espacio en blanco fuera de las etiquetas HTML.<br /><br />both: Recortar todos los espacios en blanco.';
$helptxt['personalizedBBC_tagBlockLvl'] = 'Decida si se implementará una pantalla de nivel de bloque.';
$helptxt['personalizedBBC_tagCode'] = 'El HTML que se utilizará para la BBC.<br />es decir, &lt;tag&gt;{content}&lt;/tag&gt; o &lt;tag alt={option}&gt;{content}&lt;/tag&gt;<br /><br />Usted tiene la opción de habilitar/verificar el ajuste de [Adjust Url].<br />Esto se aplicará cuando se ingrese una URL dentro de esta entrada y usted desee que sus fragmentos se filtren para que se ajusten a <a href="http://tools.ietf.org/html/rfc1738">estándares RFC 3986</a>.<br />Esto sólo se debe utilizar cuando sea necesario/requerido, ya que puede hacer que sus enlaces inútiles si se usa incorrectamente.<br />La opción en deshabilitado por defecto.';
$helptxt['personalizedBBC_tagImage'] = 'Seleccione la imagen que se utilizará para esta BBC. Las imágenes predeterminadas se incluyen con esta modificación, sin embargo, las imágenes personalizadas se pueden agregar al siguiente directorio: ../Themes/default/images/bbc/PersonalizedBBC. Solamente &@!%@ son los tipos de archivos son aceptables.';
$helptxt['personalizedBBC_tagImageUpload'] = 'Suba una imagen a la carpeta Personalized BBCode images.';
$helptxt['personalizedBBC_membergroups'] = 'La configuración de permisos del grupo de miembros permite controlar la visualización y el uso.<br /><br />[Viewing]<br />Los grupos de miembros que están habilitados/controlados tendrán permiso para ver este BBcode dentro de las publicaciones. Los grupos de miembros desmarcados/deshabilitados no podrán ver este contenido BBCode.<br /><br />[Usage]<br />Los grupos de miembros que están habilitados/controlados tendrán permiso para usar este BBcode dentro de las publicaciones. Los grupos de miembros no marcados/deshabilitados no podrán usar este BBCode y se analizarán desde su publicación antes de guardarlos en la base de datos..';
$helptxt['personalizedBBC_tagViewSource'] = 'Optar si la función autolink se desactivará durante el uso de este BBCode. Permitiendo esto no hará que el analizador BBCode de cambiar sus enlaces hacia el enlace o ftp BBCode.<br /><br />Nota: Los enlaces automáticos se desactivan automáticamente cuando se deshabilita el análisis a pesar de esta opción.';
$helptxt['personalizedBBC_testBBC'] = 'Ingrese los datos apropiados en las áreas de entrada y luego presione el botón [prueba] para probar su BBCode.<br /><br />The result will appear under the inputs at the bottom of this template.<br /><br />Tenga en cuenta que la prueba de un BBCode también lo guarda en la base de datos,<br />por lo tanto, si no desea usarlo después de la prueba, tendrá que ajustarlo o eliminarlo dentro de la lista bbcode.';
?>