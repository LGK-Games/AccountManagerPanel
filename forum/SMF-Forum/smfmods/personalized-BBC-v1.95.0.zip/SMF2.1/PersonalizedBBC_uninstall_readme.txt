Personalized BBC
Developed for SMF forums c/o Chen Zhen @ https://web-develop.ca
Copyright 2025  @ web-develop.ca
Distributed under the [url=http://creativecommons.org/licenses/by-nd/4.0/]CC BY-ND 4.0 License[/url]


This will remove Personalized BBC from your SMF forum.
All database tables created by this modification will remain unless the option to remove them during the uninstall process is selected.

