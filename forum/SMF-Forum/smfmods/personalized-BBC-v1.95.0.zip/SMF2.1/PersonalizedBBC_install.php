<?php
/*
 * Personalized BBC was developed for SMF forums c/o Chen Zhen @ https://web-develop.ca
 * Copyright 2025 @ web-develop.ca
 * Distributed under the CC BY-ND 4.0 License (http://creativecommons.org/licenses/by-nd/4.0/)
*/

// Use this file by using SSI.php
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
    require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
    die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

/*  This file is for mysql setup */
global $smcFunc, $modSettings, $boarddir;
db_extend('packages');
$bbc_hook = version_compare((!empty($modSettings['smfVersion']) ? substr($modSettings['smfVersion'], 0, 3) : '2.0'), '2.1', '<') ? 'PersonalizedBBC_codes' : '$sourcedir/PersonalizedBBC.php|PersonalizedBBC_codes';

// Create table and columns if they do not exist
$columns = array(
	array(
	    'name' => 'bbc_id',
	    'type' => 'int',
	    'size' => 10,
		'null' => false,
	    'unsigned' => true,
	    'auto' => true,
	),
	array(
	    'name' => 'name',
	    'type' => 'varchar',
	    'size' => 255,
	    'null' => false,
	    'unsigned' => true,
	    'auto' => false,
	),
	array(
	    'name' => 'description',
	    'type' => 'varchar',
	    'size' => 255,
	    'null' => false,
	    'unsigned' => true,
	    'auto' => false,
	),
	array(
	    'name' => 'code',
	    'type' => 'text',
	    'null' => false,
	    'unsigned' => true,
	    'auto' => false,
	),
	array(
	    'name' => 'image',
	    'type' => 'varchar',
	    'size' => 255,
	    'null' => false,
	    'unsigned' => true,
	    'auto' => false,
	),
	array(
	    'name' => 'prior',
	    'type' => 'text',
	    'null' => false,
	    'unsigned' => true,
	    'auto' => false,
	),
	array(
	    'name' => 'after',
	    'type' => 'text',
	    'null' => false,
	    'unsigned' => true,
	    'auto' => false,
	),
	array(
	    'name' => 'parse',
	    'type' => 'int',
	    'size' => 10,
	    'null' => false,
	    'default' => 0,
	    'unsigned' => true,
	    'auto' => false,
	),
	array(
	    'name' => 'trim',
	    'type' => 'int',
	    'size' => 10,
	    'null' => false,
	    'default' => 0,
	    'unsigned' => true,
	    'auto' => false,
	),
	array(
	    'name' => 'type',
	    'type' => 'int',
	    'size' => 10,
	    'null' => false,
	    'default' => 0,
	    'unsigned' => true,
	    'auto' => false,
	),
	array(
	    'name' => 'block_lvl',
	    'type' => 'int',
	    'size' => 10,
	    'null' => false,
	    'default' => 0,
	    'unsigned' => true,
	    'auto' => false,
	),
	array(
	    'name' => 'enable',
	    'type' => 'int',
	    'size' => 10,
	    'null' => false,
	    'default' => 0,
	    'unsigned' => true,
	    'auto' => false,
	),
	array(
	    'name' => 'display',
	    'type' => 'int',
	    'size' => 10,
	    'null' => false,
	    'default' => 0,
	    'unsigned' => true,
	    'auto' => false,
	),
	array(
	    'name' => 'view_source',
	    'type' => 'int',
	    'size' => 10,
	    'null' => false,
	    'default' => 0,
	    'unsigned' => true,
	    'auto' => false,
	),
	array(
	    'name' => 'url_fix',
	    'type' => 'varchar',
	    'size' => 255,
	    'null' => false,
	    'unsigned' => true,
	    'auto' => false,
	    'default' => "rfc0",
	)
);
$indexes = array(
	array(
	    'type' => 'primary',
	    'columns' => array('bbc_id')
	),
);

$smcFunc['db_create_table']('{db_prefix}personalized_bbc', $columns, $indexes, array(), 'ignore');

// update older installations to use newer primary key auto_increment
$checkKey = checkBbcFieldExists('personalized_bbc', 'bbc_id');
if (!$checkKey)
{
	$result = $smcFunc['db_list_indexes'] ("{db_prefix}personalized_bbc", true);
	if (!empty($result['PRIMARY']['columns'][0]))
		$smcFunc['db_query']('', "
			ALTER TABLE {db_prefix}personalized_bbc DROP PRIMARY KEY",
			array()
		);

	$smcFunc['db_add_column']('{db_prefix}personalized_bbc',
		array(
			'name' => 'bbc_id',
			'type' => 'int',
			'size' => 10,
			'null' => false,
			'auto' => true,
		),
		array(),
		'ignore',
		'fatal'
    );

	$result = $smcFunc['db_list_indexes'] ("{db_prefix}personalized_bbc", true);
	if (empty($result['PRIMARY']['columns'][0]))
		$smcFunc['db_query']('', "
			ALTER TABLE {db_prefix}personalized_bbc MODIFY bbc_id INT primary key",
			array()
		);
}

/*  Add extra needed columns into existing tables for columns native to Personalized BBC */
/*  This is necessary due to possible manual deletion or otherwise  */
foreach ($columns as $column => $data)
{
    $smcFunc['db_add_column']('{db_prefix}personalized_bbc',
		array(
			'name' => $data['name'],
			'type' => $data['type'],
			'size' => !empty($data['size']) ? $data['size'] : '',
			'unsigned' => $data['unsigned'],
			'null' => $data['null'],
			'auto' => $data['auto'],
		),
		array(),
		'ignore',
		'fatal'
    );
}

/* Adjust max characters of the permission column to 50 (if currently less than)    */
/* Maximum bbc name will be 25 chars (-3 of actual allowed)                         */
$permissionLength = $smcFunc['db_list_columns'] ('{db_prefix}permissions', 'detail');
if ((!empty($permissionLength)) && (int)$permissionLength['permission']['size'] < 50)
{
    $column_info = array(
	'name' => 'permission',
	'type' => 'varchar',
	'size' => 50,
	'null' => false,
	'unsigned' => true,
	'auto' => false,
    );

    $smcFunc['db_change_column'] ('{db_prefix}permissions', 'permission', $column_info);
}

/* Insert integration hooks */
add_integration_function('integrate_pre_include', '$sourcedir/PersonalizedBBC.php');
add_integration_function('integrate_pre_load', 'PersonalizedBBC_load');
add_integration_function('integrate_load_permissions', 'PersonalizedBBC_load_permissions');
add_integration_function('integrate_admin_areas', 'PersonalizedBBC_admin_areas');
add_integration_function('integrate_bbc_codes', '$sourcedir/PersonalizedBBC.php|PersonalizedBBC_codes');
add_integration_function('integrate_bbc_buttons', 'PersonalizedBBC_buttons');
add_integration_function('integrate_load_theme', 'PersonalizedBBC_load_theme');
add_integration_function('integrate_pre_parsebbc', '$sourcedir/PersonalizedBBC.php|PersonalizedBBC_message');
add_integration_function('integrate_word_censor', 'PersonalizedBBC_censorship');
add_integration_function('integrate_preparsecode', 'PersonalizedBBC_preparsecode');


// add bbc directory to themes if it doesn't exist
clearstatcache();
$parentPath = dirname(__FILE__) . '/Themes/default/images/bbc/personalizedBBC';
$parentPath = str_replace('\\', '/', $parentPath);
if (is_dir($parentPath)) {
	$parentImageCount = count(glob($parentPath . '/*.{png}', GLOB_BRACE));
	$scan = scandir($boarddir . '/Themes');
	foreach($scan as $path) {
		if (is_dir($boarddir . '/Themes/' . $path) && !in_array($path, array('.', '..'))) {
			$dir = $boarddir . '/Themes/' . $path . '/images/bbc/personalizedBBC';
			$dir = str_replace('\\', '/', $dir);
			if (!is_dir($dir)) {
				copyPersonalizedBBC_Directory($parentPath, $dir);
			}
			else {
				$imageCount = count(glob($dir . '/*.{png}', GLOB_BRACE));
				if ($parentImageCount > $imageCount) {
					copyPersonalizedBBC_Directory($parentPath, $dir);
				}
			}
		}


	}
}

function copyPersonalizedBBC_Directory($source, $destination)
{
	if (is_dir($source))
	{
		if (!is_dir($destination))
			@mkdir($destination, 0755);

		$directory = @dir($source);
		while (FALSE !== ($readdirectory = $directory->read()))
		{
			if (in_array(basename($readdirectory), array('..', '.')))
				continue;

			$PathDir = $source . '/' . $readdirectory;

			if (is_dir($PathDir))
			{
				copyPersonalizedBBC_Directory($PathDir, $destination . '/' . $readdirectory);
				continue;
			}
			elseif (file_exists($PathDir) && !file_exists($destination . '/' . $readdirectory))
				@copy($PathDir, $destination . '/' . $readdirectory);
		}

		$directory->close();
	}
	elseif (@file_exists($source) && !@file_exists($destination) && !in_array(basename($source), array('.', '..')))
		@copy($source, $destination);
	else
		return false;

	return true;
}

/* Check if the column exists */
function checkBbcFieldExists($tableName,$columnName)
{
	global $smcFunc;
	$check = $smcFunc['db_list_columns'] ('{db_prefix}' . $tableName, false, array());
	if (in_array($columnName, $check))
		return true;

	return false;
}
?>