<?php
/*
 * Personalized BBC was developed for SMF forums c/o Chen Zhen @ https://web-develop.ca
 * Copyright 2025 @ web-develop.ca
 * Distributed under the CC BY-ND 4.0 License (http://creativecommons.org/licenses/by-nd/4.0/)
*/

// Use this file by using SSI.php
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
    require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
    die('<b>Error:</b> Cannot use uninstaller - please verify you put this in the same place as SMF\'s index.php.');

/*  This file is for mysql setup */
global $smcFunc, $modSettings, $settings, $boarddir;
db_extend('packages');
if (checkDbBBcTableExists('personalized_bbc')) {
	$smcFunc['db_drop_table']('{db_prefix}personalized_bbc');
}

$scan = scandir($boarddir . '/Themes');
foreach($scan as $path) {
	if (is_dir($boarddir . '/Themes/' . $path) && !in_array($path, array('.', '..'))) {
		$dir = $boarddir . '/Themes/' . $path . '/images/bbc/personalizedBBC';
		if (is_dir($dir)) {
			personalizedBBC_Rmdir($dir);
		}
	}


}

function checkDbBBcTableExists($table)
{
	global $db_prefix, $smcFunc;

	if ($smcFunc['db_list_tables'](false, $db_prefix . $table))
		return true;

	return false;
}

function personalizedBBC_Rmdir($dir)
{
	global $boarddir;

	// linux/windows compatibility
	$boarddirx = str_replace('\\', '/', $boarddir);
	$thisPath = str_replace('\\', '/', $dir);
	$boarddirx = trim($boarddirx, '/');
	$mainPathArray = array('Sources', 'Themes', 'Packages', 'Smileys', 'cache', 'avatars', 'attachments');
	$thisPath = trim($thisPath, '/');

	// make absolutely sure the deleted path is not an essential parent path
	if ($thisPath == '.' || $thisPath == '..')
		return false;
	if ($thisPath == $boarddirx)
		return false;

	foreach ($mainPathArray as $path)
	{
		if ($thisPath == $boarddirx . '/' . $path)
			return false;
	}

	clearstatcache(false, $dir);
	if (is_dir($dir))
	{
		$objects = scandir($dir);
		foreach ($objects as $object)
		{
			if ($object != '.' && $object != '..')
			{
				clearstatcache(false, $dir . '/' . $object);
				if (is_dir($dir . '/' . $object))
					personalizedBBC_Rmdir($dir . '/' . $object);
				else
					@unlink($dir . '/' . $object);
			}
		}

		reset($objects);
		clearstatcache(false, $dir);
		if (is_readable($dir) && is_dir($dir)) {
			if (count(scandir($dir)) == 2) {
				if (@rmdir($dir)) {
					clearstatcache(false, $dir);
					return true;
				}
			}
		}
	}

	return false;
}

?>