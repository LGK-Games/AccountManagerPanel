<?php
global $editortxt;
$editortxt['HTML'] = 'HTML';
?>