[size=x-large][b]HtmlButton[/b][/size]

A modification for Simple Machines Forum version 2.1 that adds an HTML button to the editor toolbar for admins. Clear documentation in the source code also allows this mod to serve as a good introductory example of how to add custom buttons to the editor in SMF 2.1.

There are no settings. Install to enable, uninstall to disable.


[size=large][b]License[/b][/size]

HtmlButton is released under the MIT License. A full copy of this license is included in the package file.


[size=large][b]Changelog[/b][/size]

Version 1.0:
[list]
	[li]Initial release[/li]
[/list]