<?php
/*******************************************************************************
 * HtmlButton
 *
 * A modification for Simple Machines Forum version 2.1 that adds an HTML button
 * to the editor toolbar for admins.
 *
 * Copyright (c) 2019 Jon Stovell
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 ******************************************************************************/


if (!defined('SMF'))
	die('No direct access...');

/**
 * Adds an HTML button to the editor toolbar (but only for admins)
 *
 * Called by:
 * 		integrate_bbc_buttons
 */
function htmlbutton_bbc_buttons(&$bbc_tags, &$editor_tag_map)
{
	global $context, $editortxt;

	// No button if you can't use the [html] BBCode
	if (!allowedTo('bbc_html'))
		return;

	// This language file contains the description text for the button
	loadLanguage('HtmlButton');

	$context['bbc_tags'][count($context['bbc_tags']) - 1][] = array(
		// Required
		'image' => 'html', // Name of PNG file to use for button icon
		'code' => 'html',
		'description' => $editortxt['HTML'],

		// Deprecated. Define these in the JavaScript file instead.
		// 'before' => '[html]',
		// 'after' => '[/html]',
	);

	loadJavaScriptFile('htmlbutton.js', array('minimize' => true), 'smf_htmlbutton');
}

/**
 * Mention who made this thing
 *
 * Called by:
 * 		integrate_credits
 */
function htmlbutton_credits()
{
	global $context;
	$context['copyrights']['mods'][] = 'HtmlButton by Jon &quot;Sesquipedalian&quot; Stovell &copy; 2019';
}
