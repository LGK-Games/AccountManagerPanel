Top Replies shows the most liked or most thanked replies at the top of the topic.

This allows users to quickly see the most useful replies in the topic.

An example scenario is if someone posted a topic asking a question, the top reply could be the best answer as voted by the community.

[size=14pt]Requirements[/size]

This mod requires PHP 7.4.10 or above.

This mod has only been tested on MySQL. Postgres may not work.

You must have either Likes functionality enabled or the [url=http://custom.simplemachines.org/mods/index.php?mod=3898]Say Thanks[/url] mod installed to use this feature.

This has been tested in Firefox 99, Chrome 100.0.4896.127 and IE Edge 101.0.1210.32.

[size=14pt]Translation Credits[/size]
Turkish - gevv
Russian - digger

[size=14pt]Support[/size]
Support for this modification can be found in the support topic.

[hr]
[url=http://creativecommons.org/licenses/by/3.0][img]http://i.creativecommons.org/l/by/3.0/80x15.png[/img][/url]
This work is licensed under a [url=http://creativecommons.org/licenses/by/3.0]Creative Commons Attribution 3.0 Unported License[/url]