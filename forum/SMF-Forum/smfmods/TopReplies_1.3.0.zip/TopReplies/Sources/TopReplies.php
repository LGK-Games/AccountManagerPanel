<?php
/**
 * Top Replies
 *
 * @package SMF
 * @author kelvincool
 * @copyright 2022 kelvincool
 * @license http://creativecommons.org/licenses/by/3.0 CC
 *
 * @version 1.2.0
 */

// No Direct Access!
if (!defined('SMF'))
	die('Hacking attempt...');

final class TopReplies
{
	public function hooks()
	{
		add_integration_function('integrate_load_theme', __CLASS__ . '::integrateLoadTheme#', false, __FILE__);
		add_integration_function('integrate_display_message_list', __CLASS__ . '::integrateDisplayMessageList#', false, __FILE__);
		add_integration_function('integrate_display_buttons', __CLASS__ . '::integrateDisplayButtons#', false, __FILE__);
		add_integration_function('integrate_modify_modifications', __CLASS__ . '::integrateModifyModifications#', false, __FILE__);
		add_integration_function('integrate_admin_areas', __CLASS__ . '::integrateAdminAreas#', false, __FILE__);
	}

	//integrate_load_theme
	public function integrateLoadTheme()
	{
		loadLanguage('TopReplies');
		loadTemplate('TopReplies', 'topreplies');
	}

	//integrate_display_message_list
	public function integrateDisplayMessageList(&$messages, &$posters)
	{
		global $messages_request, $smcFunc, $context, $messages_request_top_replies, $top_replies_stage, $modSettings;
		$messages_request_top_replies = false;
		if ($context['current_page'] == 0) { // only show on first page
			$first_msg = min($messages);
			$top_replies_stage = 0;
			$top_messages = array($first_msg);
			$msg_parameters = array(
				'threshold' => isset($modSettings['topreplies_threshold']) ? $modSettings['topreplies_threshold'] : 3,
				'limit' => isset($modSettings['topreplies_limit']) ? $modSettings['topreplies_limit'] : 3,
				'first_msg' => $first_msg,
				'new_from' => $context['topicinfo']['new_from'],
			);
			$msg_parameters['limit']++; // increase to account for first msg

			$msg_selects = array();
			$msg_tables = array();
			// call same hook so other mods can get their changes in too
			call_integration_hook('integrate_query_message', array(&$msg_selects, &$msg_tables, &$msg_parameters));

			if (isset($modSettings['topreplies_metric']) && $modSettings['topreplies_metric'] == 'likes' && isset($modSettings['enable_likes']) && $modSettings['enable_likes'] == 1)
			{
				$messages_request_top_replies = $smcFunc['db_query']('', '
					SELECT
						id_msg, icon, subject, poster_time, poster_ip, id_member, modified_time, modified_name, modified_reason, body,
						smileys_enabled, poster_name, poster_email, {db_prefix}messages.approved, likes,
						id_msg_modified < {int:new_from} AS is_read
						' . (!empty($msg_selects) ? (', ' . implode(', ', $msg_selects)) : '') . '
					FROM {db_prefix}messages
					INNER JOIN {db_prefix}topics t ON t.id_topic = {db_prefix}messages.id_topic AND t.id_first_msg = {int:first_msg}
					' . (!empty($msg_tables) ? implode("\n\t", $msg_tables) : '') . '
					WHERE likes >= {int:threshold} OR id_msg={int:first_msg}
					GROUP BY id_msg, icon, subject, poster_time, poster_ip, id_member, modified_time, modified_name, modified_reason, body,
						smileys_enabled, poster_name, poster_email, {db_prefix}messages.approved, likes,
						id_msg_modified
					' . (!empty($msg_selects) ? (', ' . implode(', ', $msg_selects)) : '') . '
					ORDER BY (MIN(id_msg={int:first_msg})) DESC, likes DESC
					LIMIT {int:limit}',
					$msg_parameters
				);
			}
			else if (isset($modSettings['topreplies_metric']) && $modSettings['topreplies_metric'] == 'thanks' && class_exists('SayThanks'))
			{
				$messages_request_top_replies = $smcFunc['db_query']('', '
					SELECT
						{db_prefix}messages.id_msg, icon, subject, poster_time, poster_ip, {db_prefix}messages.id_member, modified_time, modified_name, modified_reason, body,
						smileys_enabled, poster_name, poster_email, {db_prefix}messages.approved, likes,
						id_msg_modified < {int:new_from} AS is_read, count(mt.id_msg) AS thanks
						' . (!empty($msg_selects) ? (', ' . implode(', ', $msg_selects)) : '') . '
					FROM {db_prefix}messages
					INNER JOIN {db_prefix}topics t ON t.id_topic = {db_prefix}messages.id_topic AND t.id_first_msg = {int:first_msg}
					' . (!empty($msg_tables) ? implode("\n\t", $msg_tables) : '') . '
					LEFT JOIN {db_prefix}messages_thanks mt ON mt.id_msg = {db_prefix}messages.id_msg
					GROUP BY {db_prefix}messages.id_msg, icon, subject, poster_time, poster_ip, {db_prefix}messages.id_member, modified_time, modified_name, modified_reason, body,
							smileys_enabled, poster_name, poster_email, {db_prefix}messages.approved, likes,
							id_msg_modified
					' . (!empty($msg_selects) ? (', ' . implode(', ', $msg_selects)) : '') . '
					HAVING count(mt.id_msg) >= {int:threshold} OR id_msg={int:first_msg}
					ORDER BY (MIN({db_prefix}messages.id_msg={int:first_msg})) DESC, thanks DESC
					LIMIT {int:limit}',
					$msg_parameters
				);
			}
			if ($messages_request_top_replies != false)
			{
				while ($row = $smcFunc['db_fetch_assoc']($messages_request_top_replies))
				{
					if (!empty($row['id_member']) && !in_array($row['id_member'], $posters))
					{
						$posters[] = $row['id_member'];
					}
				}
				@$smcFunc['db_data_seek']($messages_request_top_replies, 0);
			}
		}
	}

	//integrate_display_buttons
	public function integrateDisplayButtons()
	{
		global $messages_request, $context, $messages_request_store, $messages_request_top_replies, $modSettings;

		if (isset($modSettings['topreplies_custom_style']) && $modSettings['topreplies_custom_style'] == 1)
		{
			if (isset($modSettings['topreplies_wrapper_colour']))
			{
				addInlineCss('
		#top_replies_wrapper { background: ' . $modSettings['topreplies_wrapper_colour'] . ' }');
			}

			if (isset($modSettings['topreplies_font_colour']))
			{
				addInlineCss('
		#top_replies_header h3 { color: ' . $modSettings['topreplies_font_colour'] . ' }');
			}
		}

		$messages_request_store = $messages_request;
		if ($messages_request_top_replies != false) {
			$messages_request = $messages_request_top_replies;
		}
		$context['get_message'] = call_helper(__CLASS__ . '::displayTopReplies#', true);
	}

	public function displayTopReplies()
	{
		global $messages_request, $messages_request_store, $messages_request_top_replies;

		static $top_replies_stage = null;

		if (!$messages_request_top_replies) { // no top replies query available, just do normal calls
			return prepareDisplayContext();
		}
		$result = prepareDisplayContext();
		if ($result && $top_replies_stage == 1) // first top reply msg
		{
			$top_replies_stage = 2;
			template_top_replies_above();
			if ($result)
			{
				$result['id'] .= '-top-reply';
				unset($result['quickbuttons']['quick_edit']);
				$result['css_class'] .= (!empty($result['css_class']) ? ' ' : '') . 'top_replies_first_msg';
			}
		}
		if ($top_replies_stage == 0) // first msg in topic
		{
			$top_replies_stage = 1;
		}
		if ($result && $top_replies_stage == 2) // one of the top replies
		{
			$result['id'] .= '-top-reply';
			unset($result['quickbuttons']['quick_edit']);
			$result['css_class'] .= (!empty($result['css_class']) ? ' ' : '') . 'top_replies_msg';
		}
		if (!$result && $top_replies_stage == 1) // no top replies so skip to end
		{
			$top_replies_stage = 4;
			$messages_request = $messages_request_store;
			$result = prepareDisplayContext(true); // reset
			if ($result)
			{
				$result = prepareDisplayContext(); // ignore first message
				$result = prepareDisplayContext();
			}
		}
		if (!$result && $top_replies_stage == 2) // had some top replies, now close off
		{
			$top_replies_stage = 3;
			template_top_replies_below();
			$messages_request = $messages_request_store;
			$result = prepareDisplayContext(true); // reset
			if ($result)
			{
				$result = prepareDisplayContext(); // ignore first message
				$result = prepareDisplayContext();
			}
		}
		return $result;
	}

	//integrate_modify_modifications
	public function integrateModifyModifications(&$subActions)
	{
		$subActions['topreplies'] = [$this, 'settings'];
	}

	public function settings()
	{
		global $txt, $scripturl, $context, $settings, $sc, $modSettings, $txt;
		global $smcFunc;

		$disabled = false;
		if (isset($modSettings['enable_likes']) && $modSettings['enable_likes'] == 1)
		{
			$metrics['likes'] = $txt['topreplies_metric_likes'];
		}
		if (class_exists('SayThanks'))
		{
			$metrics['thanks'] = $txt['topreplies_metric_thanks'];
		}
		if (empty($metrics))
		{
			$metrics['none'] = $txt['topreplies_metric_none'];
			$disabled = true;
		}

		$metric_value = isset($modSettings['topreplies_metric']) ? $modSettings['topreplies_metric'] : array_key_first($metrics);
		$threshold_value = isset($modSettings['topreplies_threshold']) ? $modSettings['topreplies_threshold'] : 3;
		$limit_value = isset($modSettings['topreplies_limit']) ? $modSettings['topreplies_limit'] : 3;

		$config_vars = array();
		$config_vars[] = array('select', 'topreplies_metric', 'label' => $txt['topreplies_metric'], 'disabled' => $disabled, $metrics, 'subtext' => $txt['topreplies_metric_help'], 'value' => $metric_value);
		$config_vars[] = array('int', 'topreplies_threshold', 'label' => $txt['topreplies_threshold'], 'value' => $threshold_value, 'subtext' => $txt['topreplies_threshold_help']);
		$config_vars[] = array('int', 'topreplies_limit', 'label' => $txt['topreplies_limit'], 'value' => $limit_value, 'subtext' => $txt['topreplies_limit_help']);
		$config_vars[] = array('check', 'topreplies_custom_style', 'label' => $txt['topreplies_custom_style']);
		$config_vars[] = array('color', 'topreplies_font_colour', 'label' => $txt['topreplies_font_colour']);
		$config_vars[] = array('color', 'topreplies_wrapper_colour', 'label' => $txt['topreplies_wrapper_colour']);

		$context['post_url'] = $scripturl . '?action=admin;area=modsettings;save;sa=topreplies';
		$context['settings_title'] = $txt['topreplies_text'];

		if (empty($config_vars))
		{
			$context['settings_save_dont_show'] = true;
			$context['settings_message'] = '<div class="centertext">' . $txt['modification_no_misc_settings'] . '</div>';

			return prepareDBSettingContext($config_vars);
		}

		// Saving?
		if (isset($_GET['save']))
		{
			checkSession();

			$save_vars = $config_vars;

			saveDBSettings($save_vars);

			redirectexit('action=admin;area=modsettings;sa=topreplies');
		}

		prepareDBSettingContext($config_vars);
	}

	//integrate_admin_areas
	public function integrateAdminAreas(&$admin_areas)
	{
		global $txt;
		$admin_areas['config']['areas']['modsettings']['subsections']['topreplies'] = array($txt['topreplies_settings']);
	}
}