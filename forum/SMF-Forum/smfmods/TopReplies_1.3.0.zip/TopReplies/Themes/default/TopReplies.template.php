<?php
/**
 * Top Replies
 *
 * @package SMF
 * @author kelvincool
 * @copyright 2022 kelvincool
 * @license http://creativecommons.org/licenses/by/3.0 CC
 *
 * @version 1.0.0
 */

function template_top_replies_above()
{
	global $txt;
	echo '<div id="top_replies_wrapper">
			<div id="top_replies_header">
				<h3><span>', $txt['topreplies_title'], '</span></h3>
			</div>';
}

function template_top_replies_below()
{
	echo '</div>';
}

?>