<?php
// Version: 1.2.0; Top Replies

$txt['topreplies_text'] = 'Лучшие ответы';
$txt['topreplies_settings'] = 'Лучшие ответы';
$txt['topreplies_title'] = 'Лучшие ответы';
$txt['topreplies_metric'] = 'Способ измерения';
$txt['topreplies_metric_likes'] = 'Лайки';
$txt['topreplies_metric_thanks'] = 'Благодарности';
$txt['topreplies_metric_none'] = 'Не доступно';
$txt['topreplies_metric_help'] = 'Выберите, как определять лучшие ответы. Если используется мод Say Thanks, можно выбрать между лайками и благодарностями.';
$txt['topreplies_threshold'] = 'Порог';
$txt['topreplies_limit'] = 'Количество';
$txt['topreplies_threshold_help'] = 'Сколько лайков/благодарностей должно быть у сообщения, чтобы попасть в топ ответов';
$txt['topreplies_limit_help'] = 'Сколько ответов отображать в топе';
$txt['topreplies_custom_style'] = 'Включить свое оформление';
$txt['topreplies_font_colour'] = 'Цвет заголовка';
$txt['topreplies_wrapper_colour'] = 'Цвет блока';
?>