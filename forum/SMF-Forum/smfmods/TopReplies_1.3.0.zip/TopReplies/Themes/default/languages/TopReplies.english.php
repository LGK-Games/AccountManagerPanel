<?php
// Version: 1.2.0; Top Replies

$txt['topreplies_text'] = 'Top Replies';
$txt['topreplies_settings'] = 'Top Replies';
$txt['topreplies_title'] = 'Top Replies';
$txt['topreplies_metric'] = 'Metric';
$txt['topreplies_metric_likes'] = 'Likes';
$txt['topreplies_metric_thanks'] = 'Thanks';
$txt['topreplies_metric_none'] = 'None available';
$txt['topreplies_metric_help'] = 'Choose which metric to use to determine top replies, if you have Say Thanks mod installed, you will be able to choose thanks as the metric';
$txt['topreplies_threshold'] = 'Threshold';
$txt['topreplies_limit'] = 'Limit';
$txt['topreplies_threshold_help'] = 'How many likes/thanks must a post have to qualify to be a top reply';
$txt['topreplies_limit_help'] = 'How many top replies do you want to show on the page';
$txt['topreplies_custom_style'] = 'Enable custom style';
$txt['topreplies_font_colour'] = 'Colour of title';
$txt['topreplies_wrapper_colour'] = 'Colour of wrapper box';
?>