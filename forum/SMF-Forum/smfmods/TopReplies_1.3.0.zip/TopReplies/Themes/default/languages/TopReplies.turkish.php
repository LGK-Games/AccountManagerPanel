<?php
// Version: 1.0.0; Top Replies

$txt['topreplies_text'] = 'En İyi Cevap';
$txt['topreplies_settings'] = 'En İyi Cevap';
$txt['topreplies_title'] = 'En İyi Cevap';
$txt['topreplies_metric'] = 'Metrik';
$txt['topreplies_metric_likes'] = 'Beğeni';
$txt['topreplies_metric_thanks'] = 'Teşekkür';
$txt['topreplies_metric_none'] = 'Hiçbiri mevcut değil';
$txt['topreplies_metric_help'] = 'En iyi cevapları belirlemek için hangi metriği kullanacağınızı seçin, Teşekkür Et modunu yüklediyseniz, metrik olarak teşekkürü seçebilirsiniz.';
$txt['topreplies_threshold'] = 'Eşik';
$txt['topreplies_limit'] = 'Limit';
$txt['topreplies_threshold_help'] = 'Bir iletinin en iyi cevap olması için kaç beğeni/teşekkür  gerekli?';
$txt['topreplies_limit_help'] = 'Sayfada kaç adet en iyi cevabın gösterilmesini istiyorsunuz?';
?>