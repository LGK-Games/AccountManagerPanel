# Changelog

## [1.3.0] - 2022-12-19
### Added
- Added Russian translation by digger

## [1.2.0] - 2022-06-02
### Added
- Added ability to change colours of the Top Replies box

## [1.1.1] - 2022-05-25
### Fixed
- Fixed sql issue for anyone with ONLY_FULL_GROUP_BY enabled

## [1.1.0] - 2022-05-23
### Added
- Added Turkish translation by gevv

### Fixed
- Resolved conflict with Message Bookmarks mod

## [1.0.0] - 2022-05-08
### Added
- Draft release
