<?php
/*
 * @package Avatars Display Integration
 * @version 1.5.5
 * @author Pipke http://www.simplemachines.org/community/index.php?action=profile;u=314795
 * @copyright Copyright (C) 2022, Pipke
 * @All rights reserved. 
 * @This SMF modification is subject to the BSD 2-Clause License
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
$txt['adi_settings_title'] = 'Отображение аватаров';
$txt['adi_layout_title'] = 'Оформление аватаров';
$txt['adi_boardindex'] = 'Отображать аватар последнего пользователя на главной странице';
$txt['adi_message_first'] = 'Отображать аватары авторов тем в списках тем, непрочитанных сообщений и тем с непрочитанными ответами';
$txt['adi_message_last'] = 'Отображать аватары авторов сообщений в списках тем, непрочитанных сообщений и тем с непрочитанными ответами';
$txt['adi_topic_header'] = 'Отображать аватары авторов тем в заголовках тем';
$txt['adi_recent_posts'] = 'Отображать аватары авторов сообщений на странице недавних сообщений';
$txt['adi_ic_recent_posts'] = 'Отображать аватары авторов в Инфоцентре';
$txt['adi_memberlist'] = 'Отображать аватары в списке пользователей';
$txt['adi_wholist'] = 'Отображать аватары пользователей на странице «Кто онлайн»';
$txt['adi_search_posts'] = 'Отображать аватары пользователей в результатах поиска';
$txt['adi_mentions'] = 'Отображать аватары при использовании тега @ник в сообщениях...';
$txt['adi_avatar_shadow'] = 'Добавить небольшую тень для всех аватаров';
$txt['adi_avatar_shape'] = 'Сделать все аватары круглыми';
$txt['adi_log_in'] = 'онлайн';
$txt['adi_log_un'] = 'офлайн';
$txt['adi_icon_overlay'] = 'Добавить онлайн-статус пользователя в виде значка наложения на аватаре...';
$txt['adi_icon_both'] = 'любой статус';
$txt['adi_icon_online'] = 'только если находится в сети';
$txt['adi_none'] = 'нет';
$txt['adi_mention_before'] = 'перед ссылкой @ник';
$txt['adi_mention_after'] = 'после ссылки @ник';
$txt['adi_mention_no_name'] = 'и скрывать ссылку @ник';
$txt['adi_icon_shape'] = 'Отображать значок наложения статуса пользователя в виде круга';
$txt['adi_initials'] = 'Заменить аватар по умолчанию изображением с первой буквой имени';
$txt['adi_view_your_profile'] = 'Просмотр профиля';
$txt['adi_you_are_logged_in'] = 'Вы авторизованы';
$txt['adi_unknown_user'] = 'Пользователь с ID:';
$txt['adi_default_avatar'] = 'Аватар по умолчанию';
$txt['adi_initial_avatar'] = 'Первоначальный аватар';
?>
