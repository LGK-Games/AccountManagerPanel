<?php
/*
 * @package Avatars Display Integration
 * @version 1.5.7
 * @author Pipke http://www.simplemachines.org/community/index.php?action=profile;u=314795
 * @copyright Copyright (C) 2022, Pipke
 * @All rights reserved. 
 * @This SMF modification is subject to the BSD 2-Clause License
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

if (!defined('SMF'))
	die('Hacking attempt...');

// Initialize the template... we want avatars...ofcource duh.	
function adi_integrate_load_theme()
{
	global $options, $modSettings, $settings;
	
	// Load mod style
	loadCSSFile('AvatarsDisplayIntegration.css', array('force_current' => false, 'validate' => true));				
	
	// Disable online icon/text profile page default with css (no hook found for this)
	if ($modSettings['adi_icon_overlay'] !== 'none')
		addInlineCss('#userstatus br, #userstatus a:first-child, #userstatus .smalltext {display: none;}');
	
	// Disable for @name mention icon overlay @ and change some margins'
	if ($modSettings['adi_mentions'] == 'after' || $modSettings['adi_mentions'] == 'before')
		addInlineCss('.post span[data-adi~="avatar"]::before, .list_posts span[data-adi~="avatar"]::before {display:none;}');
	if ($modSettings['adi_mentions'] == 'after')
		addInlineCss('div.post .adi_item_costum, div.list_posts .adi_item_costum {margin: 0px 0px 0px 2px;}');
	if ($modSettings['adi_mentions'] == 'before')
		addInlineCss('div.post .adi_item_costum, div.list_posts .adi_item_costum {margin: 0px -4px 0px 2px;}');
	
	// This option true...then we need this css ## titlebar 'user'  
	if ($modSettings['adi_wholist'])
		addInlineCss('#mlist span.member {line-height: 38px;}');
	
	// Have we option show on memberlist and icon status overlay true. Then we need this css
	if ($modSettings['adi_memberlist'] && $modSettings['adi_icon_overlay'] !== 'none')
		addInlineCss('td.is_online.centertext {display:none;} td.real_name .adi_item_context {margin: 0px; text-align: center; width: 40px;} tr td:nth-child(2).real_name {padding: 4px 12px !important;} #mlist .is_online {width: 60px !important;}');
	
	// Has user in profile @Board and Topic display the option selected 'Don't show users' avatars'
	if (isset($options['show_no_avatars']) && ($options['show_no_avatars']))
		return;
	
	// This option true...then we need this css
	if($modSettings['adi_message_last'])
		addInlineCss('#topic_header .lastpost {margin-right: 48px;}');	
		
	// Set the following variable to true if this theme wants to display the avatar of the user that posted the last and the first post on the message index and recent pages.
	if($modSettings['adi_message_first'] || $modSettings['adi_message_last'])
		$settings['avatars_on_indexes'] = true;	
	
	// Set the following variable to true if this theme wants to display the avatar of the user that posted the last post on the board index.
	if($modSettings['adi_boardindex'])
		$settings['avatars_on_boardIndex'] = true;		
}

// Mod admin settings
function adi_integrate_modify_avatar_settings(&$config_vars)
{
	global $txt;
	
	// Mod language
	loadLanguage('AvatarsDisplayIntegration');

	// Admin layout
	$settings = array(
		array('title', 'adi_settings_title'),
		array('check', 'adi_boardindex'),
		array('check', 'adi_message_first'),
		array('check', 'adi_message_last'),
		array('check', 'adi_topic_header'),
		array('check', 'adi_recent_posts'),
		array('check', 'adi_ic_recent_posts'),		
		array('check', 'adi_memberlist'),
		array('check', 'adi_wholist'),
		array('check', 'adi_search_posts'),
		array('select', 'adi_mentions', array('before' => $txt['adi_mention_before'], 'after' => $txt['adi_mention_after'], 'no_name' => $txt['adi_mention_no_name'], 'none' => $txt['adi_none'])),
		array('title', 'adi_layout_title'),
		array('check', 'adi_avatar_shadow'),
		array('select', 'adi_avatar_shape', array('circle' => $txt['adi_avatar_circle'], 'square' => $txt['adi_avatar_square'], 'curved' => $txt['adi_avatar_curved'])),
		array('select', 'adi_icon_overlay', array('both' => $txt['adi_icon_both'], 'online' => $txt['adi_icon_online'], 'none' => $txt['adi_none'])),
		array('check', 'adi_icon_shape'),
		array('check', 'adi_initials'),
	);

	$config_vars = array_merge($config_vars, $settings);
}

// Build the css options class for avatar, true ? double quote : false
function adi_avatar_data($double_quote) 
{	
	global $modSettings;
	
	$adi_data = 'data-adi="avatar';
	$adi_data.= $modSettings['adi_avatar_shadow'] ? ' shadow' : '';
	if ($modSettings['adi_avatar_shape'] == 'circle')
		$adi_data.= ' circle';
	if ($modSettings['adi_avatar_shape'] == 'curved')
		$adi_data.= ' curved';
	
	$adi_data.= $double_quote ? '"' : '';
	
	return $adi_data;		
}

// Build the css options class for status icon 
function adi_icon_data($data, $css) 
{	
	global $modSettings;
	
	$adi_data = 'data-adi="icon '.$data;
	$adi_data.= $modSettings['adi_avatar_shadow'] ? ' inner' : '';
	$adi_data.= $modSettings['adi_icon_shape'] ? ' circle' : '';
	if ($data == 'back') 
	{
		// css stuff	
		$bg = str_replace('windowbg ','',$css);
		
		if ($bg == 'windowbg')
			$bg = 'message';
		
		if ($bg == '')
			$bg = 'topic';
		
		$adi_data.= $css ? ' '.$bg : ' basic';
	}
	
	return $adi_data;	
}

// Build the overlay status icon
function adi_status_data($array_var, $name, $id, $css) 
{	
	global $context, $txt, $modSettings, $scripturl;
	
	// Get, if not queried yet the who's online list
	if (!isset($context['adi_online']) && $modSettings['adi_icon_overlay'] !== 'none' && $array_var == null)
		adi_get_online_members();
	
	// Mod language
	loadLanguage('AvatarsDisplayIntegration');
	
	// Is the requested user online in our mod $context
	if (!empty($id) && !empty($context['adi_online'])) 
		$array_var['is_online'] = array_key_exists($id, $context['adi_online']) ? $context['adi_online'][$id] : false;
	
	// User unauthenticated or hidden
	if (!isset($array_var['is_online']) && !$context['user']['is_logged'])
	{		
		$context['adi']['is_online'] = 'log_un';
		$context['adi']['title'] = $name.' '.$txt['adi_log_un'];
	}
	else
	{
		// Who what where is online
		$context['adi']['is_online'] = $array_var && $array_var['is_online'] ? 'log_in' : 'log_un';
		$context['adi']['title'] = $context['user']['id'] == $id ? $txt['adi_you_are_logged_in'] : ($name ? $name : $txt['adi_unknown_user'].$id).' '.($array_var && $array_var['is_online'] ? $txt['adi_log_in'] : $txt['adi_log_un']);
	}
	
	// Only used for unread_alerts menu
	if ($css == 'no_href')
		$id = 0;
	
	// Avatar overlay userstatus icon corner
	if (($modSettings['adi_icon_overlay'] == 'online' && $context['adi']['is_online'] == 'log_un') || ($modSettings['adi_icon_overlay'] == 'none'))
		$context['adi']['iconstatus'] = '';
	else
		$context['adi']['iconstatus'] = '<span '.adi_icon_data('back', $css).'"></span>'. ((allowedTo('pm_send') && $id > 0) ? '<a href="'. $scripturl. '?action=pm;sa=send;u='. $id. '" rel="nofollow">' : '') .'<span '.adi_icon_data('front', null).' '.$context['adi']['is_online'].'" title="'.$context['adi']['title'].'"></span>'. ((allowedTo('pm_send') && $id > 0) ? '</a>' : '');		
	
	// Some avatars need a href, we build that here...
	$context['adi']['open'] = $id > 0 ? '<a href="' . $scripturl . '?action=profile;u=' . $id .'" data-adi="href" title="'.($context['user']['id'] == $id ? $txt['adi_view_your_profile'] : sprintf($txt['view_profile_of_username'], $name)).'">' : '';
	$context['adi']['close'] = $id > 0 ? '</a>' : '';
	
}

// Name to rgb color
function adi_name2hex2rgb($name) 
{  	
	// Create first hex from name 
	$hex = dechex(crc32(mb_strtoupper(substr($name, 0, 6))));

	// Now hex to rgb
	$hex = str_replace('#', '', $hex);
        
	$r = hexdec(substr($hex,0,2));
	$g = hexdec(substr($hex,2,2));
	$b = hexdec(substr($hex,4,2));

	// Exclude close to white colors as the font initial is white, you get it ;)
	if ($r > 230)
		$r = $r-30;
	if ($g > 230)
		$g = $g-30;
	if ($b > 230)
		$b = $b-30;

	return ('style="background-color: rgb('.$r.','.$g.','.$b.')"');
}

// Standalone/costum avatar input
function adi_integrate_buffer($avatar)
{			
	if (isset($_REQUEST['xml']) || isset($_REQUEST['ajax']))
		return $avatar;
	
	global $context, $modSettings;
	
	// Look for this
	$find = array(	
		'~(data-adi-id="{$user_id}")~', // 0 #costum data
		'~<div></div>~', // 1
		'~<div id="display_head" class="information">~', // 2 #topicinfo context header avatar
		'~data-adi-id="(\d+)"~', // 3
		'~<a href="#" data-adi="buffer_remove_this"></a>~', // 4
		'~{adi-name=(.*)=adi-id}~', // 5
		'~{adi-name=~', // 6
		'~\*(\d+)=adi-id}~', // 7
		'~data-adi="buffer_remove_this;">~', // 8
		'~<h5></h5>~', // 9
	);
	
	// Remove unnecessary html code
	$avatar = preg_replace(array($find[1], $find[4], $find[8], $find[9]), '', $avatar);
	
	// Replace @topicinfo context header
	if (isset($context['adi_topic_header']) && $modSettings['adi_topic_header'])
		$avatar = preg_replace($find[2], '<div id="display_head" class="information">'.$context['adi_topic_header'], $avatar);
			
	// Identifier find unique user id's
	$user_ids = preg_match_all($find[3], $avatar, $matches) ? array_unique($matches[1]) : array();
	
	// Identifier find unique unknown user names'
	$user_names = preg_match_all($find[5], $avatar, $match) ? array_unique($match[1]) : array();
	
	// Replace all 'users' avatar data-adi-id identity		
	if (($display_avatars = adi_loadavatars($user_ids, $user_names)) !== false)	
	{	
		foreach ($display_avatars as $user_id => $display_avatar) 
			$avatar = preg_replace(str_replace('{$user_id}', $user_id, $find[0]), $display_avatar, $avatar);
	}
	
	// Remove unnecessary html code after the needed tranform
	$avatar = preg_replace(array($find[6], $find[7]), '', $avatar);
	
	return $avatar;
}

// Avatars from db
function adi_loadavatars($user_ids = array(), $user_names = array())
{
	global $context, $smcFunc, $modSettings;
	
	if (empty($user_ids))
		return false;
		
	$user_ids = is_array($user_ids) ? $user_ids : array($user_ids);
	
	$request = $smcFunc['db_query']('','
	SELECT mem.id_member, mem.real_name, mem.avatar, mem.email_address, a.filename, COALESCE(lo.log_time, 0) AS is_online
		FROM {db_prefix}members AS mem
		LEFT JOIN {db_prefix}attachments AS a ON (a.id_member = mem.id_member)
		LEFT JOIN {db_prefix}log_online AS lo ON (lo.id_member = mem.id_member)
		WHERE LOWER(mem.id_member) IN ({array_int:user_ids})',
		array(
			'user_ids'	=> $user_ids,
		)
	);
	
	$db_ids = array();
	
	while ($row = $smcFunc['db_fetch_assoc']($request))
	{								
		// Create array from founded id's in db
		$db_ids[] = $row['id_member'];
		
		// Load the member's avatar data
		adi_load_data($row);
		
		// Build overlay status
		adi_status_data($row, $row['real_name'], $row['id_member'], 'costum');			

		// Build the output
		if ($modSettings['adi_initials'] && $context['adi']['image'] == $modSettings['avatar_url'] . '/default.png')
			$display_avatars[$row['id_member']] = '<span class="adi_item_costum">'.$context['adi']['open'].'<span class="avatar" '.adi_name2hex2rgb($row['real_name']).' '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($row['real_name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['close'].$context['adi']['iconstatus'].'</span>';
		else
			$display_avatars[$row['id_member']] = '<span class="adi_item_costum">'.$context['adi']['open'].'<img class="avatar" src="'.$context['adi']['image'].'" '.adi_avatar_data(true).' alt="avatar_'.$row['real_name'].'">'.($modSettings['adi_mentions'] == 'none' ? '' : '<span data-adi="avatar img"></span>').$context['adi']['close'].$context['adi']['iconstatus'].'</span>';					
	}
	$smcFunc['db_free_result']($request);
	
	// Getting unique values from the 2 above arrays
	$unknown_ids = array_merge(array_diff($user_ids, $db_ids), array_diff($db_ids, $user_ids));
	
	foreach ($unknown_ids as $unknown_id) 
	{
		foreach ($user_names as $user_name)
		{			
			if (str_replace('*', '', strstr($user_name, '*')) == $unknown_id) 
				$row['real_name'] = strstr($user_name, '*', true);				
		}
	
		// Build overlay status
		adi_status_data(null, $row['real_name'], $unknown_id, 'costum');
		
		if ($modSettings['adi_initials'])			
			$display_avatars[$unknown_id] = '<span class="adi_item_costum"><span class="avatar" '.adi_name2hex2rgb($row['real_name']).' '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($row['real_name'] ? $row['real_name'] : '?', 0, 1), 'UTF-8').'</span>'.$context['adi']['iconstatus'].'</span>';
		else
			$display_avatars[$unknown_id] = '<span class="adi_item_costum"><img class="avatar" src="'.$modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true).' alt="avatar_'.$unknown_id.'">'.$context['adi']['iconstatus'].'</span>';	
	}

	return $display_avatars;
}

// Who's online list
function adi_get_online_members()
{
	global $modSettings, $context, $smcFunc;
		
	// Get the user online list.
	$request = $smcFunc['db_query']('', '	
		SELECT
			lo.id_member, mem.show_online
		FROM {db_prefix}log_online AS lo
			LEFT JOIN {db_prefix}members AS mem ON (mem.id_member = lo.id_member)	
		WHERE lo.id_member > 0'			
	);
	
	// Set array
	$context['adi_online'] = array();
	
	// Build array
	while ($row = $smcFunc['db_fetch_assoc']($request))
		$context['adi_online'][$row['id_member']] = (!empty($row['show_online']) || allowedTo('admin_forum'));
	
	$smcFunc['db_free_result']($request);
}

// Load the member's data.
function adi_load_data($key) 
{
	global $image_proxy_enabled, $user_info, $modSettings, $context, $smcFunc;
	
	// Take care of proxying avatar if required, do this here for maximum reach
	if ($image_proxy_enabled && !empty($key['avatar']) && stripos($key['avatar'], 'http://') !== false && empty($user_info['possibly_robot']))
		$key['avatar'] = get_proxied_url($key['avatar']);
	
	if (!empty($modSettings['gravatarOverride']) || (!empty($modSettings['gravatarEnabled']) && stristr($key['avatar'], 'gravatar://')))
	{
		if (!empty($modSettings['gravatarAllowExtraEmail']) && stristr($key['avatar'], 'gravatar://') && strlen($key['avatar']) > 11)
			$context['adi']['image'] = get_gravatar_url($smcFunc['substr']($key['avatar'], 11));
		else
			$context['adi']['image'] = get_gravatar_url($key['email_address']);
	}
	else
	{
		// So it's stored in the member table?
		if (!empty($key['avatar']))
		{
			$context['adi']['image'] = (stristr($key['avatar'], 'http://') || stristr($key['avatar'], 'https://')) ? $key['avatar'] : $modSettings['avatar_url'] . '/' . $key['avatar'];
		}
		elseif (!empty($key['filename']))
			$context['adi']['image'] = $modSettings['custom_avatar_url'] . '/' . $key['filename'];
		// Right... no avatar...use the default one
		else
			$context['adi']['image'] = $modSettings['avatar_url'] . '/default.png';
	}	
	
	return($context['adi']['image']);
}

// Mentions bbc 
function adi_integrate_bbc_codes(&$codes)
{
	global $context, $modSettings;
	
	// @mentions member turned on?
	if (!isset($modSettings['enable_mentions']) || ($modSettings['adi_mentions'] == 'none'))
		return;
	
	// Only coded sofar for recent and topic pages
	if ((isset($_REQUEST['action']) && $context['current_action'] == 'recent') || (isset($_REQUEST['topic'])))
	{		
		foreach ($codes as $key => $bbc)
		{
			// Find bbc tag member
			if ($codes[$key]['tag'] == 'member')
			{
				// Before	
				if ($modSettings['adi_mentions'] == 'before')
				{					
					$codes[$key]['before'] = 'data-adi-id="$1" '.$codes[$key]['before'].'{adi-name=';
					$codes[$key]['after'] = '*$1=adi-id}'.$codes[$key]['after'];
				}
				// After
				if ($modSettings['adi_mentions'] == 'after') 
				{
					$codes[$key]['before'].='{adi-name=';
					$codes[$key]['after'] = '*$1=adi-id}'.$codes[$key]['after'];
					$codes[$key]['after'].= 'data-adi-id="$1"';
				}
				// No @name link
				if ($modSettings['adi_mentions'] == 'no_name') 
				{
					$codes[$key]['before'] = '<span class="hidden">{adi-name=';	
					$codes[$key]['after'] = '*$1=adi-id}</span>data-adi-id="$1"';	
				}				
			}
		}
	}	
}

// Job for topic header
function adi_integrate_display_topic(&$topic_selects, &$topic_tables)
{
	$topic_selects = array('mem.id_member', 'mem.avatar', 'mem.email_address', 'COALESCE(lo.log_time, 0) AS is_online', 'a.filename');
	$topic_tables = array('LEFT JOIN {db_prefix}log_online AS lo ON (lo.id_member = mem.id_member)', 'LEFT JOIN {db_prefix}attachments AS a ON (a.id_member = mem.id_member)');
}

// For alerts and more...
function adi_integrate_set_avatar_data(&$image, &$data)
{	
	// Build the css data attibute. The only one we need here, so add it.
	$image.='" '.adi_avatar_data(true);
}

// Topicinfo context header avatar
function adi_integrate_display_buttons()
{
	global $options, $context, $modSettings;
	
	// Has user in profile option selected 'Don't show users' avatars'
	if (isset($options['show_no_avatars']) && ($options['show_no_avatars']))
		return;	
	
	// Has admin in Topic Settings disabled 'Show user avatars in message view'
	if (empty($modSettings['show_user_images']))
		return;
	
	// Has admin in Avatar Settings disabled this?
	if (empty($modSettings['adi_topic_header'])) 
		return;
	
	if (!isset($context['topicinfo']['avatar']['image']))
	{
		// Load the member's data.
		adi_load_data($context['topicinfo']);
			
		// We got an image, yeah baby...
		if (!empty($context['adi']['image']))
			$context['topicinfo']['avatar'] = array(
				'name' => $context['topicinfo']['avatar'],
				'image' => '<img class="floatleft avatar" src="'.$context['adi']['image'].'" alt="">',
				'href' => $context['adi']['image'],
				'url' => $context['adi']['image'],
			);
	}	
	
	// Build overlay status
	adi_status_data($context['topicinfo'], $context['topicinfo']['topic_started_name'], $context['topicinfo']['id_member_started'], null);
	
	// Add it to context array
	if ($modSettings['adi_initials'] && $context['topicinfo']['avatar']['url'] == $modSettings['avatar_url'] . '/default.png')
		$context['adi_topic_header'] = '<div class="adi_header"><span class="adi_item_topic">'.$context['adi']['open'].'<span class="avatar" '.adi_name2hex2rgb($context['topicinfo']['topic_started_name']).' '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($context['topicinfo']['topic_started_name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['close'].$context['adi']['iconstatus'].'</span></div>';
	else
		$context['adi_topic_header'] = '<div class="adi_header"><div class="adi_item_topic">'.$context['adi']['open'].'<img class="avatar" src="'.$context['topicinfo']['avatar']['url'].'" '.adi_avatar_data(true).' alt="avatar_'.$context['topicinfo']['topic_started_name'].'" />'.$context['adi']['close'].$context['adi']['iconstatus'].'</div></div>';

}

// Used for quick menu's and profile view. 
function adi_integrate_member_context(&$memberContext, $user)
{
	global $memberContext, $context, $modSettings;
	
	// Build overlay status
	adi_status_data($memberContext[$user]['online'], $memberContext[$user]['name'], $memberContext[$user]['id'], 'windowbg');	
	
	// Hook it in membercontext
	if ($modSettings['adi_initials'] && $memberContext[$user]['avatar']['url'] == $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true))
		$memberContext[$user]['avatar']['image'] = '<div class="adi_item_context">'.$context['adi']['open'].'<span '.adi_name2hex2rgb($memberContext[$user]['name']).' class="avatar" '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($memberContext[$user]['name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['close'].$context['adi']['iconstatus'].'</div>';
	else
		$memberContext[$user]['avatar']['image'] = '<div class="adi_item_context">'.$context['adi']['open'].'<img class="avatar overhere" src="'.$memberContext[$user]['avatar']['url'].' alt="avatar_'.$memberContext[$user]['name'].'" />'.$context['adi']['close'].$context['adi']['iconstatus'].'</div>';
				
}

// Used for Alerts and...more
function adi_integrate_theme_context()
{
	global $options, $modSettings, $context, $txt, $settings;
	
	// Avatars recent posts to display on info center:
	if (isset($context['latest_posts']) && $settings['number_recent_posts'] > 1 && $modSettings['adi_ic_recent_posts']) 
	{
		foreach ($context['latest_posts'] as $id_post => $post) {
			// Guests
			if ($modSettings['adi_initials'] && $context['latest_posts'][$id_post]['poster']['id'] == 0)
			{
				// Build overlay status
				adi_status_data(null, $context['latest_posts'][$id_post]['poster']['name'], null, 'costum');
				
				// Hook in context
				$context['latest_posts'][$id_post]['link'] = '<span class="adi_item_costum"><span class="avatar" '.adi_name2hex2rgb($context['latest_posts'][$id_post]['poster']['name']).' '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($context['latest_posts'][$id_post]['poster']['name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['iconstatus'].'</span>'. $post['link'];
			}
			else
				$context['latest_posts'][$id_post]['link'] = '<span>data-adi-id="'.$context['latest_posts'][$id_post]['poster']['id'].'"<span>'. $post['link'];
		}
	}
	
	// Change text/settings for mod things on 'choose avatar' @profile details.
	if (isset($context['avatars'])) {
		foreach ($context['avatars'] as $key => $avatar) {
			if ($avatar['filename'] == 'blank.png')
				unset($context['avatars'][$key]);
			if ($avatar['filename'] == 'default.png' && $modSettings['adi_initials'])
				unset($context['avatars'][$key]);
		}
	}
		
	// Mod language used for profile page
	loadLanguage('AvatarsDisplayIntegration');
	$txt['no_avatar'] = $modSettings['adi_initials'] ? $txt['adi_initial_avatar'] : $txt['adi_default_avatar'];

	// Avatar profile_menu_top (all pages)
	if (isset($context['user']['avatar']['image'])) 
	{	
		// Change item in context
		if ($modSettings['adi_initials'] && $context['user']['avatar']['href'] == $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true))
			$context['user']['avatar']['image'] = '<span class="avatar" '.adi_name2hex2rgb($context['user']['name']).' '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($context['user']['name'], 0, 1), 'UTF-8').'</span>';
		else
			$context['user']['avatar']['image'] = '<img class="avatar" src="'.$context['user']['avatar']['href'].' alt="avatar_'.$context['user']['name'].'"/>';		
	}	
			
	// Avatars alerts index
	if (isset($context['alerts']))
	{
		foreach ($context['alerts'] as $id_alert => $alert)
		{
			// Guest... no avatar... use the default image url.
			if (!isset($alert['sender']['avatar']['url']))
				$context['alerts'][$id_alert]['sender']['avatar']['url'] = $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true);	
			
			// Build overlay status
			adi_status_data(null, $context['alerts'][$id_alert]['sender_name'], $context['alerts'][$id_alert]['sender_id'], 'windowbg');
	
			// Change item in context
			if ($modSettings['adi_initials'] && $context['alerts'][$id_alert]['sender']['avatar']['url'] == $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true))	
				$context['alerts'][$id_alert]['sender']['avatar']['image'] = '<div class="adi_item_alert">'.$context['adi']['open'].'<span '.adi_name2hex2rgb($alert['sender_name']).' class="avatar" '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($alert['sender_name'], 0, 1), 'UTF-8').'</span>';
			else 
				$context['alerts'][$id_alert]['sender']['avatar']['image'] = '<div class="adi_item_alert">'.$context['adi']['open'].'<img class="avatar" src="'.$context['alerts'][$id_alert]['sender']['avatar']['url'].' alt="avatar_'.$alert['sender_name'].'" />';
			
			$context['alerts'][$id_alert]['icon'].= $context['adi']['close'].$context['adi']['iconstatus'].'</div>';
			
		}	
	}
	
	// Drop down alerts menu
	if (isset($context['unread_alerts']))
	{		
		foreach ($context['unread_alerts'] as $id_alert => $alert)
		{			
			// Guest... no avatar... use the default image url.
			if (!isset($alert['sender']['avatar']['url']))
				$context['unread_alerts'][$id_alert]['sender']['avatar']['url'] = $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true);
			
			// Build overlay status
			adi_status_data(null, $context['unread_alerts'][$id_alert]['sender_name'], $context['unread_alerts'][$id_alert]['sender_id'], 'no_href');

			// Change item in context
			if ($modSettings['adi_initials'] && $context['unread_alerts'][$id_alert]['sender']['avatar']['url'] == $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true))	
				$context['unread_alerts'][$id_alert]['sender']['avatar']['image'] = '<span '.adi_name2hex2rgb($alert['sender_name']).' class="avatar" '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($alert['sender_name'], 0, 1), 'UTF-8').'</span>';
			else 
				$context['unread_alerts'][$id_alert]['sender']['avatar']['image'] = '<img class="avatar" src="'.$context['unread_alerts'][$id_alert]['sender']['avatar']['url'].' alt="avatar_'.$alert['sender_name'].'" />';
			
			// Set the icon
			if (isset($context['unread_alerts'][$id_alert]['icon']))
				$context['unread_alerts'][$id_alert]['icon'].= $context['adi']['iconstatus'];
			else
				$context['unread_alerts'][$id_alert]['icon'] = $context['adi']['iconstatus'];
		}	
	}		
		
	// Has user in profile option selected 'Don't show users' avatars'
	if (isset($options['show_no_avatars']) && ($options['show_no_avatars']))
		return;	
	
	// Avatars categories (board)index (aka main/home page)		
	if ((isset($context['categories']) && !empty($context['categories'])) && in_array('boardindex_outer', $context['template_layers'], true) && $modSettings['adi_boardindex'])
	{			
		if (is_array($context['categories']))
		{			
			foreach ($context['categories'] as $category)
			{
				// Find in boards		
				foreach ($category['boards'] as $board)	
				{																			
					if (isset($board['last_post']))
					{					
						// Build overlay status
						adi_status_data(null, $board['last_post']['member']['name'], $board['last_post']['member']['id'], null);	
						
						// Hook item into context
						if ($modSettings['adi_initials'] && $board['last_post']['member']['avatar']['href'] == $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true))
							$context['categories'][$category['id']]['boards'][$board['id']]['css_class'] = 'adi_print '.$board['css_class'].'"><div class="adi_item_board">'.$context['adi']['open'].'<span class="avatar" '.adi_name2hex2rgb($board['last_post']['member']['name']).' '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($board['last_post']['member']['name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['close'].$context['adi']['iconstatus'].'</div><span></span class="';
						else	
							$context['categories'][$category['id']]['boards'][$board['id']]['css_class'] = 'adi_print '.$board['css_class'].'"><div class="adi_item_board">'.$context['adi']['open'].'<img class="avatar" src="'.$board['last_post']['member']['avatar']['href'].' alt="avatar_'.$board['last_post']['member']['name'].'" />'.$context['adi']['close'].$context['adi']['iconstatus'].'</div><span></span class="';					
					}
					else
						$context['categories'][$category['id']]['boards'][$board['id']]['css_class'] = 'no_board_topics';
				}
			}
		}
	}
	
	// Avatars recentposts index ## Sadly no hook wich can be used, ok there is one... the great buffer!	
	if ((isset($context['posts']) && !empty($context['posts'])) && $context['current_action'] == 'recent' && $modSettings['adi_recent_posts'])
	{										
		// Hook item into context
		foreach ($context['posts'] as $id_post => $post) 
		{
			// Guests
			if ($modSettings['adi_initials'] && $context['posts'][$id_post]['poster']['id'] == 0) 
			{
				// Build overlay status
				adi_status_data(null, $context['posts'][$id_post]['poster']['name'], null, 'costum');
				
				// Hook in context
				$context['posts'][$id_post]['board']['link'] = '</h5><span class="adi_item_costum"><span class="avatar" '.adi_name2hex2rgb($context['posts'][$id_post]['poster']['name']).' '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($context['posts'][$id_post]['poster']['name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['iconstatus'].'</span><h5>'. $context['posts'][$id_post]['board']['link'];
			}
			else
				$context['posts'][$id_post]['board']['link'] = '</h5><span class="adi_item_costum">data-adi-id="'.$context['posts'][$id_post]['poster']['id'].'"</span><h5>'.$context['posts'][$id_post]['board']['link'];
		}
	}
	
	// Avatars memberslist page
	if ((isset($context['members']) && !empty($context['members'])) && $context['current_action'] == 'mlist' && $modSettings['adi_memberlist'])
	{		
		// Hook item into context
		foreach ($context['members'] as $id => $member)
		{
			// Have we option icon status overlay on.
			if ($modSettings['adi_icon_overlay'] !== 'none')
				$context['members'][$id]['link'] = $context['members'][$id]['avatar']['image'].'</td><td class="real_name lefttext">'.$context['members'][$id]['link'];		
			else
				$context['members'][$id]['link'] = '<div data-adi="memberlistname">'.$context['members'][$id]['avatar']['image'].$context['members'][$id]['link'].'</div>';
		}	
	}
	// Avatars users who page
	if ((isset($context['members']) && !empty($context['members'])) && $context['current_action'] == 'who' && $modSettings['adi_wholist'])
	{		
		// Hook item into context
		foreach ($context['members'] as $id => $member)
		{
			if ($context['members'][$id]['is_guest']) 
			{
				if ($modSettings['adi_initials'])
					$context['members'][$id]['name'] = '<div class="adi_item_context"><span '.adi_name2hex2rgb($context['members'][$id]['name']).' class="avatar" '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($context['members'][$id]['name'], 0, 1), 'UTF-8').'</span></div>'.$context['members'][$id]['name'];
				else
					$context['members'][$id]['name'] = '<div class="adi_item_context"><img class="avatar" src="'.$modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true).' alt="avatar_'.$context['members'][$id]['name'].'" /></div>'.$context['members'][$id]['name'];
			}
			else 
			{
				$context['members'][$id]['color'].= '; display:none;">'.$context['members'][$id]['avatar']['image'].$context['members'][$id]['link_color'].'data-adi="buffer_remove_this';
				$context['members'][$id]['name'] = '';
			}
		}	
	}
}

// Search page
function adi_integrate_search_message_context(&$output)
{
	global $context, $modSettings;
	
	if (!$modSettings['adi_search_posts'])
		return;

	// Guest... no avatar... use the default image url.
	if (!isset($output['matches'][0]['member']['avatar']['url'])) 
		$output['matches'][0]['member']['avatar']['url'] = $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true);
	
	// We need to check here if your search found a posted quest result.
	if (!isset($output['matches'][0]['member']['online']['is_online'])) 
		$output['matches'][0]['member']['online']['is_online'] = false;
	
	// Build overlay status
	adi_status_data($output['matches'][0]['member']['online'], $output['matches'][0]['member']['name'], $output['matches'][0]['member']['id'], $output['css_class']);
	
	// Hook it in $output['board']['link']
	if ($modSettings['adi_initials'] && $output['matches'][0]['member']['avatar']['url'] == $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true))	
		$output['board']['link'] = '</h5><div class="adi_item_post">'.$context['adi']['open'].'<span '.adi_name2hex2rgb($output['matches'][0]['member']['name']).' class="avatar" '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($output['matches'][0]['member']['name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['close'].$context['adi']['iconstatus'].'</div><h5>'. $output['board']['link'];	
	else 
		$output['board']['link'] = '</h5><div class="adi_item_post">'.$context['adi']['open'].'<img class="avatar" src="'.$output['matches'][0]['member']['avatar']['url'].'" '.adi_avatar_data(true).' alt="avatar_'.$output['matches'][0]['member']['name'].'" />'.$context['adi']['close'].$context['adi']['iconstatus'].'</div><h5>'. $output['board']['link'];						
}

// Display(Message)index 
function adi_integrate_prepare_display_context(&$message) 
{
	// Go on...
	adi_message_layout($message);
}

// PersonalMessageindex 
function adi_integrate_prepare_pm_context(&$message) 
{
	// Go on...
	adi_message_layout($message);	
}

function adi_message_layout($message)
{
	global $options, $context, $modSettings, $txt;
		
	// Has user in profile option selected 'Don't show users' avatars'
	if (isset($options['show_no_avatars']) && ($options['show_no_avatars']))
		return;		
	
	// Has admin in Topic Settings disabled 'Show user avatars in message view'
	if (empty($modSettings['show_user_images']))
		return;	
	
	// Check in guest message case if string isset
	if (!isset($message['member']['online']['is_online'])) 
		$message['member']['online']['is_online'] = false;
	
	// Build status overlay
	adi_status_data($message['member']['online'], $message['member']['name'], $message['member']['id'], isset($message['css_class']) ? $message['css_class'] : 'message');
	
	// Has Admin set 'Show online/offline status in posts and PMs' and do we use the mod iconstatus then we disable smf core on/offline status wich is then double @ Displayindex!
	if ($context['adi']['iconstatus'])
		$modSettings['onlineEnable'] = false;
	
	// Build always the default avatar (for guests: there's no setting or other way around it)
	if (empty($message['member']['avatar']['href'])) 
	{			
		$message['member']['href'] = '#" data-adi="buffer_remove_this';
		
		if ($modSettings['adi_initials'])	
			$message['member']['avatar']['image'] = '</a><span '.adi_name2hex2rgb($message['member']['name']).' class="avatar guest" '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($message['member']['name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['iconstatus'].'</span><a href="'. $message['member']['href']. '">';
		else 	
			$message['member']['avatar']['image'] = '</a><img class="avatar guest" src="'.$modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true).' alt="avatar_'.$message['member']['name'].'" />'.$context['adi']['iconstatus'].'</span><a href="'. $message['member']['href']. '">';
	}
	else
	{
		if ($modSettings['adi_initials'] && $message['member']['avatar']['url'] == $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true))	
			$message['member']['avatar']['image'] = '<span '.adi_name2hex2rgb($message['member']['name']).' class="avatar" '.adi_avatar_data(true).' title="'.($context['user']['id'] == $message['member']['id'] ? $txt['adi_view_your_profile'] : sprintf($txt['view_profile_of_username'], $message['member']['name'])).'">'.mb_strtoupper(mb_substr($message['member']['name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['iconstatus'];
		else 			
			$message['member']['avatar']['image'] = '<img class="avatar" src="'.$message['member']['avatar']['url'].' title="'.($context['user']['id'] == $message['member']['id'] ? $txt['adi_view_your_profile'] : sprintf($txt['view_profile_of_username'], $message['member']['name'])).'" alt="avatar_'.$message['member']['name'].'" />'.$context['adi']['iconstatus'];
	}	
	
	return($message);
}

// Messageindex
function adi_integrate_messageindex_buttons()
{
	// Go on...
	adi_topic_layout();
}

// Recent, Unread
function adi_integrate_recent_buttons()
{
	// Go on...
	adi_topic_layout();
}

function adi_topic_layout()
{
	global $options, $context, $modSettings, $txt;
	
	// Has user in profile @Board and Topic display the option selected 'Don't show users' avatars'
	if (isset($options['show_no_avatars']) && ($options['show_no_avatars']))
		return;	
		
	/// Has user in profile option selected 'Don't show users' avatars'
	if (isset($options['show_no_avatars']) && ($options['show_no_avatars']))
		return;		
	
	// Find in childboards
	if ($modSettings['adi_boardindex'])
	{			
		if (isset($context['boards']) && !empty($context['boards']))
		{	
			if (is_array($context['boards']))
				foreach ($context['boards'] as $board) 
				{				
					if (isset($board['last_post'])) 
					{
						// Build overlay status
						adi_status_data(null, $board['last_post']['member']['name'], $board['last_post']['member']['id'], ' basic');	
						
						// Hook it into context	
						if ($modSettings['adi_initials'] && $board['last_post']['member']['avatar']['url'] == $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true))	
							$context['boards'][$board['id']]['css_class'] = 'adi_print '.$board['css_class'].'"><div class="adi_item_board">'.$context['adi']['open'].'<span '.adi_name2hex2rgb($board['last_post']['member']['name']).' class="avatar" '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($board['last_post']['member']['name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['close'].$context['adi']['iconstatus'].'</div><span></span class="';			
						else 			
							$context['boards'][$board['id']]['css_class'] = 'adi_print '.$board['css_class'].'"><div class="adi_item_board">'.$context['adi']['open'].'<img class="avatar" src="'.$board['last_post']['member']['avatar']['url'].' alt="avatar_'.$board['last_post']['member']['name'].'" />'.$context['adi']['close'].$context['adi']['iconstatus'].'</div><span></span class="';				
					}
				}
		}
	}
	
	// Find in topics	
	if ($modSettings['adi_message_first'] || $modSettings['adi_message_last']) 
	{
		if (isset($context['topics']) && !empty($context['topics']))
		{		
			if (is_array($context['topics']))
			{			
				foreach ($context['topics'] as $topic) 
				{
					// Are we @messageindex or @replies/unread page, they have different array key value for the topic id
					$topic['id_topic'] = isset($topic['id_topic']) ? $topic['id_topic'] : $topic['id'];
					
					// Set vars
					$first = $last = '';
					
					// Build overlay status
					if ($modSettings['adi_message_first']) 
					{
						// Build overlay status
						adi_status_data(null, $topic['first_post']['member']['name'], $topic['first_post']['member']['id'], (isset($topic['is_solved']) && $topic['is_solved'] ? 'solved' : $topic['css_class']));
						
						if ($modSettings['adi_initials'] && $topic['first_post']['member']['avatar']['url'] == $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true))
							$first = '<div class="adi_item_topic_first">'.$context['adi']['open'].'<span '.adi_name2hex2rgb($topic['first_post']['member']['name']).' class="avatar" '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($topic['first_post']['member']['name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['close'].$context['adi']['iconstatus'].'</div>';
						else						
							$first = '<div class="adi_item_topic_first">'.$context['adi']['open'].'<img class="avatar" src="'.$topic['first_post']['member']['avatar']['href'].' alt="avatar_'.$topic['first_post']['member']['name'].'" />'.$context['adi']['close'].$context['adi']['iconstatus'].'</div>';					
					}
					if ($modSettings['adi_message_last']) 
					{
						// Build overlay status
						adi_status_data(null, $topic['last_post']['member']['name'], $topic['last_post']['member']['id'], (isset($topic['is_solved']) && $topic['is_solved'] ? 'solved' : $topic['css_class']));	
						
						if ($modSettings['adi_initials'] && $topic['last_post']['member']['avatar']['url'] == $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true))
							$last = '<div class="adi_item_topic_last">'.$context['adi']['open'].'<span '.adi_name2hex2rgb($topic['last_post']['member']['name']).' class="avatar" '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($topic['last_post']['member']['name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['close'].$context['adi']['iconstatus'].'</div>';
						else
							$last = '<div class="adi_item_topic_last">'.$context['adi']['open'].'<img class="avatar" src="'.$topic['last_post']['member']['avatar']['href'].' alt="avatar_'.$topic['last_post']['member']['name'].'" />'.$context['adi']['close'].$context['adi']['iconstatus'].'</div>';
					}
					
					// Hook it into context	
					$context['topics'][$topic['id_topic']]['css_class'] .= ' adi_print '.(isset($topic['is_solved']) && $topic['is_solved'] ? 'solved' : '').'">'.$first.$last.'<span></span class="';
			
				}
			}
		}
	}	
}

// Show the hard work
function adi_integrate_credits()
{
	global $context;
	
	$context['copyrights']['mods'][] = 'Avatars Display Integration v1.5.7 | &copy 2022 by <a href="http://www.simplemachines.org/community/index.php?action=profile;u=314795">Pipke</a>';	
}

?>