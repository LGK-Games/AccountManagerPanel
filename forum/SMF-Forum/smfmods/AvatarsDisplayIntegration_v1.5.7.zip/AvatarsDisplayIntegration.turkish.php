<?php
/*
 * @package Avatars Display Integration
 * @version 1.5.1
 * @author Pipke http://www.simplemachines.org/community/index.php?action=profile;u=314795
 * @copyright Copyright (C) 2022, Pipke
 * @All rights reserved. 
 * @This SMF modification is subject to the BSD 2-Clause License
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

$txt['adi_settings_title'] = 'Avatar Entegrasyonu';
$txt['adi_layout_title'] = 'Avatar Düzeni';
$txt['adi_boardindex'] = 'Bölüm dizininde son gönderen Avatarını göster ';
$txt['adi_message_first'] = 'Okunmamış iletiler, değişiklik olmuş konular ve bölüm içinde başlatan Avatarını göster';
$txt['adi_message_last'] = 'Okunmamış iletiler, değişiklik olmuş konular ve bölüm içinde son gönderen Avatarını göster';
$txt['adi_topic_header'] = 'Konu başlığında başlatan Avatarını göster';
$txt['adi_recent_posts'] = 'Son iletiler sayfasında Avatarları göster';
$txt['adi_ic_recent_posts'] = 'Bilgi merkezi son iletiler bölümünde Avatarları göster';
$txt['adi_memberlist'] = 'Üye listesi sayfasında Avatarları göster';
$txt['adi_wholist'] = 'Kimler çevrimiçi sayfasında Avatarları göster';
$txt['adi_search_posts'] = 'Arama sonuçları sayfasında Avatarları göster';
$txt['adi_mentions'] = 'İleti içinde @bahsedilen üyenin Avatarını göster';
$txt['adi_avatar_shadow'] = 'Avatarlara gölge efekti ekle';
$txt['adi_avatar_shape'] = 'Avatarlar yuvarlak köşeli olarak ayarla';
$txt['adi_log_in'] = 'giriş yapıldı';
$txt['adi_log_un'] = 'çevrimdışı';
$txt['adi_icon_overlay'] = 'Kullanıcı çevrimiçi veya çevrimdışı ise durumunu Avatarda simge olarak göster...';
$txt['adi_icon_both'] = 'her ikiside';
$txt['adi_icon_online'] = 'sadece giriş yapıldıysa';
$txt['adi_none'] = 'kullanma';
$txt['adi_mention_before'] = '@bahsedilen bağlantısından önce avatar';
$txt['adi_mention_after'] = '@bahsedilen bağlantısından sonra avatar';
$txt['adi_mention_no_name'] = '@bahsedilen bağlantısını gösterme (sadece avatar)';
$txt['adi_icon_shape'] = 'Çevrimiçi durumu simgesi yuvarlak köşeli olarak ayarla';
$txt['adi_initials'] = 'Avatarı olmayan kullanıcıların Avatarını kullanıcı adının baş harfi olarak ayarla';
$txt['adi_view_your_profile'] = 'Profilinizi görüntüleyin';
$txt['adi_you_are_logged_in'] = 'Giriş yaptınız';
$txt['adi_unknown_user'] = 'Kullanıcının kimliği:';
$txt['adi_default_avatar'] = 'Varsayılan avatar';
$txt['adi_initial_avatar'] = 'Avatar olarak adımın baş harfini kullan';
?>
