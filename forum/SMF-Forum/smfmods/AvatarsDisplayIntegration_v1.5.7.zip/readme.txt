[color=red][size=14pt][b]Avatars Display Integration[/b][/size][/color] 

[b]For SMF 2.1.x (Hook install)[/b]
Tested only with the SMF default theme...but should work with other themes aswell!

[b]What does this mod do...[/b]
- Poster or user avatar display integration on: [i](Note: This mod will display the default/initial avatar when user has posted or mentioned as guest.)[/i]
[list]
[li]Board index[/li]
[li]Unread, Update and Message index[/li]
[li]Personal Message index[/li]
[li]Alert list[/li]
[li]Top section dropmenu[/li]
[li]Topic title header[/li]
[li]Recent post index[/li]
[li]Recent post info center[/li]
[li]Memberlist[/li]
[li]Who's Online page[/li]
[li]Search result[/li]
[li]When using bbc @mention member name in posts[/li]
[li]Other costum places*[/li]
[/list]

- Layout the avatar:
[list]
[li]With shadow[/li]
[li]As a circle/square/curved shape[/li]
[li]Add connection status overlay[/li]
[li]Initial avatar of displayname[/li]
[/list]

[b]*Other costum places:[/b]
How to add user avatar anywhere in your template file from mods maybe, simple type:
[code]data-adi-id="{userid}"[/code]

How to example in template file:
[code=find]
<div class="most_downloaded"><a href="'.$last['href'].'"><b>'.$last['name'].'</b></a></div>
[/code]
[code="replace by"]
<div class="most_downloaded">data-adi-id="'.$last['user']['id'].'"<a href="'.$last['href'].'"><b>'.$last['name'].'</b></a></div>
[/code]

How to style your costum output element:
[code]<span class="{whatever}">data-adi-id="{userid}"</span>[/code]

[color=red][b][size=12pt]License[/size][/b][/color]
* This SMF modification is subject to the BSD 2-Clause License

[color=red][b][size=12pt]Admin settings[/size][/b][/color]
- Admin->Forum->Attachments and Avatars->Avatar Settings

[color=red][b][size=12pt]Languages[/size][/b][/color]
- English
- Turkish by [url="https://www.simplemachines.org/community/index.php?action=profile;u=155076"]gevv[/url]
- Russian by [url="https://www.simplemachines.org/community/index.php?action=profile;u=229017"]Bugo[/url]
- Spanish_latin by [url="https://www.simplemachines.org/community/index.php?action=profile;u=322597"]Rock Lee␏[/url] (not complete anymore)
- Dutch by [url="https://www.simplemachines.org/community/index.php?action=profile;u=287786"]@rjen[/url]
- Portuguese_pt by [url="https://www.simplemachines.org/community/index.php?action=profile;u=391884"]marcosbr[/url]

[color=red][b][size=12pt]Changelog[/size][/b][/color]
[b]Version 1.5.7 - Mar 18, 2024[/b]
- Fixed v1.5.6 wich had different versions of files

[b]Version 1.5.6 - Nov 22, 2023[/b]
- Fixed who's online page buffer bug

[b]Version 1.5.5 - Nov 21, 2023[/b]
- Fixed css style rule for redirection boards and empty(no topics inside) boards on index
- Updated languages Dutch and Russian
- Added language Portuguese_pt
- Added collaboration with the 'Topic Solved' mod

[b]Version 1.5.4 - Nov 26, 2022[/b]
- Fixed who's online page buffer bug, due Who.template update
- Added style for avatar: Curved (square shape with rounded corners)

[b]Version 1.5.2 - Mar 1, 2022[/b]
- Fixed responsive css for boardindex

[b]Version 1.5.1 - Feb 28, 2022[/b]
- Fixed css for @mentions avatar in posts
- Added dutch language

[b]Version 1.5 - Feb 27, 2022[/b]
- Fixed error 500 blank page due missing global var
- Fixed Undefined index: current_action
- Added option: Display avatar poster recent posts on info center

[b]Version 1.4.2 - Aug 4, 2021[/b]
- Fixed Trying to access array offset on value of type null

[b]Version 1.4.1 - Aug 4, 2021[/b]
- Fixed Undefined array key "profile_of"

[b]Version 1.4 - Aug 3, 2021[/b]
- Fixed Undefined index global $txt var "profile_of", it doesnt exist anymore in 2.1 RC4

[b]Version 1.3 - Jul 19, 2021[/b]
- Fixed error message when uninstalling

[b]Version 1.2 - Mar 7, 2020[/b]
- Fixed anchor bbc @mention member name 'before the @name link'
- Fixed Undefined index: alert icon

[b]Version 1.1 - Mar 4, 2020[/b]
- Added option avatar Who's Online page
- Optimized several css rules
- Fixed css for the 'who likes posts' avatar position
- Fixed comparison operator
- Fixed initial avatar for guests when using bbc @member in posts and at the recent post index

[b]Version 1.0 - Jan 28, 2020[/b]
- Initial Release