<?php
/*
 * @package Avatars Display Integration
 * @version 1.5.4
 * @author Pipke http://www.simplemachines.org/community/index.php?action=profile;u=314795
 * @copyright Copyright (C) 2020, Pipke
 * @All rights reserved. 
 * @This SMF modification is subject to the BSD 2-Clause License
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
	require_once(dirname(__FILE__) . '/SSI.php');
elseif (!defined('SMF'))
	exit('<b>Error:</b> Cannot install or uninstall - please verify you put this in the same place as SMF\'s index.php.');

// Mod db-settings
if (!empty($context['uninstalling']))
{
	// Leave it out at this point, so it will not be included in the minified file after uninstall.
	unset($context['css_files']['AvatarsDisplayIntegration_css']);
	
	// Remove adi db-settings
	$mod_settings = array('adi_boardindex', 'adi_message_first', 'adi_message_last', 'adi_topic_header', 'adi_recent_posts', 'adi_ic_recent_posts', 'adi_memberlist', 'adi_wholist', 'adi_search_posts', 'adi_mentions', 'adi_avatar_shadow', 'adi_avatar_shape', 'adi_icon_overlay', 'adi_icon_shape', 'adi_initials');
	foreach($mod_settings as $adi_db_list)
	{
		$smcFunc['db_query']('', '
			DELETE FROM {db_prefix}settings
			WHERE variable = {string:adi_db}',
			array(
				'adi_db' => $adi_db_list,
			)
		);
	}
}
else
{
	// Adding adi db-settings	
	$mod_settings = array(
		'adi_boardindex' => 1,
		'adi_message_first' => 1,
		'adi_message_last' => 1,
		'adi_topic_header' => 1,
		'adi_recent_posts' => 1,
		'adi_ic_recent_posts' => 1,
		'adi_memberlist' => 1,
		'adi_wholist' => 1,
		'adi_search_posts' => 1,
		'adi_mentions' => 'no_name',
		'adi_avatar_shadow' => 1,
		'adi_avatar_shape' => 'circle',
		'adi_icon_overlay' => 'both',
		'adi_icon_shape' => 1,
		'adi_initials' => 1
	);
	updateSettings($mod_settings);
}

// Prepare hooks
$hook_functions = array(
	'integrate_pre_include' => '$sourcedir/AvatarsDisplayIntegration.php',
	'integrate_buffer' => 'adi_integrate_buffer',	
	'integrate_load_theme' => 'adi_integrate_load_theme',
	'integrate_bbc_codes' => 'adi_integrate_bbc_codes',
	'integrate_display_topic' => 'adi_integrate_display_topic',
	'integrate_display_buttons' => 'adi_integrate_display_buttons',
	'integrate_modify_avatar_settings' => 'adi_integrate_modify_avatar_settings',
	'integrate_member_context' => 'adi_integrate_member_context',
	'integrate_theme_context' => 'adi_integrate_theme_context',
	'integrate_prepare_display_context' => 'adi_integrate_prepare_display_context',
	'integrate_prepare_pm_context' => 'adi_integrate_prepare_pm_context',
	'integrate_messageindex_buttons' => 'adi_integrate_messageindex_buttons',
	'integrate_search_message_context' => 'adi_integrate_search_message_context',
	'integrate_set_avatar_data' => 'adi_integrate_set_avatar_data',
	'integrate_recent_buttons' => 'adi_integrate_recent_buttons',
	'integrate_credits' => 'adi_integrate_credits'
	);

// Adding or removing hooks
if (!empty($context['uninstalling']))
	$request = 'remove_integration_function';
else
	$request = 'add_integration_function';

// Carrying out the hooks
foreach ($hook_functions as $hook => $function)
	$request($hook, $function);

?>