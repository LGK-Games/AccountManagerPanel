<?php
/*
 * @package Avatars Display Integration
 * @version 1.5.5
 * @author Pipke http://www.simplemachines.org/community/index.php?action=profile;u=314795
 * @copyright Copyright (C) 2022, Pipke
 * @All rights reserved. 
 * @This SMF modification is subject to the BSD 2-Clause License
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

$txt['adi_settings_title'] = 'Avatar weergave integratie';
$txt['adi_layout_title'] = 'Layout van avatars';
$txt['adi_boardindex'] = 'Toon de avatar van de laatste poster op de boardindex';
$txt['adi_message_first'] = 'Toon de avatar van de topicstarter op de ongelezen topics, ongelezen reacties en berichtenlijst';
$txt['adi_message_last'] = 'Toon de avatar van de laatste poster op de ongelezen topics, ongelezen reacties en berichtenlijst';
$txt['adi_topic_header'] = 'Toon de avatar van de topicstarter in de titel van een topic';
$txt['adi_recent_posts'] = 'Toon de avatar van de poster op de lijst recente berichten';
$txt['adi_ic_recent_posts'] = 'Toon avatars bij de recente topics in het info centrum';
$txt['adi_memberlist'] = 'Toon de avatar van de leden in de ledenlijst';
$txt['adi_wholist'] = 'Toon de avatars op de wie is online pagina';
$txt['adi_search_posts'] = 'Toon avatars in de zoekresultaten';
$txt['adi_mentions'] = 'Toon een avatar als je iemand vermeld met @mention in berichten...';
$txt['adi_avatar_shadow'] = 'Voeg een schaduweffect toe aan alle avatars';
$txt['adi_avatar_shape'] = 'Geef alle avatars een ronde vorm';
$txt['adi_avatar_circle'] = 'Rond';
$txt['adi_avatar_square'] = 'Vierkant';
$txt['adi_avatar_curved'] = 'Afgerond';
$txt['adi_log_in'] = 'is online';
$txt['adi_log_un'] = 'is niet ingelogd';
$txt['adi_icon_overlay'] = 'Toon de status als een icoon op de avatar als een gebruiker online is of niet aangemeld...';
$txt['adi_icon_both'] = 'voor beide opties';
$txt['adi_icon_online'] = 'alleen als deze online is';
$txt['adi_none'] = 'niet toepassen';
$txt['adi_mention_before'] = 'voor de @naam link';
$txt['adi_mention_after'] = 'na de @naam link';
$txt['adi_mention_no_name'] = 'en verberg de @naam link';
$txt['adi_icon_shape'] = 'Geef het status icoon een ronde vorm';
$txt['adi_initials'] = 'Vervang de standaard avatar door het initiaal van de weergavenaam';
$txt['adi_view_your_profile'] = 'Bekijk je profiel';
$txt['adi_you_are_logged_in'] = 'Je bent ingelogd';
$txt['adi_unknown_user'] = 'Deze gebruiker met ID:';
$txt['adi_default_avatar'] = 'Standaard avatar';
$txt['adi_initial_avatar'] = 'Initiele avatar';
?>
