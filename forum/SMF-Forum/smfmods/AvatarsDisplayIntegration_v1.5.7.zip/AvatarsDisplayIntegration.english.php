<?php
/*
 * @package Avatars Display Integration
 * @version 1.5.1
 * @author Pipke http://www.simplemachines.org/community/index.php?action=profile;u=314795
 * @copyright Copyright (C) 2022, Pipke
 * @All rights reserved. 
 * @This SMF modification is subject to the BSD 2-Clause License
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

$txt['adi_settings_title'] = 'Avatars Display Integration';
$txt['adi_layout_title'] = 'Layout avatars';
$txt['adi_boardindex'] = 'Display avatar last poster on the Board index';
$txt['adi_message_first'] = 'Display avatar first poster on the Unread, Update and Message index';
$txt['adi_message_last'] = 'Display avatar last poster on the Unread, Update and Message index';
$txt['adi_topic_header'] = 'Display avatar first poster on the Topic title header';
$txt['adi_recent_posts'] = 'Display avatar poster on the Recent posts index';
$txt['adi_ic_recent_posts'] = 'Display avatar poster Recent posts on Info center';
$txt['adi_memberlist'] = 'Display member avatar on the Memberlist page';
$txt['adi_wholist'] = 'Display user avatar on the who\'s online page';
$txt['adi_search_posts'] = 'Display avatar poster of the Search results';
$txt['adi_mentions'] = 'Display avatar when using bbc @mention member in posts...';
$txt['adi_avatar_shadow'] = 'Add some shadow to all avatars';
$txt['adi_avatar_shape'] = 'Avatar layout shape';
$txt['adi_avatar_circle'] = 'Circle';
$txt['adi_avatar_square'] = 'Square';
$txt['adi_avatar_curved'] = 'Curved';
$txt['adi_log_in'] = 'is logged in';
$txt['adi_log_un'] = 'is unauthenticated';
$txt['adi_icon_overlay'] = 'Add connection status as icon overlay on avatar if user is online or unauthenticated...';
$txt['adi_icon_both'] = 'for both options';
$txt['adi_icon_online'] = 'only if logged in';
$txt['adi_none'] = 'please do not';
$txt['adi_mention_before'] = 'before the @name link';
$txt['adi_mention_after'] = 'after the @name link';
$txt['adi_mention_no_name'] = 'and hide the @name link';
$txt['adi_icon_shape'] = 'Set the connection status overlay icon to a circle shape';
$txt['adi_initials'] = 'Overwrite the default avatar with initial of displayname';
$txt['adi_view_your_profile'] = 'View your profile';
$txt['adi_you_are_logged_in'] = 'You are logged in';
$txt['adi_unknown_user'] = 'This user with ID:';
$txt['adi_default_avatar'] = 'Default avatar';
$txt['adi_initial_avatar'] = 'Initial avatar';
?>
