<?php
/*
 * @package Avatars Display Integration
 * @version 1.1
 * @author Pipke http://www.simplemachines.org/community/index.php?action=profile;u=314795
 * @copyright Copyright (C) 2020, Pipke
 * @All rights reserved. 
 * @This SMF modification is subject to the BSD 2-Clause License
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * Spanish translation https://www.bombercode.net Copyright 2014-2020
 */

$txt['adi_settings_title'] = 'Integración de avatares';
$txt['adi_layout_title'] = 'Avatares de diseño';
$txt['adi_boardindex'] = 'Mostrar avatar con la última respuesta en las secciones del foro';
$txt['adi_message_first'] = 'Mostrar avatar de autor de hilo en publicaciones y temas no leídos con respuestas no leídas';
$txt['adi_message_last'] = 'Mostrar avatar con la última respuesta en mensajes no leídos y temas con respuestas no leídas';
$txt['adi_topic_header'] = 'Mostrar avatar del autor en el título del tema';
$txt['adi_recent_posts'] = 'Mostrar avatar en publicaciones recientes';
$txt['adi_memberlist'] = 'Mostrar avatar del usuario en la página de la lista de usuarios';
$txt['adi_wholist'] = 'Mostrar el avatar del usuario en la página de quién está en línea';
$txt['adi_search_posts'] = 'Mostrar avatar en el resultado de búsqueda';
$txt['adi_mentions'] = 'Mostrar avatar cuando un participante usa el código bbc @mencionar miembro en los mensajes...';
$txt['adi_avatar_shadow'] = 'Agrega algo de sombra a todos los avatares';
$txt['adi_avatar_shape'] = 'Establecer todos los avatares en forma de círculo';
$txt['adi_log_in'] = 'está conectado';
$txt['adi_log_un'] = 'desconectado';
$txt['adi_icon_overlay'] = 'Agregue el estado de conexión como superposición en el avatar si el usuario está en línea o no...';
$txt['adi_icon_both'] = 'para ambas opciones';
$txt['adi_icon_online'] = 'solo si ha iniciado sesión';
$txt['adi_none'] = 'por favor no lo hagas';
$txt['adi_mention_before'] = 'antes del enlace del @nombre';
$txt['adi_mention_after'] = 'después del enlace del @nombre';
$txt['adi_mention_no_name'] = 'y oculta el enlace del @nombre';
$txt['adi_icon_shape'] = 'Establecer que el icono de estado de conexión sea redondo';
$txt['adi_initials'] = 'Sobrescribe el avatar predeterminado con la inicial del nombre para mostrar';
$txt['adi_view_your_profile'] = 'Ver perfil';
$txt['adi_you_are_logged_in'] = 'Estás conectado';
$txt['adi_unknown_user'] = 'Usuario ID:';
?>