<?php
/*
 * @package Avatars Display Integration
 * @versão 1.5.5
 * @author Pipke http://www.simplemachines.org/community/index.php?action=profile;u=314795
 * @copyright Copyright (C) 2022, Pipke
 * @Todos os direitos reservados. 
 * @Esta modificação SMF está sujeita à BSD 2-Licença Cláusula
 *
 * A redistribuição e o uso em formato fonte e binário, com ou sem modificação, são permitidos desde que sejam atendidas as seguintes condições:
 * 1. As redistribuições do código-fonte devem manter o aviso de direitos autorais acima, esta lista de condições e o aviso de isenção de responsabilidade a seguir.
 * 2. As redistribuições em formato binário devem reproduzir o aviso de direitos autorais acima, esta lista de condições e a seguinte isenção de responsabilidade na documentação e/ou outros materiais fornecidos com a distribuição.
 * ESTE SOFTWARE É FORNECIDO PELOS DETENTORES DOS DIREITOS AUTORAIS E COLABORADORES "COMO ESTÁ" E QUAISQUER GARANTIAS EXPRESSAS OU IMPLÍCITAS, INCLUINDO, MAS NÃO
 * LIMITADO A, AS GARANTIAS IMPLÍCITAS DE COMERCIALIZAÇÃO E ADEQUAÇÃO PARA UM FIM ESPECÍFICO SÃO REJEITADAS. EM NENHUM CASO OS DIREITOS AUTORAIS
 * O TITULAR OU OS COLABORADORES SERÃO RESPONSÁVEIS POR QUAISQUER DANOS DIRETOS, INDIRETOS, INCIDENTAIS, ESPECIAIS, EXEMPLARES OU CONSEQUENTES (INCLUINDO, MAS NÃO
 * LIMITADO À AQUISIÇÃO DE BENS OU SERVIÇOS SUBSTITUTOS; PERDA DE USO, DADOS OU LUCROS; OU INTERRUPÇÃO DE NEGÓCIOS) DE QUALQUER CAUSA E SOBRE
 * QUALQUER TEORIA DE RESPONSABILIDADE, SEJA EM CONTRATO, RESPONSABILIDADE ESTRITA OU ILÍCITO (INCLUINDO NEGLIGÊNCIA OU DE OUTRA FORMA) DECORRENTE DE QUALQUER FORMA DO USO
 * DESTE SOFTWARE, MESMO SE AVISADO DA POSSIBILIDADE DE TAIS DANOS.
 */

$txt['adi_settings_title'] = 'Integração de Avatares';
$txt['adi_layout_title'] = 'Opções do avatar';
$txt['adi_boardindex'] = 'Exibir o avatar na última resposta do quadro';
$txt['adi_message_first'] = 'Exiba o avatar  do autor da postagem em Mensagens não lidas e Tópicos atualizados';
$txt['adi_message_last'] = 'Exiba o avatar da última resposta em Mensagens não lidas e Tópicos atualizados';
$txt['adi_topic_header'] = 'Exibir o avatar do autor no título do tópico';
$txt['adi_recent_posts'] = 'Exibir avatar no índice de postagens recentes';
$txt['adi_ic_recent_posts'] = 'Exibir avatar em Postagens recentes no centro de informações';
$txt['adi_memberlist'] = 'Exibir avatares na página Lista de membros';
$txt['adi_wholist'] = 'Exibir avatar na página Quem está online';
$txt['adi_search_posts'] = 'Exibir avatar nos resultados da pesquisa';
$txt['adi_mentions'] = 'Exibir avatar ao usar bbc @mencionar membro em postagens...';
$txt['adi_avatar_shadow'] = 'Adicione alguma sombra a todos os avatares';
$txt['adi_avatar_shape'] = 'Formato do avatar';
$txt['adi_avatar_circle'] = 'Círculo';
$txt['adi_avatar_square'] = 'Quadrado';
$txt['adi_avatar_curved'] = 'Curvado';
$txt['adi_log_in'] = 'está logado';
$txt['adi_log_un'] = 'não está logado';
$txt['adi_icon_overlay'] = 'Adicionar status de conexão como sobreposição de ícone no avatar se o usuário estiver logado ou não logado...';
$txt['adi_icon_both'] = 'para ambas as opções';
$txt['adi_icon_online'] = 'somente se logado';
$txt['adi_none'] = 'por favor não usar';
$txt['adi_mention_before'] = 'antes do link @name';
$txt['adi_mention_after'] = 'após o link @name';
$txt['adi_mention_no_name'] = 'e ocultar o link @name';
$txt['adi_icon_shape'] = 'Defina o ícone de sobreposição de status de conexão para uma forma de círculo';
$txt['adi_initials'] = 'Substitua o avatar padrão pela letra inicial do nome do usuário';
$txt['adi_view_your_profile'] = 'Veja seu perfil';
$txt['adi_you_are_logged_in'] = 'Você está logado';
$txt['adi_unknown_user'] = 'Este usuário com ID:';
$txt['adi_default_avatar'] = 'avatar padrão';
$txt['adi_initial_avatar'] = 'avatar inicial';
?>
