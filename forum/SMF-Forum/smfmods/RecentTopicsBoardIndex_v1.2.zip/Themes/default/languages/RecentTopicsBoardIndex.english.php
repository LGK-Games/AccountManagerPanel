<?php
/*
 * @package RecentTopicsBoardIndex
 * @version 1.0
 * @Author: Pipke
 * @copyright Copyright (C) 2023, Pipke
 * @All rights reserved. 
 * @This SMF modification is subject to the BSD 2-Clause License
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
$txt['rtbi_title'] = 'Recent Forum Topics'; 
$txt['rtbi_filter_b'] = 'Set forum filter as board'; 
$txt['rtbi_filter_c'] = 'Set forum filter as category'; 
$txt['rtbi_forum_filter'] = 'Forum filter';
$txt['rtbi_forum_filter_board'] = 'Forum Filter Board&#58; ';
$txt['rtbi_forum filter category'] = 'Forum Filter Category&#58; ';
$txt['rtbi_topic_by'] = 'By %1$s %2$s in <em>%3$s</em>';
$txt['rtbi_align_left'] = 'Align left, board right';
$txt['rtbi_align_right'] = 'Align right, board left';
$txt['rtbi_align_top'] = 'Align top, board default';
$txt['rtbi_align_col'] = 'Align top, board 2 column';
$txt['rtbi_topics_page'] = 'Topics per page to 5';
$txt['rtbi_topic_starter_time'] = 'Topic starter time';
$txt['rtbi_topic_legend'] = 'Topic legend';
$txt['rtbi_topic_icons'] = 'Topic icons';
$txt['rtbi_first_poster_avatar'] = 'First poster avatar';
$txt['rtbi_last_poster_avatar'] = 'Last poster avatar';

?>
