<?php
/*
 * @package RecentTopicsBoardIndex
 * @version 1.0
 * @Author: Pipke
 * @copyright Copyright (C) 2023, Pipke
 * @All rights reserved. 
 * @This SMF modification is subject to the BSD 2-Clause License
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
 
$txt['rtbi_title'] = 'Temas recientes del foro'; 
$txt['rtbi_filter_b'] = 'Establecer filtro por foro'; 
$txt['rtbi_filter_c'] = 'Establecer filtro por categoría'; 
$txt['rtbi_forum_filter'] = 'Filtro del foro';
$txt['rtbi_forum_filter_board'] = 'Foro de filtro&#58; ';
$txt['rtbi_forum filter category'] = 'Categoría de filtro&#58; ';
$txt['rtbi_topic_by'] = 'Por %1$s %2$s en <em>%3$s</em>';
$txt['rtbi_align_left'] = 'Alinear a la izquierda, foro a la derecha';
$txt['rtbi_align_right'] = 'Alinear a la derecha, foro a la izquierda';
$txt['rtbi_align_top'] = 'Alinear arriba, foro por defecto';
$txt['rtbi_align_col'] = 'Alinear arriba, foro a 2 columna';
$txt['rtbi_topics_page'] = '5 Temas por página';
$txt['rtbi_topic_starter_time'] = 'Fecha de creación del tema';
$txt['rtbi_topic_legend'] = 'Descripción del tema';
$txt['rtbi_topic_icons'] = 'Icono del tema';
$txt['rtbi_first_poster_avatar'] = 'Avatar del primer mensaje';
$txt['rtbi_last_poster_avatar'] = 'Avatar del último mensaje';

?>
