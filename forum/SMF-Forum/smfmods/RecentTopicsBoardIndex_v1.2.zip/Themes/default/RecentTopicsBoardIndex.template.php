<?php
/*
 * @package RecentTopicsBoardIndex
 * @version 1.0
 * @Author: Pipke
 * @copyright Copyright (C) 2023, Pipke
 * @All rights reserved. 
 * @This SMF modification is subject to the BSD 2-Clause License
 *
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:
 * 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

function template_rtbi_above()
{
	global $rtbi;
	
	echo'<div id="rtbi_'. $rtbi['options']['align'].'">';
	
	template_recenttopics();
}

function template_rtbi_below() 
{
	echo'</div>
	<!-- #rtbi_{align} -->';
}
function template_bi_rtbi_col_lastpost($board)
{
	global $context, $modSettings, $rtbi;
	
	if (!empty($board['last_post']['id']) && $rtbi['AvatarsDisplayIntegration'] && $modSettings['adi_boardindex']) {	
		// Build overlay status
		adi_status_data(null, $board['last_post']['member']['name'], $board['last_post']['member']['id'], $board['css_class']);	
		
		if ($modSettings['adi_initials'] && $board['last_post']['member']['avatar']['url'] == $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true))
			echo '<div class="adi_item_topic_last">'.$context['adi']['open'].'<span '.adi_name2hex2rgb($board['last_post']['member']['name']).' class="avatar" '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($board['last_post']['member']['name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['close'].$context['adi']['iconstatus'].'</div>';
		else
			echo '<div class="adi_item_topic_last">'.$context['adi']['open'].'<img class="avatar" src="'.$board['last_post']['member']['avatar']['href'].' alt="avatar_'.$board['last_post']['member']['name'].'" />'.$context['adi']['close'].$context['adi']['iconstatus'].'</div>';					
	}
	if (!empty($board['last_post']['id']))
		echo '
			<p>', $board['last_post']['last_post_message'], '</p>';
	
}

function template_bi_rtbi_sides_stats($board)
{
	global $txt;

	echo '
		<p>
			<span title="', $board['is_redirect'] ? $txt['redirects'] : $txt['posts'] ,'">', rtbi_thousands_format($board['posts']),'</span>
		</p>';
}

function template_bi_rtbi_sides_info($board)
{
	global $context, $scripturl, $txt, $rtbi;
	
	if ($board['is_redirect']) {
		echo '
			<a href="', $board['href'], '" class="rtbi_redirect_icon"', !empty($board['board_tooltip']) ? ' title="' . $board['board_tooltip'] . '"' : '', '></a>';
	}
	echo '
		<a class="subject mobile_subject" href="', $board['href'], '" id="b', $board['id'], '">
			', $board['name'], '
		</a>';

	// Has it outstanding posts for approval?
	if ($board['can_approve_posts'] && ($board['unapproved_posts'] || $board['unapproved_topics']))
		echo '
		<a href="', $scripturl, '?action=moderate;area=postmod;sa=', ($board['unapproved_topics'] > 0 ? 'topics' : 'posts'), ';brd=', $board['id'], ';', $context['session_var'], '=', $context['session_id'], '" title="', sprintf($txt['unapproved_posts'], $board['unapproved_topics'], $board['unapproved_posts']), '" class="moderation_link amt">!</a>';
}

//Show the recent forum topics.
function template_recenttopics() {
	
	global $context, $txt, $scripturl, $modSettings, $rtbi;
	
	foreach ($context['categories'] as $category) {
		// Categorie filter
		if ($rtbi['options']['forum_filter'] == 'filter_c')
			$context['categories'][$category['id']]['link'] = rtbi_filter_url('filter_c', $category['id']).' '. $category['link'];			
			
		foreach ($category['boards'] as $board) {
			// Boards layout change			
			if ($rtbi['options']['align'] == 'left' || $rtbi['options']['align'] == 'right') 
				$context['categories'][$category['id']]['boards'][$board['id']]['type'] = 'rtbi_sides';
			// Disable board avatar from AvatarsDisplayIntegration mod if align is not top
			if ($rtbi['AvatarsDisplayIntegration'] && $rtbi['options']['align'] !== 'top')
					$context['categories'][$category['id']]['boards'][$board['id']]['css_class'] = false;
						
			if ($rtbi['options']['align'] == 'col') 
				$context['categories'][$category['id']]['boards'][$board['id']]['type'] = 'rtbi_col';			
			// Boards filter 			 
			if ($rtbi['options']['forum_filter'] == 'filter_b' && !$board['is_redirect'])
				$context['categories'][$category['id']]['boards'][$board['id']]['name'].= rtbi_filter_url('filter_b', $board['id']);				
			// Children filter
			foreach ($board['children'] as $child) {
				if ($rtbi['options']['forum_filter'] == 'filter_b' && !$child['is_redirect'])
					$context['categories'][$category['id']]['boards'][$board['id']]['children'][$child['id']]['name'] = rtbi_filter_url('filter_b', $child['id']).' '.$child['link'];					
			}
		}
	}
	
	// Change text 'Sub-Boards' to icon when align is left or right
	if ($rtbi['options']['align'] == 'left' || $rtbi['options']['align'] == 'right') 
		$txt['sub_boards'] = '<span title="'.$txt['sub_boards'].'">&#10551;</span>';
	
	echo '
		<div id="recenttopics_table" class="recenttopics_table ',$rtbi['options']['align'],'">';
		
			// User action pop on mobile screen (or actually small screen), this uses responsive css does not check mobile device.
			if (!empty($context['rtbi_buttons']))
			echo '
				<div id="mobile_action" class="popup_container">
					<div class="popup_window description">
						<div class="popup_heading">
							', $txt['mobile_action'], '
							<a href="javascript:void(0);" class="main_icons hide_popup"></a>
						</div>
						', template_button_strip($context['rtbi_buttons']), '
					</div>
				</div>';
		
			echo '
				<div id="recenttopics" class="main_content">
					<div id="display_head" class="information">
						<h2 class="display_title">
							<span>', $txt['rtbi_title'] ,'</span>
						</h2>
						<span>',template_quickbuttons($rtbi['quickbuttons']),'</span>
					</div>';

			
				echo '
					<div class="pagesection">
					', $context['user']['is_logged'] && !empty($context['categories']) ? template_button_strip($context['rtbi_buttons'], 'right') : '', '
						', $context['menu_separator'], '
						<div class="pagelinks floatleft">
							<a href="#bot" class="button">', $txt['go_down'], '</a>
							', $context['page_index'], '
						</div>';

					// Mobile action (top)
					if (!empty($context['rtbi_buttons']))
						echo '
							<div class="mobile_buttons floatright">
								<a class="button mobile_act">', $txt['mobile_action'], '</a>
							</div>';
				
				echo '
					</div><!-- .pagesection -->';
					

				echo '
					<div id="recentforumtopics">
						<div id="topic_header" class="title_bar">';
						if (empty($context['topics']))
							echo '
								<h3 class="titlebg">', $txt['topic_alert_none'], '</h3>';
						else {
							echo '
							<div class="board_icon', $rtbi['options']['topic_icons'] ? '' : ' icon_off' ,'"></div>
							<div class="info">', $txt['subject'] ,' / ', $txt['started_by'],' / ', $txt['board'],'</div>
							<div class="board_stats centertext">', $txt['replies'] ,' / ', $txt['views'],'</div>
							<div class="lastpost', $rtbi['AvatarsDisplayIntegration'] && $rtbi['options']['last_poster_avatar'] ? '' : ' avatar_off' ,'">', $txt['last_post'] ,'</div>';
						}
					echo '
						</div><!-- #topic_header -->';
					
					if (!empty($context['topics']))	
					{
						echo'		
							<div id="topic_container">';
							// do counter
							$i=0;
							foreach ($context['topics'] as $topic)
							{
								$i++;
							echo '
								<div class="', $topic['css_class'], '">
									<div class="board_icon', $rtbi['options']['topic_icons'] ? '' : ' icon_off' ,'">';
									if ($rtbi['options']['topic_icons']) {
										echo' <img src="', $topic['first_post']['icon_url'], '" alt="">
										', $topic['is_posted_in'] ? '<span class="main_icons profile_sm"></span>' : '';
									}
									echo'</div>';
									if ($rtbi['AvatarsDisplayIntegration'] && $rtbi['options']['first_poster_avatar'])
									{
									  // Build overlay status
									adi_status_data(null, $topic['first_post']['member']['name'], $topic['first_post']['member']['id'], $topic['css_class']);
									
									if ($modSettings['adi_initials'] && $topic['first_post']['member']['avatar']['url'] == $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true))
										echo '<div class="adi_item_topic_first">'.$context['adi']['open'].'<span '.adi_name2hex2rgb($topic['first_post']['member']['name']).' class="avatar" '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($topic['first_post']['member']['name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['close'].$context['adi']['iconstatus'].'</div>';
									else						
										echo '<div class="adi_item_topic_first">'.$context['adi']['open'].'<img class="avatar" src="'.$topic['first_post']['member']['avatar']['href'].' alt="avatar_'.$topic['first_post']['member']['name'].'" />'.$context['adi']['close'].$context['adi']['iconstatus'].'</div>';					
									}
									
									echo '<div class="info">';
									// Now we handle the icons
									echo '<div class="icons floatright">';
										if ($topic['is_locked'])
											echo '<span class="main_icons lock"></span>';
										if ($topic['is_sticky'])
											echo '<span class="main_icons sticky"></span>';
										if ($topic['is_poll'])
											echo '<span class="main_icons poll"></span>';
									echo '
										</div> <!-- .floatright -->
										<div class="recent_title">
										
											', $topic['new'] && $context['user']['is_logged'] ? '<a href="' . $topic['new_href'] . '" id="newicon' . $topic['first_post']['id'] . '" class="new_posts">' . $txt['new'] . '</a>' : '', '
											<span class="preview', $topic['is_sticky'] ? ' bold_text' : '', '" title="', $topic[(empty($modSettings['message_index_preview_first']) ? 'last_post' : 'first_post')]['preview'], '">
												<span id="msg_', $topic['first_post']['id'], '">', $topic['first_post']['link'] ,'</span>
											</span>
										</div> <!-- .recent_title -->
										<p class="floatleft">
											', $topic['first_post']['started_by'], '
										</p>
										', !empty($topic['pages']) ? '<span id="pages' . $topic['first_post']['id'] . '" class="topic_pages">' . $topic['pages'] . '</span>' : '', '
									</div><!-- .info -->
									<div class="board_stats centertext">
										<p>
											', $topic['replies'], ' ', $txt['replies'], '
											<br>
											', $topic['views'], ' ', $txt['views'], '
										</p>
									</div> <!-- .board_stats centertext -->';
									if ($rtbi['AvatarsDisplayIntegration'] && $rtbi['options']['last_poster_avatar']) 
									{
										// Build overlay status
										adi_status_data(null, $topic['last_post']['member']['name'], $topic['last_post']['member']['id'], $topic['css_class']);	
										
										if ($modSettings['adi_initials'] && $topic['last_post']['member']['avatar']['url'] == $modSettings['avatar_url'] . '/default.png" '.adi_avatar_data(true))
											echo '<div class="adi_item_topic_last">'.$context['adi']['open'].'<span '.adi_name2hex2rgb($topic['last_post']['member']['name']).' class="avatar" '.adi_avatar_data(true).'>'.mb_strtoupper(mb_substr($topic['last_post']['member']['name'], 0, 1), 'UTF-8').'</span>'.$context['adi']['close'].$context['adi']['iconstatus'].'</div>';
										else
											echo '<div class="adi_item_topic_last">'.$context['adi']['open'].'<img class="avatar" src="'.$topic['last_post']['member']['avatar']['href'].' alt="avatar_'.$topic['last_post']['member']['name'].'" />'.$context['adi']['close'].$context['adi']['iconstatus'].'</div>';					
									}
								  
									echo'<div class="lastpost">
										', sprintf($txt['last_post_topic'], '<a href="' . $topic['last_post']['href'] . '">' . $topic['last_post']['time'] . '</a>', $topic['last_post']['member']['link']), '
									</div>';
							echo'
								</div><!-- $topic[css_class] end -->';
								if ($i == 5)
									echo'<span id="bot"></span>';
							}

							if (empty($context['topics']))
								echo '
									<div style="display: none;"></div>';

						echo '
							</div><!-- #topic_container -->';						
					}
				echo '
					</div><!-- #recentforumtopics -->';

				echo '
					<div class="pagesection">
					', $context['user']['is_logged'] && !empty($context['categories']) ? template_button_strip($context['rtbi_buttons'], 'right') : '', '
						', $context['menu_separator'], '
						<div class="pagelinks floatleft">
							<a href="#recenttopics" class="button">', $txt['go_up'], '</a>
							', $context['page_index'], '
						</div>';

					// Mobile action (bottom)
					if (!empty($context['rtbi_buttons']))
						echo '
							<div class="mobile_buttons floatright">
								<a class="button mobile_act">', $txt['mobile_action'], '</a>
							</div>';
				
				echo '
					</div><!-- .pagesection -->';
			
			if (empty($context['no_topic_listing']) && $rtbi['options']['legend'])
				template_recenttopic_legend();
			
			echo '
				</div><!-- #recenttopics -->';
	
	echo '
		</div><!-- #recenttopics_table -->';
		
	// Disable smf default mark read button
	$context['mark_read_button'] = array();
}

//Shows a legend for recent forum topic icons.
function template_recenttopic_legend()
{
	global $context, $settings, $txt, $modSettings;

	echo '
	<div class="tborder" id="topic_icons">
		<div class="information">
			<p id="message_index_jump_to"></p>';

	if (empty($context['no_topic_listing']))
		echo '
			<p class="floatleft">', !empty($modSettings['enableParticipation']) && $context['user']['is_logged'] ? '
				<span class="main_icons profile_sm"></span> ' . $txt['participation_caption'] . '<br>' : '', '
				' . ($modSettings['pollMode'] == '1' ? '<span class="main_icons poll"></span> ' . $txt['poll'] . '<br>' : '') . '
				<span class="main_icons move"></span> ' . $txt['moved_topic'] . '<br>
			</p>
			<p>
				<span class="main_icons lock"></span> ' . $txt['locked_topic'] . '<br>
				<span class="main_icons sticky"></span> ' . $txt['sticky_topic'] . '<br>
				<span class="main_icons watch"></span> ' . $txt['watching_topic'] . '<br>
			</p>';

	echo '
		</div><!-- .information -->
	</div><!-- #topic_icons -->';
}

?>