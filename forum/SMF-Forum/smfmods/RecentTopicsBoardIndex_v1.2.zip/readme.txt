[color=red][size=14pt][b]Recent Forum Topics on Board Index[/b][/size][/color] 

[b]For SMF 2.1.x[/b]
[b]Tested only with the SMF default theme![/b]

This mod will add Recent Forum Topics on the Boardindex, it has some options:
[list]
[li]Change on wich side you want it to display[/li]
[li]Filtering the forum topics by selecting categories or boards[/li]
[li]Display posters avatars (Note: this only works if you have the [url="https://custom.simplemachines.org/index.php?mod=4246"]Avatars Display Integration[/url] mod installed)[/li]
[li]More...[/li]
[/list]

[color=red][b][size=12pt]License[/size][/b][/color]
* This SMF modification is subject to the BSD 2-Clause License

[color=red][b][size=12pt]User options[/size][/b][/color]
- Options are available through icons (some are only available when you are logged in!)

[color=red][b][size=12pt]Languages[/size][/b][/color]
- English

[b]Version 1.2 - Mar 15, 2023[/b]
- Fixed the constructpages

[b]Version 1.1 - Feb 11, 2023[/b]
- Fixed undefined array key due php > 8.0
- Added language Spanish/Latin by [url=https://www.simplemachines.org/community/index.php?action=profile;u=322597]Rock Lee[/url]

[b]Version 1.0 - Jan 17, 2023[/b]
- Initial Release