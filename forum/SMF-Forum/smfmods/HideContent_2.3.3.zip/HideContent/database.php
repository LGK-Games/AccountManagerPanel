<?php
/**
 * Hide Content
 *
 * @package SMF
 * @author kelvincool
 * @copyright 2014 kelvincool
 * @license http://creativecommons.org/licenses/by/3.0 CC
 *
 * @version 2.0.0
 */

// If SSI.php is in the same place as this file, and SMF isn't defined, this is being run standalone.
if (!defined('SMF') && file_exists(dirname(__FILE__) . '/SSI.php'))
	require_once(dirname(__FILE__) . '/SSI.php');
// Hmm... no SSI.php and no SMF?
elseif(!defined('SMF'))
	die('<b>Error:</b> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

if ((SMF == 'SSI') && !$user_info['is_admin'])
	die('Admin privileges required.');

///////////////////////////////////////////
db_extend('packages');

global $smcFunc;
$permissions_exist = false;

$request = $smcFunc['db_query']('', '
	SELECT count(id_group) as total
	FROM {db_prefix}board_permissions
	WHERE permission = {string:permission}',
	array(
		'permission' => 'hide_content'
	)
);
$board_permissions_check = $smcFunc['db_fetch_assoc']($request);
$smcFunc['db_free_result']($request);
if (!empty($board_permissions_check)) {
	if ($board_permissions_check['total'] > 0)
	{
		$permissions_exist = true;
	}
}

// default permissions for first install
if (!$permissions_exist)
{
	// Get all the non-postcount based groups except Adminstrator
	$request = $smcFunc['db_query']('', '
		SELECT id_group
		FROM {db_prefix}membergroups
		WHERE min_posts = -1
		AND id_group != 1'
	);
	$board_groups = array();
	$board_groups[] = array('id_group' => 0, 'id_profile' => 1, 'permission' => 'hide_content', 'add_deny' => 1);
	while ($row = $smcFunc['db_fetch_assoc']($request))
	{
		$board_groups[] = array('id_group' => $row['id_group'], 'id_profile' => 1, 'permission' => 'hide_content', 'add_deny' => 1);
	}
	$smcFunc['db_free_result']($request);

	// Insert permission for all groups
	$smcFunc['db_insert']('ignore' ,
		'{db_prefix}board_permissions',
		array(
			'id_group' => 'int', 'id_profile' => 'int', 'permission' => 'string', 'add_deny' => 'int'
		),
		$board_groups,
		array('id_group', 'id_profile', 'permission')
	);
}

if (SMF == 'SSI')
	echo 'Database changes are complete! Please wait...';