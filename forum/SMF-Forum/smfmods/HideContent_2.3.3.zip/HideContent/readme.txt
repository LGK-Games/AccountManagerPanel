[size=16pt]Hide Content[/size]
[hr]

Hide Content provides the ability to hide certain parts of a post based on a number of specified criteria.

[size=14pt]Requirements[/size]

This mod requires PHP 7.4.10 or above.

This mod will not work without Javascript, it has been tested in Firefox 99, Chrome 100.0.4896.127 and IE Edge 101.0.1210.32.

[size=14pt]Out of the Box[/size]

By default, the following plugins are available to use:
[list]
[li]Hide By Post Count - restrict content to be viewable to users who have equal or greater post count required.[/li]
[li]Hide By Login - restrict content to be viewable to logged-in users only.[/li]
[li]Hide By Group - restrict content to be viewable to users belonging to a specified group, please note you can select multiple groups with this plugin, it will act as an OR condition for each group.[/li]
[li]Hide By Liked - restrict content to be viewable to users who like the post.[/li]
[/list]

[size=14pt]Extensible[/size]

This mod is written to be extensible by other mods, the above plugins are all written this way. Writing a plugin for this mod is just a case of implementing some hooks, please see the above plugins for example code.

[url=http://custom.simplemachines.org/mods/index.php?mod=3898]Say Thanks[/url] now supports this mod.

[size=14pt]Additional Notes and known limitations[/size]

[list]
[li]Admins and moderators with required permissions can view any content without restriction[/li]
[li]You cannot quote hidden content[/li]
[li]The hide tag is not designed to be nested inside another hide tag[/li]
[li]The permissions only hides the BBC button, the permissions do not stop the functionality working[/li]
[li]If the original poster does not meet their own requirements they will also not see the content, however they can still edit the post. (only for SMF 2.0.x versions)[/li]
[/list]

[size=14pt]Translation Credits[/size]
Turkish - gevv

[size=14pt]Resource Credits[/size]

[url=https://www.flaticon.com/free-icons/hidden]Hidden icons created by Freepik - Flaticon[/url]
1.x.x Icon courtesy of Yusuke Kamiyamane (http://www.iconfinder.com/icondetails/26317/16/exclamation_eye_view_alert_warning_icon)
1.x.x Base for modal window http://www.the-art-of-web.com/javascript/feedback-modal-window/

[b]Support[/b]

Support for this modification can be found in the support topic.

[hr]
[url=http://creativecommons.org/licenses/by/3.0][img]http://i.creativecommons.org/l/by/3.0/80x15.png[/img][/url]
This work is licensed under a [url=http://creativecommons.org/licenses/by/3.0]Creative Commons Attribution 3.0 Unported License[/url]