<?php
/**
 * Hide Content
 *
 * @package SMF
 * @author kelvincool
 * @copyright 2014 kelvincool
 * @license http://creativecommons.org/licenses/by/3.0 CC
 *
 * @version 2.0.0
 */

// No Direct Access!
if (!defined('SMF'))
	die('Hacking attempt...');

final class HideLogin
{
	public function hooks()
	{
		add_integration_function('integrate_hide_content_plugin_info', __CLASS__ . '::integrateHideContentPluginInfo#', false, __FILE__);
		add_integration_function('integrate_hide_content_implement_parameter', __CLASS__ . '::integrateHideContentImplementParameter#', false, __FILE__);
	}
	
	public function integrateHideContentPluginInfo(&$plugins)
	{
		global $txt;
		$plugins['login'] = array(
			'title' => $txt['hidelogin_title'], 
			'code' => 'login', 
			'default_value' => 1, 
			'description' => $txt['hidelogin_desc'], 
			'evaluate' => __CLASS__ . '::evaluateCondition#',
			'options' => __CLASS__ . '::getOptions#'
		);
	}
	
	public function integrateHideContentImplementParameter(&$parameters)
	{
		$parameters['login'] = array(
			'optional' => true, 
			'match' => '(\d)'
		);
	}
	
	public function evaluateCondition($params)
	{
		global $txt, $user_info, $context, $scripturl;
		$result = '';
		$require_logged_in = intval($params['{login}']) == 1;
		if ($require_logged_in && $user_info["is_guest"])
		{
			$result = strtr($txt['hidelogin_only_for_registered_text'], array(
				'{login_link}' => $scripturl . '?action=login',
				'{register_link}' => $scripturl . '?action=register',
			));
		}
		return $result;
	}
	
	public function getOptions()
	{
		global $txt;
		$options = array(
			'type' => 'hidden', 
			'title' => '', 
			'id' => 'login_input', 
			'default_value' => 1
		);
		return $options;
	}
}