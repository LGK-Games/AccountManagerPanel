<?php
/**
 * Hide Like
 *
 * @package SMF
 * @author kelvincool
 * @copyright 2015 kelvincool
 * @license http://creativecommons.org/licenses/by/3.0 CC
 *
 * @version 2.3.0
 */

// No Direct Access!
if (!defined('SMF'))
	die('Hacking attempt...');

final class HideLike
{
	public function hooks()
	{
		add_integration_function('integrate_hide_content_implement_parameter', __CLASS__ . '::integrateHideContentImplementParameter#', false, __FILE__);
		add_integration_function('integrate_hide_content_plugin_info', __CLASS__ . '::integrateHideContentPluginInfo#', false, __FILE__);
	}

	public function integrateHideContentPluginInfo(&$plugins)
	{
		global $txt;
		$plugins['liked'] = array(
			'title' => $txt['hidelike_title'],
			'code' => 'liked',
			'default_value' => 1,
			'description' => $txt['hidelike_desc'],
			'evaluate' => __CLASS__ . '::evaluateCondition#',
			'options' => __CLASS__ . '::getOptions#'
		);
	}

	public function integrateHideContentImplementParameter(&$parameters)
	{
		$parameters['liked'] = array(
			'optional' => true,
			'match' => '(\d+)'
		);
	}

	public function evaluateCondition($params)
	{
		global $txt, $context;
		$result = '';
		$liked_needed = intval($params['{liked}']);
		if ($liked_needed == 1)
		{
			if (!empty($context['hc_current_post']))
			{
				$id_msg = $context['hc_current_post'];
				if (!self::hasLikedPost($id_msg))
				{
					$result = $txt['hidelike_text'];
				}
			}
			else
			{
				$result = $txt['hidelike_text'];
			}
		}
		return $result;
	}

	public function getOptions()
	{
		global $txt;
		$options = array(
			'type' => 'hidden',
			'title' => '',
			'id' => 'liked_input',
			'default_value' => 1
		);
		return $options;
	}

	private function hasLikedPost($id_msg) : bool
	{
		global $context;
		return (array_key_exists('my_likes', $context) && $context['my_likes'] != null && in_array($id_msg, $context['my_likes'])) || (array_key_exists('hc_is_ajax', $context) && $context['hc_is_ajax'] && self::hasLikedPostInDb($id_msg));
	}

	private function hasLikedPostInDb($id_msg) : bool
	{
		global $smcFunc, $user_info;
		// Do we already like this?
		$request = $smcFunc['db_query']('', '
			SELECT content_id, content_type, id_member
			FROM {db_prefix}user_likes
			WHERE content_id = {int:like_content}
				AND content_type = {string:like_type}
				AND id_member = {int:id_member}',
			array(
				'like_content' => $id_msg,
				'like_type' => 'msg',
				'id_member' => $user_info['id'],
			)
		);
		$alreadyLiked = (bool) $smcFunc['db_num_rows']($request) != 0;
		$smcFunc['db_free_result']($request);
		return $alreadyLiked;
	}
}