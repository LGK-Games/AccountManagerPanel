<?php
/**
 * Hide Content
 *
 * @package SMF
 * @author kelvincool
 * @copyright 2014 kelvincool
 * @license http://creativecommons.org/licenses/by/3.0 CC
 *
 * @version 2.0.0
 */

// No Direct Access!
if (!defined('SMF'))
	die('Hacking attempt...');

final class HidePost
{
	public function hooks()
	{
		add_integration_function('integrate_hide_content_plugin_info', __CLASS__ . '::integrateHideContentPluginInfo#', false, __FILE__);
		add_integration_function('integrate_hide_content_implement_parameter', __CLASS__ . '::integrateHideContentImplementParameter#', false, __FILE__);
	}
	
	public function integrateHideContentPluginInfo(&$plugins)
	{
		global $txt;
		$plugins['post'] = array(
			'title' => $txt['hidepost_title'], 
			'code' => 'post', 
			'default_value' => 1, 
			'description' => $txt['hidepost_desc'], 
			'evaluate' => __CLASS__ . '::evaluateCondition#',
			'options' => __CLASS__ . '::getOptions#'
		);
	}
	
	public function integrateHideContentImplementParameter(&$parameters)
	{
		$parameters['post'] = array(
			'optional' => true,
			'match' => '(\d+)'
		);
	}
	
	public function evaluateCondition($params)
	{
		global $txt, $user_info;
		$result = '';
		$posts_needed = intval($params['{post}']);
		if ($posts_needed > $user_info["posts"] || $user_info["is_guest"])
		{
			$posts_left = $posts_needed - $user_info["posts"];
			$result = strtr($txt['hidepost_text'], array(
				'{posts_needed}' => '<strong>' . $posts_needed . '</strong>',
				'{posts_left}' => '<strong>' . $posts_left . '</strong>',
			));
		}
		return $result;
	}
	
	public function getOptions()
	{
		global $txt;
		$options = array(
			'type' => 'text', 
			'title' => $txt['hidepost_input_title'], 
			'id' => 'post_count', 
			'default_value' => 1, 
			'class' => 'numeric'
		);
		return $options;
	}
}