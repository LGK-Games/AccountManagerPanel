<?php
/**
 * Hide Content
 *
 * @package SMF
 * @author kelvincoool
 * @copyright 2014 kelvincoool
 * @license http://creativecommons.org/licenses/by/3.0 CC
 *
 * @version 2.0.0
 */

// No Direct Access!
if (!defined('SMF'))
	die('Hacking attempt...');

final class HideGroup
{
	public function hooks()
	{
		add_integration_function('integrate_hide_content_plugin_info', __CLASS__ . '::integrateHideContentPluginInfo#', false, __FILE__);
		add_integration_function('integrate_hide_content_implement_parameter', __CLASS__ . '::integrateHideContentImplementParameter#', false, __FILE__);
	}
	
	public function integrateHideContentPluginInfo(&$plugins)
	{
		global $txt;
		$plugins['group'] = array(
			'title' => $txt['hidegroup_title'], 
			'code' => 'group', 
			'default_value' => 1, 
			'description' => $txt['hidegroup_desc'], 
			'evaluate' => __CLASS__ . '::evaluateCondition#',
			'options' => __CLASS__ . '::getOptions#'
		);
	}
	
	public function integrateHideContentImplementParameter(&$parameters)
	{
		$parameters['group'] = array(
			'optional' => true, 
			'match' => '([0-9,]+)'
		);
	}
	
	public function evaluateCondition($params)
	{
		global $txt, $user_info, $smcFunc;
		$result = '';
		$group_ids = explode(',', $params['{group}']);
		foreach($group_ids as $key=>$group_id) {
			$group_ids[$key] = (int) $group_id;
		}
		$common = array_intersect($group_ids, $user_info['groups']);
		if (count($common) == 0)
		{
			$groups_needed = array();
			$query = $smcFunc['db_query']('', '
				SELECT mg.group_name
				FROM {db_prefix}membergroups mg
				WHERE mg.id_group IN ({array_int:group_list})',
				array(
					'group_list' => $group_ids,
				)
			);
			while ($row = $smcFunc['db_fetch_assoc']($query))
			{
				$groups_needed[] = $row['group_name'];
			}
			$smcFunc['db_free_result']($query);
			if (count($groups_needed) > 0)
			{
				$result = strtr($txt['hidegroup_text'], array('{groups_needed}' => '<strong>' . implode(', ', $groups_needed) . '</strong>'));
			}
		}
		return $result;
	}
	
	public function getOptions()
	{
		global $txt, $smcFunc;
		$groups = array();
		$query = $smcFunc['db_query']('', '
			SELECT mg.id_group, mg.group_name
			FROM {db_prefix}membergroups mg',
			array()
		);
		while ($row = $smcFunc['db_fetch_assoc']($query))
		{
			$groups[$row['id_group']] = $row['group_name'];
		}
		$smcFunc['db_free_result']($query);
		$options = array(
			'type' => 'checkbox', 
			'title' => $txt['hidegroup_input_title'], 
			'id' => 'group', 
			'default_value' => array(),
			'options' => $groups
		);
		return $options;
	}
}