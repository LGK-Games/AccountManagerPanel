<?php
/**
 * Hide Content
 *
 * @package SMF
 * @author kelvincool
 * @copyright 2014 kelvincool
 * @license http://creativecommons.org/licenses/by/3.0 CC
 *
 * @version 2.3.3
 */

// No Direct Access!
if (!defined('SMF'))
	die('Hacking attempt...');

final class HideContent
{
	public function hooks()
	{
		add_integration_function('integrate_bbc_codes', __CLASS__ . '::integrateBbcCodes#', false, __FILE__);
		add_integration_function('integrate_bbc_buttons', __CLASS__ . '::integrateBbcButtons#', false, __FILE__);
		add_integration_function('integrate_load_theme', __CLASS__ . '::integrateLoadTheme#', false, __FILE__);
		add_integration_function('integrate_modify_modifications', __CLASS__ . '::integrateModifyModifications#', false, __FILE__);
		add_integration_function('integrate_admin_areas', __CLASS__ . '::integrateAdminAreas#', false, __FILE__);
		add_integration_function('integrate_load_permissions', __CLASS__ . '::integrateLoadPermissions#', false, __FILE__);
		add_integration_function('integrate_sceditor_options', __CLASS__ . '::integrateSceditorOptions#', false, __FILE__);
		add_integration_function('integrate_unpreparsecode', __CLASS__ . '::integrateUnpreparsecode#', false, __FILE__);
		add_integration_function('integrate_pre_parsebbc', __CLASS__ . '::integratePreParsebbc#', false, __FILE__);
		add_integration_function('integrate_prepare_display_context', __CLASS__ . '::integratePrepareDisplayContext#', false, __FILE__);
		add_integration_function('integrate_display_message_list', __CLASS__ . '::integrateDisplayMessageList#', false, __FILE__);
		add_integration_function('integrate_post_start', __CLASS__ . '::integratePostStart#', false, __FILE__);
		add_integration_function('integrate_actions', __CLASS__ . '::integrateActions#', false, __FILE__);
		add_integration_function('integrate_pre_javascript_output', __CLASS__ . '::integratePreJavascriptOutput#', false, __FILE__);
	}

	//integrate_bbc_codes
	public function integrateBbcCodes(&$codes, &$no_autolink_tags)
	{
		global $modSettings, $context;
		if (!array_key_exists('uninstalling', $context)) {
			loadLanguage('HideContent');
			// required for email notifications of replies
			// note: 2nd parameter for css styles not passed as causes issues with error log and is not required anyway
			loadTemplate('HideContent');
		}
		if (!self::checkEnabled())
		{
			return;
		}

		$no_autolink_tags[] = 'hide';

		$parameters = array();

		call_integration_hook('integrate_hide_content_implement_parameter', array(&$parameters));

		// Disable plugins not enabled
		foreach($parameters as $key=>$parameter)
		{
			if (empty($modSettings[$key . '_hidecontent_plugin']))
			{
				// plugin has been disabled but let's just let it pass so we don't get the ugly bbc codes displayed
				$parameters[$key] = array('optional' => true);
			}
		}

		$codes[] = array(
			'tag' => 'hide',
			'type' => 'unparsed_content',
			'parameters' => $parameters,
			'content' => '$1',
			'validate' => function($tag, &$data, $disabled, $params)
			{
				global $context;
				$result = self::evaluateConditions($data, $params);
				if ($result)
				{
					$data = parse_bbc($data, $context['hc_current_post_smileys_enabled'], $context['hc_current_post']);
				}
				else
				{
					return $data;
				}
			}
		);
	}

	//integrate_bbc_buttons
	public function integrateBbcButtons(&$bbcTags, &$editor_tag_map)
	{
		global $txt;

		if (!HideContent::checkEnabled() || HideContent::notAllowedTo())
		{
			return;
		}

		$plugins = self::getPlugins();
		$attributes = "";
		foreach($plugins as $key=>$plugin)
		{
			$attributes .= ' ' . $key . '=' . $plugin['default_value'];
		}
		if ($attributes != "")
		{
			$bbcTags[count($bbcTags)-1][] = array(
				'image' => 'hide',
				'code' => 'hide',
				'description' => $txt['hidecontent_hide']
			);
		}
	}

	//integrate_load_theme
	public function integrateLoadTheme()
	{
		loadLanguage('HideContent',);
		loadTemplate('HideContent', 'hidecontent');
	}

	//integrate_modify_modifications
	public function integrateModifyModifications(&$subActions)
	{
		$subActions['hidecontent'] = [$this, 'settings'];
	}

	public function settings()
	{
		global $txt, $scripturl, $context, $settings, $sc, $modSettings;
		global $smcFunc;
		if (empty($_POST['hc_disable_on_boards']))
		{
			$_POST['hc_disable_on_boards'] = array(-1);
		}
		$plugins = array();
		$config_vars = array();
		call_integration_hook('integrate_hide_content_plugin_info', array(&$plugins));
		foreach($plugins as $key=>$plugin)
		{
			$config_vars[] = array('check', $key . '_hidecontent_plugin', 'label' => $txt['hidecontent_enable_plugin_settings_desc'] . '<b>' . $key . '</b>');
			$config_vars[] = array('check', $key . '_hc_plugin_checked', 'label' => $txt['hidecontent_checked_by_default']);
			$options = self::getPluginsOptions($plugin);
			$default_value = $options['default_value'];
			$default_key = $key . '_hidecontent_plugin_default_value';
			if ($options['type'] == 'text' || $options['type'] == 'select')
			{
				if (!empty($modSettings[$default_key]))
				{
					$default_value = $modSettings[$default_key];
				}
				$default_value_input = array($options['type'], $default_key, 'label' => ' - ' . $txt['hidecontent_admin_default_value'], 'value' => $default_value, 'subtext' => $txt['hidecontent_admin_no_value']);
				if ($options['type'] == 'select')
				{
					$default_value_input[2] = $options['options'];
				}
				$config_vars[] = $default_value_input;
			}
			else if ($options['type'] == 'checkbox')
			{
				$default_value_checkbox = array();
				if (!empty($modSettings[$default_key]))
				{
					$default_value_checkbox = explode(',', $modSettings[$default_key]);
				}
				foreach($options['options'] as $key2=>$option)
				{
					$default_value = '0';
					if (in_array($key2, $default_value_checkbox))
					{
						$default_value = '1';
					}
					$config_vars[] = array('check', $key2 . '_' . $key . '_hidecontent_plugin_default_value', 'label' => ' - ' . $txt['hidecontent_settings_checkbox_default'] . $option, 'checkbox' => 'multiple', 'group' => $default_key, 'checkbox_value' => $key2, 'value' => $default_value);
				}
			}
			$config_vars[] = '';
		}

		$request = $smcFunc['db_query']('', '
				SELECT id_board, name, child_level FROM {db_prefix}boards AS b ORDER BY board_order ASC
		');
		$boards = array();
		$boardsKeys = array(-1 => '');
		while ($row = $smcFunc['db_fetch_assoc']($request))
		{
			$boards[] = array($row['id_board'], str_repeat('&nbsp;&nbsp;', $row['child_level']) . $row['name']);
			$boardsKeys[$row['id_board']] = str_repeat('&nbsp;&nbsp;', $row['child_level']) . $row['name'];
		}

		$smcFunc['db_free_result']($request);
		$disableBoards = array();

		if (!empty($modSettings['hc_disable_on_boards']))
		{
			$disableBoards = json_decode($modSettings['hc_disable_on_boards']);
		}
		$config_vars[] = array('select', 'hc_disable_on_boards', $boardsKeys, 'label' => $txt['hidecontent_disable_on_boards'], 'multiple' => 1, 'data' => $boards, 'value' => $disableBoards, 'name' => 'hc_disable_on_boards[]');

		$context['post_url'] = $scripturl . '?action=admin;area=modsettings;save;sa=hidecontent';
		$context['settings_title'] = $txt['hidecontent_settings'];

		if (empty($config_vars))
		{
			$context['settings_save_dont_show'] = true;
			$context['settings_message'] = '<div class="centertext">' . $txt['modification_no_misc_settings'] . '</div>';

			return prepareDBSettingContext($config_vars);
		}

		// Saving?
		if (isset($_GET['save']))
		{
			checkSession();
			$multiple_checkboxes = array();
			foreach($config_vars as $config_var)
			{
				if (empty($config_var))
					continue;

				if (array_key_exists('checkbox', $config_var) && $config_var['checkbox'] == 'multiple')
				{
					if (!array_key_exists($config_var['group'], $multiple_checkboxes))
					{
						$multiple_checkboxes[$config_var['group']] = $config_var;
						$multiple_checkboxes[$config_var['group']][0] = 'text';
						$multiple_checkboxes[$config_var['group']][1] = $config_var['group'];
					}
					if (!empty($_POST[$config_var[1]]))
					{
						$multiple_checkboxes[$config_var['group']]['array_value'][] = $config_var['checkbox_value'];
					}
					unset($_POST[$config_var[1]]);
				}
				else
				{
					$save_vars[] = $config_var;
				}
			}
			if (!empty($multiple_checkboxes))
			{
				foreach($multiple_checkboxes as $key=>$multiple_checkbox)
				{
					if (!array_key_exists('array_value', $multiple_checkbox))
						continue;

					$multiple_checkbox['value'] = implode(',', $multiple_checkbox['array_value']);
					$_POST[$key] = $multiple_checkbox['value'];
					$save_vars[] = $multiple_checkbox;
				}
			}

			saveDBSettings($save_vars);

			redirectexit('action=admin;area=modsettings;sa=hidecontent');
		}
		prepareDBSettingContext($config_vars);
	}

	//integrate_admin_areas
	public function integrateAdminAreas(&$admin_areas)
	{
		global $txt;
		$admin_areas['config']['areas']['modsettings']['subsections']['hidecontent'] = array($txt['hidecontent_settings']);
	}

	//integrate_load_permissions
	public function integrateLoadPermissions(&$permissionGroups, &$permissionList, &$leftPermissionGroups, &$hiddenPermissions, &$relabelPermissions)
	{
		$permissionList['board']['hide_content'] = array(false, 'post');
	}

	//integrate_sceditor_options
	public function integrateSceditorOptions(&$sce_options)
	{
		global $context, $txt;

		$plugins = self::getPlugins();

		$content = template_hidecontent_panel($plugins);

		$context['bbcodes_handlers'] .= "
			sceditor.command.set('hide', {
				tooltip: 'Hide content in posts',
				exec: function (caller) {
					hideDropdown(caller, this);
				},
				txtExec: function (caller) {
					hideDropdown(caller, this);
				}
			});

			function hideDropdown(caller, editor) {
				var content = $('<div />');

				$(" . JavaScriptEscape($content) . ").appendTo(content);

				editor.createDropDown(caller, 'header-picker', content.get(0));
				$('.hidecontent_option_wrapper').each(function() {
					var pluginName = $(this).children('.hidecontent_plugin_name').val();
					$('#hidecontent_plugin_' + pluginName).on('change', function (e) {
						if (this.checked) {
							$(this).parents('.hidecontent_option_wrapper').find('.hidecontent_option_parameters').slideDown();
							$(this).parents('.hidecontent_option_wrapper').find('.hidecontent_option_parameters input').prop('disabled', false);
						} else {
							$(this).parents('.hidecontent_option_wrapper').find('.hidecontent_option_parameters').slideUp();
							$(this).parents('.hidecontent_option_wrapper').find('.hidecontent_option_parameters input').prop('disabled', true);
						}
					});
				});

				$('#hidecontent_submit_button').on('click', function (e) {
					var parameter = '';
					var checkedList = []
					$('.hidecontent_option_wrapper').each(function() {
						var pluginName = $(this).children('.hidecontent_plugin_name').val();
						var pluginChecked = $(this).find('#hidecontent_plugin_' + pluginName + ':checked').length;
						if (pluginChecked > 0) {
							parameter += ' ' + pluginName + '=';
							if (pluginName == 'login') {
								parameter += '1';
							} else if ($(this).find('.hidecontent_multiple_checkboxes').length > 0) {
								$(this).find('.hidecontent_multiple_checkboxes input:checked').each(function() {
									checkedList.push($(this).val());
								});
								parameter += checkedList.join(',');
							} else if ($(this).find('.input_text').length > 0) {
								parameter += $(this).find('.input_text').val();
							}
						}
					});
					editor.insert('[hide' + parameter + ']', '[/hide]');
					editor.closeDropDown(true);
					e.preventDefault();
				})
			}";
		if (!empty($_REQUEST['quote']))
		{
			$message = $context['controls']['richedit']['message']['value'];
			$message = parse_bbc($message, false, '', array('hide'));
			$message = strtr($message, array('<br>' => "\n"));
			$context['controls']['richedit']['message']['value'] = $message;
			$context['controls']['richedit']['message']['rich_value'] = $message;
		}
	}

	//integrate_unpreparsecode
	public function integrateUnpreparsecode(&$message)
	{
		if (!empty($_REQUEST['quote']) && !isset($_REQUEST['modify']))
		{
			$message = parse_bbc($message, false, '', array('hide'));
		}
	}

	//integrate_pre_parsebbc
	public function integratePreParsebbc(&$message, &$smileys, &$cache_id, &$parse_tags)
	{
		global $context;
		$context['hc_current_post'] = $cache_id;
		$context['hc_current_post_smileys_enabled'] = $smileys;
	}

	//integrate_prepare_display_context
	public function integratePrepareDisplayContext(&$output, &$message, $counter)
	{
		global $context;
		unset($context['hc_current_post']);
		unset($context['hc_current_post_smileys_enabled']);
	}

	//integrate_display_message_list
	public function integrateDisplayMessageList(&$messages, &$posters)
	{
		global $context, $smcFunc;
		$context['hc_post_authors'] = array();
		$request = $smcFunc['db_query']('', '
			SELECT id_msg, id_member
			FROM {db_prefix}messages
			WHERE id_msg IN ({array_int:post_ids})',
			array(
				'post_ids' => $messages,
			)
		);
		while ($row = $smcFunc['db_fetch_assoc']($request))
		{
			if (!empty($row['id_member']))
				$context['hc_post_authors'][$row['id_msg']] = $row['id_member'];
		}
		$smcFunc['db_free_result']($request);
	}

	//integrate_post_start
	public function integratePostStart()
	{
		global $context, $topic, $smcFunc;
		$context['hc_post_authors'] = array();
		if (isset($_REQUEST['xml']))
			$limit = '
			LIMIT ' . (empty($context['new_replies']) ? '0' : $context['new_replies']);
		else
			$limit = empty($modSettings['topicSummaryPosts']) ? '' : '
			LIMIT ' . (int) $modSettings['topicSummaryPosts'];

		$request = $smcFunc['db_query']('', '
			SELECT id_msg, id_member
			FROM {db_prefix}messages
			WHERE id_topic = {int:current_topic}
			ORDER BY id_msg DESC' . $limit,
			array(
				'current_topic' => $topic,
			)
		);
		while ($row = $smcFunc['db_fetch_assoc']($request))
		{
			$context['hc_post_authors'][$row['id_msg']] = $row['id_member'];
		}
		$smcFunc['db_free_result']($request);
	}

	//integrate_actions
	public function integrateActions(&$actionArray)
	{
		$actionArray['hide_content_refresh'] = array('HideContent.php', 'HideContent::getPostContent#');
	}

	public function getPostContent()
	{
		global $context;
		$id = $_REQUEST['id'];
		$context['hc_current_post'] = $id;
		$context['hc_is_ajax'] = true;

		try
		{
            if (@include_once('SSI.php'))
            {
            	$posts = ssi_fetchPosts(array($id), false, "array");
				if (empty($posts))
				{
					obExit(false);
					return;
				}
				$post = $posts[$id];
				header('Content-Type: text/html; charset=UTF-8');
				echo $post['body'];
            }
            obExit(false);
			return;
        }
        catch(Exception $e) {
        	obExit(false);
            return;
        }
	}

	//integrate_pre_javascript_output
	public function integratePreJavascriptOutput(&$do_deferred)
	{
		global $context, $settings;
		if (file_exists($settings['default_theme_dir'] . '/scripts/hidecontent.js'))
		{
			$seed = array_key_exists('browser_cache', $context) ? $context['browser_cache'] : '';
			$context['javascript_files']['hide_content_js'] = array(
				'fileUrl' => $settings['default_theme_url'] . '/scripts/hidecontent.js',
				'filePath' => $settings['default_theme_dir'] . '/scripts/hidecontent.js',
				'options' => array(
					'minimize' => true,
					'seed' => $seed,
				),
				'mtime' => @filemtime($settings['default_theme_dir'] . '/scripts/hidecontent.js'),
			);
		}
	}

	public function evaluateConditions(&$data, $params)
	{
		global $txt, $context, $messages_request, $smcFunc;
		$results = array();
		$errorMessage = '';
		$canModify = false;
		$plugins = self::getPlugins();
		foreach($plugins as $key=>$plugin)
		{
			$result = '';
			if (!empty($params['{' . $plugin['code'] . '}']))
			{
				$callable_task = call_helper($plugin['evaluate'], true);
				if (!empty($callable_task))
				{
					$result = call_user_func($callable_task, $params);
				}
			}
			if (!empty($result))
			{
				$results[$plugin['code']] = $result;
			}
		}
		// handle quoting
		if (isset($_REQUEST['quote']))
		{
			$data = $txt['hidecontent_quote_hidden'];
			return false;
		}
		// check if admin/mod or owner
		$canView = self::checkPermission();
		if (count($results) > 0 && !$canView)
		{
			$errorMessage = template_hidecontent_error_wrapper($results);
			$data = $errorMessage;
			return false;
		}
		$data = template_hidecontent_wrapper($data);
		return true;
	}

	public static function getPlugins()
	{
		global $modSettings;
		$plugins = array();
		call_integration_hook('integrate_hide_content_plugin_info', array(&$plugins));
		foreach($plugins as $key=>$plugin)
		{
			if (empty($modSettings[$key . '_hidecontent_plugin']))
			{
				unset($plugins[$key]);
			}
		}
		return $plugins;
	}

	public static function getPluginsOptions($plugin)
	{
		global $modSettings;
		$options = array();
		$callable_task = call_helper($plugin['options'], true);
		if (!empty($callable_task))
		{
			$options = call_user_func($callable_task);
		}
		$default_key = $plugin['code'] . '_hidecontent_plugin_default_value';
		if (!empty($modSettings[$default_key]) && !empty($options))
		{
			if ($options['type'] == 'checkbox')
			{
				if ($modSettings[$default_key])
				{
					$options['default_value'] = explode(',', $modSettings[$default_key]);
				}
			}
			else
			{
				$options['default_value'] = $modSettings[$default_key];
			}
		}
		return $options;
	}

	public function checkPermission() : bool
	{
		global $context;
		return (allowedTo('moderate_board')
			|| allowedTo('modify_any')
			|| (allowedTo('modify_replies') && !empty($context['user']['started']))
			|| (array_key_exists('hc_post_authors', $context) && array_key_exists($context['hc_current_post'], $context['hc_post_authors']) && $context['hc_post_authors'][$context['hc_current_post']] == $context['user']['id']));
	}

	public function checkEnabled() : bool
	{
		global $context, $modSettings;

		// handle topic page, reply and new topic
		if (!empty($context['current_board']))
		{
			if (!empty($modSettings['hc_disable_on_boards']))
			{
				$boardsDisabled = json_decode($modSettings['hc_disable_on_boards']);
				if (in_array($context['current_board'], $boardsDisabled))
				{
					return false;
				}
			}
		}

		// let it through on any other page like rss, recent posts, profile, etc...
		return true;
	}

	public function notAllowedTo() : bool
	{
		global $context;
		// not allowed to hide content and post page or viewing a topic
		return !allowedTo('hide_content') || !($context['current_action'] == 'post' || $context['current_action'] == 'post2' || !empty($context['topicinfo']));
	}
}