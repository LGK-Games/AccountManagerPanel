/**
 * Hide Content
 *
 * @package SMF
 * @author kelvincool
 * @copyright 2015 kelvincool
 * @license http://creativecommons.org/licenses/by/3.0 CC
 *
 * @version 2.3.0
 */

$(document).ready(function(){
	$(document).on("ajaxSuccess", function(event, request, settings) {
		if (settings.url.indexOf("?action=likes;ltype=msg;sa=like;") >= 0 || settings.url.indexOf("/likes/?ltype=msg;sa=like;") >= 0) {
			var m = settings.url.match(/ltype=msg;sa=like;like=([0-9]+)/);
			var id_msg = m[1];
			if ($('#msg_' + id_msg).find('.hidecontent_liked_wrapper').length) {
				$.ajax({
					type: 'GET',
					contentType: 'text/html',
					url: '?action=hide_content_refresh&id=' + id_msg,
					success: function ( data ) {
						if (data !== '') {
							var msgPost = $('#msg_' + id_msg);
							msgPost.html(data);
							var msgPostTopReply = $('#msg_' + id_msg + '-top-reply');
							if (msgPostTopReply.length) {
								msgPostTopReply.html(data);
							}
						}
					}
				});
				}
			return false;
		}
	});
});