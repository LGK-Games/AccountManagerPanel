<?php
/**
 * Hide Content
 *
 * @package SMF
 * @author kelvincool
 * @copyright 2014 kelvincool
 * @license http://creativecommons.org/licenses/by/3.0 CC
 *
 * @version 2.3.0
 */

function template_hidecontent_wrapper($data)
{
	global $txt;
	$content = '<div class="infobox">' . $data . '</div>';
	return $content;
}

function template_hidecontent_error_wrapper($results)
{
	global $txt;
	$errorMessage = '<div class="errorbox"><h6>' . $txt['hidecontent_required_conditions'] . '</h6><ul>';
	foreach($results as $plugin=>$result) {
		$errorMessage .= '<li class="hidecontent_' . $plugin . '_wrapper">' . $result . '</li>';
	}
	$errorMessage .= '</ul></div>';
	return $errorMessage;
}

function template_hidecontent_panel($plugins)
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

	$content = '
			 <div>
				<form id="hidecontent_form" method="post" action="#" accept-charset="UTF-8">
					<div>
';
	$i = 0;
	foreach($plugins as $key=>$plugin)
	{
		$order = $i%2 == 0 ? 'even' : 'odd';
		$content .= template_hidecontent_option($key, $plugin, $order);
		$i++;
	}
	$content .= '
					</div>
					<div id="hidecontent_submit"><input id="hidecontent_submit_button" class="button" type="submit" name="hidecontent_submit" value="'. $txt['hidecontent_apply'] .'" /></div>
				</form>
			</div>';
	return $content;
}

function template_hidecontent_option($key, $plugin, $order)
{
	global $modSettings;
	$checkedByDefault = ' ';
	$disabled = ' disabled';
	$hideOptions = ' hidecontent_hidden_options';
	if (!empty($modSettings[$key . '_hc_plugin_checked']))
	{
		$checkedByDefault = 'checked="checked" ';
		$disabled = ' ';
		$hideOptions = ' ';
	}
	$modal = '
						<div class="hidecontent_panel">
							<div class="hidecontent_option_wrapper '. $order .'">
								<input class="hidecontent_plugin_name" type="hidden" value="'. $plugin['code'] .'" name="hidecontent_plugin_name_'. $plugin['code'] .'" />

								<label for="hidecontent_plugin_post" class="hidecontent_plugin_label">
									<input id="hidecontent_plugin_'. $plugin['code'] .'" class="input_check" type="checkbox" value="1"'. $checkedByDefault .'name="hidecontent_plugin" />
									<span class="input_check_label">'. $plugin['title'] .'</span>
								</label>
								<div class="hidecontent_option_parameters' . $hideOptions . '">';
	$options = HideContent::getPluginsOptions($plugin);
	if ($options['type'] == 'text')
	{
		$modal .= '
										<div>
											<input' . $disabled . ' id="hidecontent_plugin_input_'. $options['id'] .'" class="input_text '. $options['class'] .'" type="text" value="'. $options['default_value'] .'" name="hidecontent_plugin_input_'. $options['id'] .'" />
										</div>';
	}
	else if ($options['type'] == 'hidden')
	{
		$modal .= '
									<input id="hidecontent_plugin_input_'. $options['id'] .'" class="input_text" type="hidden" value="'. $options['default_value'] .'" name="hidecontent_plugin_input_'. $options['id'] .'" />';
	}
	else if ($options['type'] == 'select')
	{
		$modal .= '
									<fieldset class="parameter_options_wrapper">
										<div>
											<select' . $disabled . ' id="hidecontent_plugin_input_'. $options['id'] .'" class="input_select" value="'. $options['default_value'] .'" name="hidecontent_plugin_input_'. $options['id'] .'">';
		foreach($options['options'] as $key=>$option)
		{
			$modal .= '
												<option value="'. $key .'">'. $option .'</option>';
		}
		$modal .= '
											</select>
										</div>
									</fieldset>';
	}
	else if ($options['type'] == 'checkbox')
	{
		$modal .= '
									<fieldset class="parameter_options_wrapper">
										<div class="hidecontent_multiple_checkboxes">';
		$i = 0;
		$checked = '';
		foreach($options['options'] as $key=>$option)
		{
			if ($key == $options['default_value'] || in_array($key, $options['default_value']))
			{
				$checked = ' checked="checked"';
			}
			$modal .= '
											<div>

												<label for="hidecontent_plugin_input_'. $plugin['code'] .'_option_'. $i .'">
												<input' . $disabled . ' id="hidecontent_plugin_input_'. $plugin['code'] .'_option_'. $i .'" class="input_check" type="checkbox" value="'. $key .'"'. $checked .' name="hidecontent_plugin_'. $plugin['code'] .'_options" />
												<span class="hidecontent_input_check_label">'. $option .'</span></label>
											</div>';
			$checked = '';
			$i++;
		}
		$modal .= '
										</div>
									</fieldset>';
	}
	$modal .= '
								</div>
							</div>
						</div>
					';
	return $modal;
}
?>