<?php
// Version: 2.3.0; Hide Content

$txt['hidecontent_required_conditions'] = 'You require the following to view this post content: ';
$txt['hidecontent_hide'] = 'Hide content in posts';
$txt['hidepost_title'] = 'Hide by post count';
$txt['hidepost_text'] = 'You require a post count of at least {posts_needed}, you need another {posts_left} posts.';
$txt['hidepost_desc'] = 'Hides post content based on post count.';
$txt['hidepost_input_title'] = 'Minimum post count';
$txt['hidelogin_title'] = 'Hide by login';
$txt['hidelogin_only_for_registered_text'] = 'You need to log in to view this content, please <a href="{login_link}">login</a> or <a href="{register_link}">register</a>.';
$txt['hidelogin_desc'] = 'Hides post content based on whether user is logged in.';
$txt['hidegroup_title'] = 'Hide by group';
$txt['hidegroup_text'] = 'You need to be a member of one of the following groups: {groups_needed}.';
$txt['hidegroup_desc'] = 'Hides post content based on group.';
$txt['hidelike_title'] = 'Hide by liked';
$txt['hidelike_text'] = 'You must like this post to see the content.';
$txt['hidelike_desc'] = 'Hides post content based on like.';
$txt['hidegroup_input_title'] = 'Group';
$txt['hidecontent_enable_plugin_settings_desc'] = 'Enable the plugin: ';
$txt['hidecontent_settings'] = "Hide Content";
$txt['hidecontent_error_1'] = "%field must be numeric only";
$txt['hidecontent_error_2'] = "%field is required";
$txt['hidecontent_error_3'] = "At least one option is required";
$txt['hidecontent_apply'] = "Apply";
$txt['hidecontent_admin_default_value'] = 'Default value';
$txt['hidecontent_admin_no_value'] = 'If you enter 0 or no value, the default value from the plugin will be used';
$txt['hidecontent_settings_checkbox_default'] = 'Default for option ';
$txt['hidecontent_quote_hidden'] = 'This content is hidden and cannot be quoted.';
$txt['hidecontent_disable_on_boards'] = 'Disable on individual boards';
$txt['hidecontent_checked_by_default'] = 'Checked by default';
$txt['permissionname_hide_content'] = 'Hide content';
$txt['permissionhelp_hide_content'] = 'This permissions allows user to use the hide content tag';
?>