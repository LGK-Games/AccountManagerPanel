<?php
// Version: 2.0.0; Hide Content

$txt['hidecontent_required_conditions'] = 'Bu iletinin içeriğini görüntülemek için aşağıdakilere ihtiyacınız var: ';
$txt['hidecontent_hide'] = 'İletilerdeki içeriği gizle';
$txt['hidepost_title'] = 'Mesaj sayısına göre gizle';
$txt['hidepost_text'] = 'Konuda {posts_needed} iletiye ihtiyacınız var, başka bir konuda {posts_left} iletiye ihtiyacınız var.';
$txt['hidepost_desc'] = 'İleti içeriğine göre ileti içeriğini gizler.';
$txt['hidepost_input_title'] = 'Minimum ileti sayısı';
$txt['hidelogin_title'] = 'Giriş yapmayanlardan gizle';
$txt['hidelogin_only_for_registered_text'] = 'Bu içeriği görüntülemek için giriş yapmalısınız, lütfen <a href="{login_link}">giriş yapın</a> veya <a href="{register_link}">kaydolun</a>.';
$txt['hidelogin_desc'] = 'Kullanıcının oturum açıp açmadığına bağlı olarak ileti içeriğini gizler.';
$txt['hidegroup_title'] = 'Gruba göre gizle';
$txt['hidegroup_text'] = 'Gruplardan birinin üyesi olmanız gerekir: {groups_needed}.';
$txt['hidegroup_desc'] = 'Gruba göre ileti içeriğini gizler.';
$txt['hidegroup_input_title'] = 'Grup';
$txt['hidecontent_enable_plugin_settings_desc'] = 'Eklentiyi etkinleştir: ';
$txt['hidecontent_settings'] = "İçeriği gizle";
$txt['hidecontent_error_1'] = "%field sadece sayısal olmalı";
$txt['hidecontent_error_2'] = "%field gereklidir";
$txt['hidecontent_error_3'] = "En az bir seçenek gerekli";
$txt['hidecontent_apply'] = "Uygula";
$txt['hidecontent_admin_default_value'] = 'Varsayılan değer';
$txt['hidecontent_admin_no_value'] = '0 girerseniz veya hiç değer girmezseniz, eklentinin varsayılan değeri kullanılacaktır.';
$txt['hidecontent_settings_checkbox_default'] = '';
$txt['hidecontent_quote_hidden'] = 'Bu içerik gizlidir ve alıntı yapılamaz.';
$txt['hidecontent_disable_on_boards'] = 'İçerik gizlemenin kapalı olacağı bölümleri seçin';
$txt['hidecontent_checked_by_default'] = 'Varsayılan olarak işaretli';
$txt['permissionname_hide_content'] = 'İçeriği gizle';
$txt['permissionhelp_hide_content'] = 'Bu izinler, kullanıcının içerik gizle etiketini kullanmasına izin verir.';
?>