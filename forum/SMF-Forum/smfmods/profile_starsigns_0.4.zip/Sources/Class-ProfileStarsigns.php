<?php

/**
 * Class-ProfileStarsigns.php
 *
 * @package Profile Starsigns
 * @link https://custom.simplemachines.org/mods/index.php?mod=3272
 * @author Bugo https://dragomano.ru/mods/profile-starsigns
 * @copyright 2011-2023 Bugo
 * @license https://opensource.org/licenses/MIT The MIT License
 *
 * @version 0.4
 */

if (!defined('SMF'))
	die('No direct access...');

class ProfileStarsigns
{
	public function hooks(): void
	{
		add_integration_function('integrate_credits', __CLASS__ . '::credits#', false, __FILE__);
		add_integration_function('integrate_member_context', __CLASS__ . '::memberContext#', false, __FILE__);
	}

	public function credits(): void
	{
		global $context;

		$context['credits_modifications'][] = '<a href="https://www.iconarchive.com/show/onebit-4-icons-by-icojam.html" target="_blank" rel="noopener">Onebit 4 Icons Pack</a> | Licensed under <a href="https://creativecommons.org/publicdomain/zero/1.0/" target="_blank" rel="noopener">the CC0 1.0 Universal</a>';
	}

	public function memberContext(&$memberContext, $user): void
	{
		global $memberContext;

		if (empty($memberContext[$user]['birth_date']) || $memberContext[$user]['birth_date'] == '1004-01-01')
			return;

		$custom_field = array(
			array(
				'col_name'  => 'zodiak_sign',
				'value'     => self::getZodiak($memberContext[$user]['birth_date']),
				'placement' => '1'
			)
		);

		$memberContext[$user]['custom_fields'] = isset($memberContext[$user]['custom_fields']) ? array_merge($memberContext[$user]['custom_fields'], $custom_field) : $custom_field;
	}

	private function getZodiak($birth_date): string
	{
		global $txt, $settings;

		loadLanguage('ProfileStarsigns');

		$day = str_replace('-', '', substr($birth_date, 5));

		$zodiak = array(
			'ot' => array('0120','0219','0321','0421','0521','0622','0723','0823','0923','1024','1123','1222','0101'),
			'do' => array('0218','0320','0420','0520','0621','0722','0822','0922','1023','1122','1221','1231','0119'),
			'zn' => $txt['zodiak_set'],
			'im' => array('aquarius','pisces','aries','taurus','gemini','cancer','leo','virgo','libra','scorpio','sagittarius','capricorn','capricorn')
		);

		$i = 0;
		while (empty($znak) && ($i < 13)) {
			$znak = (($zodiak['ot'][$i] <= $day) && ($zodiak['do'][$i] >= $day)) ? $zodiak['zn'][$i] : null;
			++$i;
		}

		$result = !empty($znak) ? '<img src="' . $settings['default_theme_url'] . '/images/starsigns/' . $zodiak['im'][$i-1] . '.png" width="48" height="48" alt="" title="' . $znak . '">' : '';

		return $result;
	}
}
