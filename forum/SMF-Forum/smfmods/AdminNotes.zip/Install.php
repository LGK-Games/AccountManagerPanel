<?php

// If we have found SSI.php and we are outside of SMF, then we are running standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
{
	$ssi = true;
	require_once(dirname(__FILE__) . '/SSI.php');
}

// If we are outside SMF and can't find SSI.php, then throw an error
elseif (!defined('SMF'))
	exit('<strong>Error:</strong> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

global $smcFunc;

if (!isset($smcFunc['db_create_table']))
	db_extend('packages');

$tables = array(
	'admin_notes' => array(
		'columns' => array(
			array(
				'name' => 'note_id',
				'type' => 'int',
				'size' => '10',
				'null' => false,
				'unsigned' => true,
				'auto' => true,
			),
			array(
				'name' => 'admin_id',
				'type' => 'mediumint',
				'size' => '8',
				'unsigned' => true,
			),
			array(
			   'name' => 'note_time',
			    'type' => 'int',					
			    'size' => '10',
			    'default' => '0',	
	        ),
		    array(
			   'name' => 'note', 
			   'type' => 'text', 
			),
		),
		'indexes' => array(
			array(
				'type' => 'primary',
				'columns' => array('note_id'),
			),
		),
	),
);

foreach ($tables as $table_name => $data)
	$smcFunc['db_create_table']('{db_prefix}' . $table_name, $data['columns'], $data['indexes']);
	   
if (!empty($ssi))
	echo 'Congratulations! You have successfully installed this mod!';	   