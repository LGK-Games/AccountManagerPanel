<?php

// If we have found SSI.php and we are outside of SMF, then we are running standalone.
if (file_exists(dirname(__FILE__) . '/SSI.php') && !defined('SMF'))
{
	$ssi = true;
	require_once(dirname(__FILE__) . '/SSI.php');
}

// If we are outside SMF and can't find SSI.php, then throw an error.	
elseif (!defined('SMF'))
	exit('<strong>Error:</strong> Cannot install - please verify you put this in the same place as SMF\'s index.php.');

//Run hook functions.
$hook_functions = array(
	'integrate_pre_include' => '$sourcedir/Subs-AdminNotes.php',
	'integrate_admin_areas' => 'admin_notes_admin_areas',
);

if (!empty($context['uninstalling']))
	$call = 'remove_integration_function';
else
	$call = 'add_integration_function';

foreach ($hook_functions as $hook => $function)
	$call($hook, $function);			

if (!empty($ssi))
	echo 'Congratulations! You have successfully installed this mod!';