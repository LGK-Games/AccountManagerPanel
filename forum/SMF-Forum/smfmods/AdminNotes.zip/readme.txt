This mod will give the admins the oppurtunity to add notes in the admin panel. This mod is released under Mozilla Public License
. Enjoy it :)