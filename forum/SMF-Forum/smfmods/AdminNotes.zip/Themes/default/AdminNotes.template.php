<?php

//Display the add note form template.
function template_main()
{
	global $context, $settings, $scripturl, $txt;

	echo'
				<div class="roundframe">	
					<div class="cat_bar">
						<h3 class="catbg"><span class="left"></span>
							', $txt['add_note'], '
						</h3>
					</div>
					<div class="windowbg">
						<span class="topslice"><span></span></span>
						<div class="content">';
							echo'
							<form action="', $scripturl, '?action=admin;area=notes;sa=submit_note" method="post">
							    <br/>
								<input id="note" name="note" type="text" size="100" placeholder="', $txt['add_note'], '" required/>
								<input class="button active" id="submit" name="submit" type="submit" value="', $txt['submit_note'], '"/>
								<input type="hidden" name="sc" value="' ,$context['session_id'], '" />
							</form>'; 
						echo'
						</div>
						<span class="botslice"><span></span></span>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="clear"></div>';
}