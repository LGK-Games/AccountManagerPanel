<?php

//Language strings for the mod.
$txt['add_note'] = 'Add Note';
$txt['list_admin_notes'] = 'Notes';
$txt['list_admin_notes_desc'] = 'Below is a listing of all notes added.';
$txt['no_admin_note_yet'] = 'There are currently no notes added.';
$txt['delete_selected_note_logs'] = 'Delete Selected Note Logs';
$txt['delete_selected_note_logs_confirm'] = 'Are you sure that you want to delete the selected note logs? This action can not be undone.';
$txt['admin_note'] = 'Note';
$txt['note_date'] = 'Time';
$txt['submit_note'] = 'Submit Note';