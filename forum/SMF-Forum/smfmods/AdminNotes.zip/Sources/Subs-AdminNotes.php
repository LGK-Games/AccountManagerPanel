<?php

// If we are outside SMF throw an error.
if (!defined('SMF'))
	die('Hacking attempt...'); 
	
//Add the Admin Panel link to add and list all admin notes.
function admin_notes_admin_areas(&$admin_areas)
{
	global $txt;
	
	loadLanguage('AdminNotes');

	$admin_areas['forum']['areas'] += array(
		'notes' => array(
		    'permission' => array('admin_forum'),
			'label' => $txt['list_admin_notes'],
			'file' => 'AdminNotes.php',
			'function' => 'AdminNotesMenu',
			'icon' => 'members.gif',
			'subsections' => array(
			    'list' => array($txt['list_admin_notes']),	
				'add_note' => array($txt['add_note']),
			),
		),
	);
}