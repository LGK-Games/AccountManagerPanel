<?php

// If we are outside SMF throw an error.
if (!defined('SMF')) {
    die('Hacking attempt...');
}

//Admin panel menu for the mod.
function AdminNotesMenu()
{
	global $context, $txt;
	
	isAllowedTo('admin_forum');

	$subActions = array(
	    'list' => 'AdminNotes', 
	    'add_note' => 'AddNote',
		'submit_note' => 'SubmitNote',
	);

	$context['page_title'] = $txt['list_admin_notes'];

	$context[$context['admin_menu_name']]['tab_data'] = array(
		'title' => &$txt['list_admin_notes'],
		'description' => $txt['list_admin_notes_desc'],
	);

	// Call the right function for this sub-acton.
	if (!isset($_GET['sa']) || !isset($subActions[$_GET['sa']]))
		$_GET['sa'] = 'list';
	
	$subActions[$_GET['sa']]();
}

//Display the note form.
function AddNote()
{
	loadTemplate('AdminNotes');
}

//Insert note in the database.
function SubmitNote()
{
	global $smcFunc, $user_info;
	
	isAllowedTo('admin_forum');
	
	$_SESSION['save_success'] = false;

	$_POST['note'] = $smcFunc['htmlspecialchars']($_POST['note'], ENT_QUOTES);
	
	$smcFunc['db_insert']('',
		'{db_prefix}admin_notes',
		    array(
		            'admin_id' => 'int', 'note_time' => 'int', 'note' => 'string',
			     ),
		    array(
				    $user_info['id'], time(), $_POST['note'],
			    ),
		    array('admin_id')
	);
	
	$_SESSION['save_success'] = true;

	redirectexit('action=admin;area=notes;sa=list');
}

//Display all notes in the admin panel.
function AdminNotes()
{
	global $txt, $sourcedir, $scripturl, $context, $smcFunc;
	
	isAllowedTo('admin_forum');
	
	// User pressed the 'remove selection button'.
	if (!empty($_POST['delete']) && !empty($_POST['remove']) && is_array($_POST['remove']))
	{
		checkSession();

		foreach ($_POST['remove'] as $index => $log_time)
			$_POST['remove'][(int) $index] = (int) $log_time;

		$smcFunc['db_query']('', '
			DELETE FROM {db_prefix}admin_notes
			WHERE note_id IN ({array_int:notes_list})',
			array(
				'notes_list' => $_POST['remove'],
			)
		);

		redirectexit('action=admin;area=notes;sa=list');
	}
	
	$listOptions = array(
		'id' => 'notes_list',
		'items_per_page' => 20,
		'base_href' => $scripturl . '?action=admin;area=notes;sa=list',
		'default_sort_col' => 'admin_id',
		'no_items_label' => $txt['no_admin_note_yet'],
		'get_items' => array(
			'function' => 'list_geAdminNotes',
		),
		'get_count' => array(
			'function' => 'list_countAdminNotes',
		),
		'columns' => array(
			'admin_id' => array(
				'header' => array(
					'value' => $txt['username'],
					'style' => 'width: 20%; text-align: left;',
				),
				'data' => array(
					'db' => 'admin_id',
				),
				'sort' =>  array(
					'default' => 'admin_id DESC',
					'reverse' => 'admin_id',
				),
			),
			'note' => array(
				'header' => array(
					'value' => $txt['admin_note'],
				),
				'data' => array(
					'db' => 'note',
					'style' => 'width: 60%; text-align: left;',
				),
				'sort' => array(
					'default' => 'note',
					'reverse' => 'note DESC',
				),
			),
			'note_time' => array(
				'header' => array(
					'value' => $txt['note_date'],
				),
				'data' => array(
					'db' => 'note_time',
					'style' => 'width: 20%; text-align: center;',
				),
				'sort' =>  array(
					'default' => 'note_time DESC',
					'reverse' => 'note_time',
				),
			),
			'check' => array(
				'header' => array(
					'value' => '<input type="checkbox" onclick="invertAll(this, this.form);" class="input_check" />',
			),
			'data' => array(
					'sprintf' => array(
						'format' => '<input type="checkbox" name="remove[]" value="%1$d" class="input_check" />',
						'params' => array(
							'id' => false,
						),
					),
					'style' => 'text-align: center',
				),
			),
		),	
		'form' => array(
			'href' => $scripturl . '?action=admin;area=notes;sa=list',
		),
		'additional_rows' => array(
			array(
				'position' => 'below_table_data',
				'value' => '<input type="submit" name="delete" value="' . $txt['delete_selected_note_logs'] . '" onclick="return confirm(\'' . $txt['delete_selected_note_logs_confirm'] . '\');" class="button_submit" />',
				'style' => 'text-align: right;',
			),
		),
	);

	require_once($sourcedir . '/Subs-List.php');
	createList($listOptions);

	$context['sub_template'] = 'show_list';
	$context['default_list'] = 'notes_list';
}

//Get all admin notes.
function list_geAdminNotes($start, $items_per_page, $sort)
{
	global $smcFunc, $scripturl;
	
	$result = $smcFunc['db_query']('', '
	       SELECT n.note_id, n.admin_id, n.note, n.note_time,
		   mem.id_member, mem.member_name
		   FROM {db_prefix}admin_notes AS n
		   LEFT JOIN {db_prefix}members AS mem ON (mem.id_member = n.admin_id)
		   ORDER BY {raw:sort}
		   LIMIT {int:start}, {int:per_page}',
		   array(
				 'sort' => $sort,
		         'start' => $start,
			     'per_page' => $items_per_page,
			    )
	);
	
    $members = array();
	
	while ($row = $smcFunc['db_fetch_assoc']($result))
	{
		$members[] = array(
		    'id' => $row['note_id'],
			'admin_id' => '<a href="' . $scripturl . '?action=profile;u=' . $row['admin_id'] . '">' . $row['member_name'] . '</a>',
			'note' => $row['note'],
			'note_time' => timeformat($row['note_time']),
		);
	}
	
	return $members;

	$smcFunc['db_free_result']($result);
}

//Count all members notes for the pagination.
function list_countAdminNotes()
{
	global $smcFunc;
	
	$result = $smcFunc['db_query']('', '
		SELECT COUNT(*)
		FROM {db_prefix}admin_notes',
		array( )
	);
				
	list ($members) = $smcFunc['db_fetch_row']($result);
	
	$smcFunc['db_free_result']($result);

	return $members;
}