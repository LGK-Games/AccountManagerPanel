<?php

/**
 * The members online today section of the info center.
 */
function template_ic_block_MembersOnlineToday()
{
	global $context, $txt;
	
	echo '
			<div class="sub_bar">
				<h4 class="subbg">
					<span class="main_icons people"></span> ', $txt['members_logged_today'], '
				</h4>
			</div>
			<p class="inline">';
	        echo
			    $txt['total_members_logged_in_today'], ': <strong>', $context['count_members_today'], '</strong>';

			// Assuming there HAVE been users online today... each user in users_online has an id, username, name, group, href, and link.
			if (!empty($context['members_online_today']) && allowedTo('view_today_visitors'))
			{
	            echo '<br />'; 
				
	            echo empty($context['members_online_today_list']) ? '0' . $txt['members'] : implode(', ', $context['members_online_today_list']) . ((empty($context['hidden_members_today']) || allowedTo('moderate_forum')) ? '' : ' (+ ' . $context['hidden_members_today'] . ' ' . $txt['hidden'] . ')');
			}
	        echo '
			</p>';
}