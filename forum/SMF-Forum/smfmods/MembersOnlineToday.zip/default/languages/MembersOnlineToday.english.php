<?php

/**
 * Language strings for the mod.
 */
 
$txt['members_logged_today']= 'Members Logged In Today';
$txt['total_members_logged_in_today']= 'Total';
$txt['permissiongroup_todayvisitors'] = 'Today \'s Visitors';
$txt['permissiongroup_simple_todayvisitors'] = 'Today \'s Visitors';
$txt['permissionname_view_today_visitors'] = 'View Today \'s Visitors';
$txt['permissionhelp_view_today_visitors'] = 'This permission allows a member in this group to view the list of members who visited your forum for the past 24 hours.';