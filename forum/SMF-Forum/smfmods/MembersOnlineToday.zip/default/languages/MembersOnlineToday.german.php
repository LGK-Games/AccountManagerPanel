<?php

/**
 * Language strings for the mod.
 */
 
$txt['members_logged_today'] = 'Eingeloggte User (24h)';
$txt['total_members_logged_in_today'] = 'Insgesamt';
$txt['permissiongroup_todayvisitors'] = 'Eingeloggte User (24h)';
$txt['permissiongroup_simple_todayvisitors'] = 'Eingeloggte User (24h)';
$txt['permissionname_view_today_visitors'] = 'Zeige die Besucher der letzten 24h';
$txt['permissionhelp_view_today_visitors'] = 'Diese Berechtigung erlaubt die Anzeige aller eingeloggten User der letzten 24h.';