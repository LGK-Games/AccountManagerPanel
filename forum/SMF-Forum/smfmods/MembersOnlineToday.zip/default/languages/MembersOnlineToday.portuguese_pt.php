<?php

/**
 * Language strings for the mod.
 */
 
$txt['members_logged_today']= 'Membros que nos visitaram hoje';
$txt['total_members_logged_in_today']= 'Total';
$txt['permissiongroup_todayvisitors'] = 'Visitas de hoje';
$txt['permissiongroup_simple_todayvisitors'] = 'Visitas de hoje';
$txt['permissionname_view_today_visitors'] = 'Ver as visitas de hoje';
$txt['permissionhelp_view_today_visitors'] = 'Esta opção permite que um membro deste grupo veja a lista de membros que visitaram o seu fórum nas últimas 24 horas.';