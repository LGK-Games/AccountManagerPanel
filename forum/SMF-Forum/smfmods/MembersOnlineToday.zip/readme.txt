This is a simple mod that will list all members who logged in at your forum for the past 24 hours on board index at the Info Center area.

There are no settings for this mod. After you install the mod, go to the group(s) that you want to view the list of today visitors, click the modify button, tick the View Today 's Visitors checkbox and save the changes.