<?php

/**
 * If we are outside SMF throw an error.
 */
if (!defined('SMF'))
{
	die('Hacking attempt...');
}

/**
 * Load the language.
 */
function getMembersOnlineTodayLanguage()
{
	loadLanguage('MembersOnlineToday');
}


/**
 * Add group permissions.
 */
function getMembersOnlineTodayPermissions(&$permissionGroups, &$permissionList)
{ 
    loadLanguage('MembersOnlineToday'); 
	
	$permissionList['membergroup'] += array('view_today_visitors' => array(false, 'todayvisitors', 'todayvisitors'));
}

/**
 * Display members who logged in today on board index.
 */
function getMembersOnlineTodayHook() 
{
    global $context;

    loadTemplate('MembersOnlineToday');
	loadLanguage('MembersOnlineToday'); 
    
	$context += getMembersOnlineToday();
    $context['info_center'][] = array(
        'tpl' => 'MembersOnlineToday',
        'txt' => 'members_logged_today',
    );
}

/**
 * Get all members who logged in today.
 */
function getMembersOnlineToday()
{
	global $smcFunc, $scripturl, $user_info;
		
	$context['can_moderate_forum'] = allowedTo('moderate_forum');
	
	// Initialize the array that'll be returned later on.
	$membersOnlineToday = array(
		'members_online_today' => array(),
		'members_online_today_list' => array(),
		'num_buddies_today' => 0,
		'hidden_members_today' => 0,
		'count_members_today' => 0,
	);

	// Load the users who logged in today.
	$request = $smcFunc['db_query']('', '
		SELECT
			mem.id_member, mem.last_login, mem.real_name, mem.member_name, mem.show_online,
			mg.online_color, mg.id_group, mg.group_name
		FROM {db_prefix}members AS mem
			LEFT JOIN {db_prefix}membergroups AS mg ON (mg.id_group = CASE WHEN mem.id_group = {int:reg_mem_group} THEN mem.id_post_group ELSE mem.id_group END)
			WHERE mem.last_login >= {int:last_login}
			ORDER BY mem.last_login DESC',
		array(
			'reg_mem_group' => 0,
			'last_login' => time() - 86400,
		)
	);
	
    while ($row = $smcFunc['db_fetch_assoc']($request))
	{
		if (empty($row['show_online']) && !allowedTo('moderate_forum'))
	    {
			// Just increase the stats and don't add this hidden user to any list.
			$membersOnlineToday['hidden_members_today']++;
		    continue;
		}
		
		// Some basic color coding...
		if (!empty($row['online_color']))
		{
			$link = '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '" style="color: ' . $row['online_color'] . ';" title="' . strip_tags(timeformat($row['last_login'])) . '">' . $row['real_name'] . '</a>';
		}
		else
		{
			$link = '<a href="' . $scripturl . '?action=profile;u=' . $row['id_member'] . '" title="' . strip_tags(timeformat($row['last_login'])) . '">' . $row['real_name'] . '</a>';
        }
		
		// Buddies get counted and highlighted.
		$is_buddy = in_array($row['id_member'], $user_info['buddies']);
		if ($is_buddy)
	    {
			$membersOnlineToday['num_buddies_today']++;
			$link = '<strong>' . $link . '</strong>';
	    }

		if (!empty($row['show_online']) || allowedTo('moderate_forum'))
		{
			// This is the compact version, simply implode it to show.
			$membersOnlineToday['members_online_today_list'][] = empty($row['show_online']) ? '<i>' . $link . '</i>' : $link;
			 
			// A lot of useful information for each member. 
			$membersOnlineToday['members_online_today'][] = array(
			    'id' => $row['id_member'],
			    'username' => $row['real_name'],
			    'name' => $row['real_name'],
			    'group' => $row['id_group'],
			    'href' => $scripturl . '?action=profile;u=' . $row['id_member'],
			    'link' => $link,
			    'is_buddy' => $is_buddy,
			    'hidden' => empty($row['show_online']),
			);
        }
	}
	
	$smcFunc['db_free_result']($request);
	
	// Hidden and non-hidden members make up all today 's online members.
	$membersOnlineToday['count_members_today'] = count($membersOnlineToday['members_online_today']) + $membersOnlineToday['hidden_members_today'];

	return $membersOnlineToday;
}