<?php

if (!defined('SMF'))
	die('Hacking attempt...');

function BBCode_FontSize(&$codes)
{
	// Add the bbc code
	$codes[] = array(
			'tag' => 'size',
			'type' => 'unparsed_equals',
			'test' => '([1-9][0-9]|[1-9][0-9][0-9]|[1-9][0-9][%]|[1-9][0-9][0-9][%])\]',
			'before' => '<span style="font-size: $1%;" class="bbc_size">',
			'after' => '</span>',
			'validate' => function(&$tag, &$data, $disabled)
			{
				$data = str_replace('%', '', $data);
			},
	);
}

?>
